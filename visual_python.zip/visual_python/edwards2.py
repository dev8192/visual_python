import pygame
import sys
import math

# Initialize Pygame
pygame.init()
pygame.font.init()

# Setup Fullscreen Resolution dynamically
info = pygame.display.Info()
WIDTH, HEIGHT = info.current_w, info.current_h
screen = pygame.display.set_mode((WIDTH, HEIGHT), pygame.NOFRAME)
pygame.display.set_caption("Ed25519 Curve Asymmetrical Zoom")
clock = pygame.time.Clock()
FONT = pygame.font.SysFont("Consolas", 24)

# Colors
COLOR_BG = (10, 11, 18)
COLOR_AXIS = (120, 120, 140)
COLOR_GRID = (35, 35, 48)
COLOR_CURVE = (0, 255, 190)
COLOR_TEXT = (230, 235, 255)

# Curve constant d for Ed25519
D = 121665 / 121666

# State Machine Configuration
STATE_NORMAL = 0
STATE_PAUSE1 = 1
STATE_ZOOM_IN = 2
STATE_PAUSE2 = 3
STATE_ZOOM_OUT = 4

current_state = STATE_NORMAL
state_timer = 0.0

# Bounds Config
# Normal Zoom: Perfect 1:1 Aspect Ratio bounds
X_BOUNDS_NORMAL = (-1.5, 1.5)
Y_BOUNDS_NORMAL = (-1.5, 1.5)

# Asymmetric Zoom: Heavy X-zoom, light Y-zoom to stretch out the curve properties
X_BOUNDS_ZOOMED = (-0.0003, 0.0003) 
Y_BOUNDS_ZOOMED = (-1.2, 1.2)

# Dynamic viewport coordinates
current_x_min, current_x_max = X_BOUNDS_NORMAL
current_y_min, current_y_max = Y_BOUNDS_NORMAL

def get_screen_coords(x, y):
    """Convert mathematical coordinates to screen pixel positions."""
    px = int((x - current_x_min) / (current_x_max - current_x_min) * WIDTH)
    py = int(HEIGHT - (y - current_y_min) / (current_y_max - current_y_min) * HEIGHT)
    return px, py

def get_math_coords(px, py):
    """Convert screen pixels back to mathematical coordinates."""
    x = current_x_min + (px / WIDTH) * (current_x_max - current_x_min)
    y = current_y_min + ((HEIGHT - py) / HEIGHT) * (current_y_max - current_y_min)
    return x, y

def draw_grid_and_axes():
    """Draws dynamic grids and value ticks corresponding to asymmetrical dimensions."""
    x_range = current_x_max - current_x_min
    y_range = current_y_max - current_y_min

    def get_grid_step(v_range):
        if v_range <= 0: return 1.0
        order = 10 ** math.floor(math.log10(v_range))
        normalized = v_range / order
        if normalized < 2: return order * 0.2
        elif normalized < 5: return order * 0.5
        else: return order

    x_step = get_grid_step(x_range)
    y_step = get_grid_step(y_range)

    x_start = math.ceil(current_x_min / x_step) * x_step
    y_start = math.ceil(current_y_min / y_step) * y_step

    # Vertical grid lines & X scale ticks
    x_val = x_start
    while x_val <= current_x_max:
        px, _ = get_screen_coords(x_val, 0)
        if 0 <= px <= WIDTH:
            pygame.draw.line(screen, COLOR_GRID, (px, 0), (px, HEIGHT), 1)
            lbl = FONT.render(f"{x_val:.5f}", True, COLOR_AXIS)
            screen.blit(lbl, (px + 6, HEIGHT - 35))
        x_val += x_step

    # Horizontal grid lines & Y scale ticks
    y_val = y_start
    while y_val <= current_y_max:
        _, py = get_screen_coords(0, y_val)
        if 0 <= py <= HEIGHT:
            pygame.draw.line(screen, COLOR_GRID, (0, py), (WIDTH, py), 1)
            lbl = FONT.render(f"{y_val:.2f}", True, COLOR_AXIS)
            screen.blit(lbl, (15, py - 26))
        y_val += y_step

    # Structural Master Axes
    ax_x, ax_y = get_screen_coords(0, 0)
    if 0 <= ax_x <= WIDTH:
        pygame.draw.line(screen, COLOR_AXIS, (ax_x, 0), (ax_x, HEIGHT), 2)
    if 0 <= ax_y <= HEIGHT:
        pygame.draw.line(screen, COLOR_AXIS, (0, ax_y), (WIDTH, ax_y), 2)

def draw_edwards_curve():
    """Renders the twisted Edwards curve mapping solutions directly to screen coordinates."""
    points_top = []
    points_bottom = []

    # Map directly across all screen pixel columns to capture the warped curvature smoothly
    for px in range(0, WIDTH, 1):
        x, _ = get_math_coords(px, 0)

        # Equation rearrangement: y^2 = (1 + x^2) / (1 + d * x^2)
        numerator = 1 + x**2
        denominator = 1 + D * x**2

        if denominator != 0:
            y2 = numerator / denominator
            if y2 >= 0:
                y_pos = math.sqrt(y2)
                
                # Append coordinates if they fall within viewport constraints
                if current_y_min <= y_pos <= current_y_max:
                    points_top.append(get_screen_coords(x, y_pos))
                if current_y_min <= -y_pos <= current_y_max:
                    points_bottom.append(get_screen_coords(x, -y_pos))

    # Connect components to ensure a continuous line presentation
    if len(points_top) > 1:
        pygame.draw.lines(screen, COLOR_CURVE, False, points_top, 3)
    if len(points_bottom) > 1:
        pygame.draw.lines(screen, COLOR_CURVE, False, points_bottom, 3)

def draw_info_panel():
    """Renders the telemetry metadata block safely in the top-left area."""
    x_span = current_x_max - current_x_min
    y_span = current_y_max - current_y_min

    lines = [
        "━ Ed25519 Curve Scale Telemetry ━",
        f"Equation : -x² + y² = 1 - (121665/121666)x²y²",
        f"X-Span   : {x_span:.6f}",
        f"Y-Span   : {y_span:.4f}",
        f"Animation: {['Normal Field', 'Holding...', 'Asymmetric Zoom In...', 'Holding...', 'Zooming Out...'][current_state]}",
        "Press [ESC] to Exit Visualization"
    ]

    for i, line in enumerate(lines):
        text_surface = FONT.render(line, True, COLOR_TEXT)
        screen.blit(text_surface, (30, 30 + i * 30))

# --- Main Runtime Loop ---
running = True
while running:
    dt = clock.tick(60) / 1000.0  # Framerate timing normalization
    state_timer += dt

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:  # Escape key safety check for fullscreen
                running = False

    # State Machine Handling Interpolations
    if current_state == STATE_NORMAL:
        current_x_min, current_x_max = X_BOUNDS_NORMAL
        current_y_min, current_y_max = Y_BOUNDS_NORMAL
        if state_timer >= 2.0:
            current_state = STATE_PAUSE1
            state_timer = 0.0

    elif current_state == STATE_PAUSE1:
        if state_timer >= 1.0:
            current_state = STATE_ZOOM_IN
            state_timer = 0.0

    elif current_state == STATE_ZOOM_IN:
        t = min(state_timer / 2.0, 1.0)
        ease_t = math.sin(t * math.pi / 2)  # Smooth out animation pacing

        current_x_min = X_BOUNDS_NORMAL[0] + (X_BOUNDS_ZOOMED[0] - X_BOUNDS_NORMAL[0]) * ease_t
        current_x_max = X_BOUNDS_NORMAL[1] + (X_BOUNDS_ZOOMED[1] - X_BOUNDS_NORMAL[1]) * ease_t
        current_y_min = Y_BOUNDS_NORMAL[0] + (Y_BOUNDS_ZOOMED[0] - Y_BOUNDS_NORMAL[0]) * ease_t
        current_y_max = Y_BOUNDS_NORMAL[1] + (Y_BOUNDS_ZOOMED[1] - Y_BOUNDS_NORMAL[1]) * ease_t

        if t >= 1.0:
            current_state = STATE_PAUSE2
            state_timer = 0.0

    elif current_state == STATE_PAUSE2:
        if state_timer >= 1.0:
            current_state = STATE_ZOOM_OUT
            state_timer = 0.0

    elif current_state == STATE_ZOOM_OUT:
        t = min(state_timer / 2.0, 1.0)
        ease_t = math.sin(t * math.pi / 2)

        current_x_min = X_BOUNDS_ZOOMED[0] + (X_BOUNDS_NORMAL[0] - X_BOUNDS_ZOOMED[0]) * ease_t
        current_x_max = X_BOUNDS_ZOOMED[1] + (X_BOUNDS_NORMAL[1] - X_BOUNDS_ZOOMED[1]) * ease_t
        current_y_min = Y_BOUNDS_ZOOMED[0] + (Y_BOUNDS_NORMAL[0] - Y_BOUNDS_ZOOMED[0]) * ease_t
        current_y_max = Y_BOUNDS_ZOOMED[1] + (Y_BOUNDS_NORMAL[1] - Y_BOUNDS_ZOOMED[1]) * ease_t

        if t >= 1.0:
            current_state = STATE_NORMAL
            state_timer = 0.0

    # Graphic Drawing Operations
    screen.fill(COLOR_BG)
    draw_grid_and_axes()
    draw_edwards_curve()
    draw_info_panel()
    pygame.display.flip()

pygame.quit()
sys.exit()
