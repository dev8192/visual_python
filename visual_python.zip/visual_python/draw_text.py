import os
import sys
os.environ['PYGAME_HIDE_SUPPORT_PROMPT'] = "1"
import pygame

pygame.init()
pygame.font.init()

screen = pygame.display.set_mode((0, 0), pygame.NOFRAME)
pygame.mouse.set_visible(False)

width, height = screen.get_size()

BG_COLOR = (25, 25, 30)
WHITE    = (240, 240, 245)
CYAN     = (0, 200, 255)
YELLOW   = (255, 215, 0)

# Syntax: pygame.font.SysFont(font_name, size, bold=False, italic=False)
title_font = pygame.font.SysFont("Arial", 48, bold=True)
body_font = pygame.font.SysFont("Consolas", 24)
# custom_font = pygame.font.Font("my_font_file.ttf", 32)

# ==============================================================================
# 2. RENDERING TEXT SURFACES
# ==============================================================================
# In Pygame, you don't draw text directly. You "render" it into an image (Surface) first.
# Syntax: font.render(text_string, antialias, text_color, background_color=None)
# Note: Set antialias=True to make the edges of the letters look smooth!

title_surface = title_font.render("Pygame Text Rendering Guide", True, CYAN)
body_surface1 = body_font.render("1. Choose a font (System or TrueType file).", True, WHITE)
body_surface2 = body_font.render("2. Render it to a surface (turn on anti-aliasing).", True, WHITE)
body_surface3 = body_font.render("3. Blit it to your main screen surface.", True, WHITE)
bg_text_surface = body_font.render(" Text with a custom background! ", True, BG_COLOR, YELLOW)

clock = pygame.time.Clock()
running = True

while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                running = False

    screen.fill(BG_COLOR)

    screen.blit(title_surface, (100, 100))
    screen.blit(body_surface1, (100, 200))
    screen.blit(body_surface2, (100, 240))
    screen.blit(body_surface3, (100, 280))
    screen.blit(bg_text_surface, (100, 360))

    pygame.display.flip()
    clock.tick(60)

pygame.quit()
sys.exit()
