import os
import sys
os.environ['PYGAME_HIDE_SUPPORT_PROMPT'] = "1"
import pygame

pygame.init()

width, height = 300, 300
screen = pygame.display.set_mode((width, height), pygame.HIDDEN)

screen.fill((30, 30, 35))
pygame.draw.circle(screen, (0, 200, 255), (width // 2, height // 2), 100)

output_filename = "circle.png"
pygame.image.save(screen, output_filename)

print(f"Success! Saved image to: {os.path.abspath(output_filename)}")

pygame.quit()
sys.exit()
