import pygame
import sys

pygame.init()

info = pygame.display.Info()
SCREEN_WIDTH = info.current_w
SCREEN_HEIGHT = info.current_h
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.NOFRAME)

COLOR_BG = (22, 22, 29)
COLOR_AXIS = (100, 110, 120)
COLOR_CURVE = (255, 107, 107)
COLOR_TEXT = (240, 240, 240)

ORIGIN_X = SCREEN_WIDTH // 2
ORIGIN_Y = SCREEN_HEIGHT // 2
SCALE_PIXELS_PER_UNIT = 40

# Parabola initial parameters in vertex form: y = a*(x - h)^2 + k
# Using standard math coordinates (y goes up, x goes right)
a = 1.0
h = 0.0
k = 0.0

font = pygame.font.SysFont("Consolas", 32)

def math_to_screen(x, y):
    screen_x = int(ORIGIN_X + x * SCALE_PIXELS_PER_UNIT)
    screen_y = int(ORIGIN_Y - y * SCALE_PIXELS_PER_UNIT)
    return screen_x, screen_y

def screen_to_math(screen_x, screen_y):
    x = (screen_x - ORIGIN_X) / SCALE_PIXELS_PER_UNIT
    y = (ORIGIN_Y - screen_y) / SCALE_PIXELS_PER_UNIT
    return x, y

clock = pygame.time.Clock()

running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                running = False

    keys = pygame.key.get_pressed()
    
    move_speed = 0.1
    if keys[pygame.K_LEFT]:
        h -= move_speed
    if keys[pygame.K_RIGHT]:
        h += move_speed
    if keys[pygame.K_UP]:
        k += move_speed
    if keys[pygame.K_DOWN]:
        k -= move_speed
        
    scale_speed = 0.05
    if keys[pygame.K_EQUALS] or keys[pygame.K_KP_PLUS]:
        a += scale_speed
    if keys[pygame.K_MINUS] or keys[pygame.K_KP_MINUS]:
        a -= scale_speed
        if abs(a) < 0.01:
            a = 0.01 if a >= 0 else -0.01

    screen.fill(COLOR_BG)

    pygame.draw.line(screen, COLOR_AXIS, (0, ORIGIN_Y), (SCREEN_WIDTH, ORIGIN_Y), 2)
    pygame.draw.line(screen, COLOR_AXIS, (ORIGIN_X, 0), (ORIGIN_X, SCREEN_HEIGHT), 2)

    # y = a * (x - h)^2 + k
    # y = a * (x - h) * (x - h) + k
    # y = a * (x^2 - x * h - h * x + h^2) + k
    # y = a * (x^2 - 2 * x * h + h^2) + k
    # y = a * x^2 - 2 * a * h * x + a * h^2 + k
    # y = a * x^2 + b * x + c
    b_coeff = -2 * a * h
    c_coeff = a * (h ** 2) + k

    points = []
    for screen_x in range(0, SCREEN_WIDTH):
        math_x = (screen_x - ORIGIN_X) / SCALE_PIXELS_PER_UNIT
        math_y = a * (math_x ** 2) + b_coeff * math_x + c_coeff
        screen_pos = math_to_screen(math_x, math_y)

        if -1000 < screen_pos[1] < SCREEN_HEIGHT + 1000:
            points.append(screen_pos)

    if len(points) >= 2:
        pygame.draw.lines(screen, COLOR_CURVE, False, points, 3)

    sign_b = "+" if b_coeff >= 0 else "-"
    sign_c = "+" if c_coeff >= 0 else "-"
    
    equation_text = f"y = {a:.2f}x² {sign_b} {abs(b_coeff):.2f}x {sign_c} {abs(c_coeff):.2f}"
    text_surface = font.render(equation_text, True, COLOR_TEXT)
    screen.blit(text_surface, (30, 30))

    pygame.display.flip()
    clock.tick(60)

# pygame.quit()
# sys.exit()
