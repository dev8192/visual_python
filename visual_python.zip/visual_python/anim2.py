import sys
import pygame

# Initialize Pygame
pygame.init()

# Setup full screen window
screen = pygame.display.set_mode((0, 0), pygame.NOFRAME)
pygame.display.set_caption("Additive Color Circle Animation")
pygame.mouse.set_visible(False)

# Get screen dimensions
width, height = screen.get_size()
cy = height // 2          # Vertical center for all circles
radius = min(width, height) // 10

# Calculate horizontal positions so they are spaced out nicely
# Left, Middle, and Right circle X coordinates
left_x   = width // 4
middle_x = width // 2
right_x  = (width * 3) // 4

# Colors (RGB)
BG_COLOR = (50, 50, 50)     # Greyish background
RED      = (255, 50, 50)
GREEN    = (50, 255, 50)
BLUE     = (50, 50, 255)

# Clock to control frame rate
clock = pygame.time.Clock()
FPS = 60

running = True

while running:
    # 1. Handle Events (allows early exit with 'Escape')
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                running = False

    # 2. Track elapsed time in seconds
    seconds_passed = pygame.time.get_ticks() / 1000.0

    # Automatic exit right at the 5-second mark
    if seconds_passed >= 5.0:
        running = False

    # 3. Fill the background
    screen.fill(BG_COLOR)

    # 4. Additive Animation Timeline Logic
    # 0s to 1s: Empty background (do nothing)
    
    # At 1s: Add Red
    if seconds_passed >= 1.0:
        pygame.draw.circle(screen, RED, (left_x, cy), radius)
        
    # At 2s: Add Green (Red stays on screen)
    if seconds_passed >= 2.0:
        pygame.draw.circle(screen, GREEN, (middle_x, cy), radius)
        
    # At 3s & 4s: Add Blue (Red and Green stay on screen)
    if seconds_passed >= 3.0:
        pygame.draw.circle(screen, BLUE, (right_x, cy), radius)

    # 5. Update display
    pygame.display.flip()
    clock.tick(FPS)

# Clean up and exit automatically at 5 seconds
pygame.quit()
sys.exit()
