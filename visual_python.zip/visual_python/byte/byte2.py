import sys
import pygame

# Initialize Pygame
pygame.init()

# --- Screen Configuration ---
# Opens Pygame in native Fullscreen mode
screen = pygame.display.set_mode((0, 0), pygame.FULLSCREEN)
WINDOW_WIDTH, WINDOW_HEIGHT = screen.get_size()
pygame.display.set_caption("Byte & Binary Counting Visualizer")
clock = pygame.time.Clock()

# --- Color Palette ---
COLOR_BG = (15, 18, 26)          # Sleek, immersive dark canvas
COLOR_BIT_ON = (46, 204, 113)     # Glowing green for '1'
COLOR_BIT_OFF = (43, 50, 66)      # Dim gray-blue for '0'
COLOR_TEXT = (236, 240, 241)     # Clean white for primary labels
COLOR_HEX = (155, 89, 182)       # Vibrant purple for hexadecimal
COLOR_DECIMAL = (241, 196, 15)   # Amber yellow for decimal math
COLOR_BORDER = (26, 32, 44)
COLOR_MUTED = (127, 140, 141)     # Muted gray for paused overlay/hints

# --- UI Layout Calculations ---
# Significantly increased sizing for fullscreen deployment
BIT_WIDTH = 110
BIT_HEIGHT = 150
BIT_SPACING = 25
NIBBLE_GAP = 70  # Explicit separation between the left 4 bits and right 4 bits

# Compute absolute horizontal starting positions for each of the 8 bits
bit_x_positions = []
total_width = (BIT_WIDTH * 8) + (BIT_SPACING * 6) + NIBBLE_GAP
start_x = (WINDOW_WIDTH - total_width) // 2

current_x = start_x
for i in range(8):
    bit_x_positions.append(current_x)
    # If we just placed the 4th bit (index 3), add the large nibble gap instead of regular spacing
    if i == 3:
        current_x += BIT_WIDTH + NIBBLE_GAP
    else:
        current_x += BIT_WIDTH + BIT_SPACING

START_Y = (WINDOW_HEIGHT // 2) - 130

# --- Fonts Configuration ---
def get_font(name, size, bold=True):
    try:
        return pygame.font.SysFont(name, size, bold=bold)
    except:
        return pygame.font.Font(None, size)

font_giant = get_font("monospace", 100, bold=True)
font_large = get_font("monospace", 70, bold=True)
font_medium = get_font("sans-serif", 40, bold=True)
font_small = get_font("sans-serif", 26, bold=False)
font_super = get_font("sans-serif", 24, bold=True)  # Used for mathematical superscripts

# --- Counter & Control States ---
counter = 0
MAX_VALUE = 255
is_paused = False

# Global Clock Timer (fires an event every 1000ms to increment)
TIMER_EVENT = pygame.USEREVENT + 1
pygame.time.set_timer(TIMER_EVENT, 1000)

def draw_superscript_text(surface, text, power, x, y, base_font, super_font, color):
    """Renders text with an aligned mathematical superscript exponent."""
    base_surf = base_font.render(text, True, color)
    super_surf = super_font.render(power, True, color)
    
    # Blit the base number
    surface.blit(base_surf, (x, y))
    # Blit the exponent slightly offset up and to the right
    surface.blit(super_surf, (x + base_surf.get_width() + 2, y - 8))
    
    return base_surf.get_width() + super_surf.get_width() + 4

# --- Main Runtime Loop ---
running = True
while running:
    # 1. Input Processing
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
            
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                running = False
                
            elif event.key == pygame.K_SPACE:
                is_paused = not is_paused
                
            elif event.key == pygame.K_LEFT:
                if is_paused and counter > 0:
                    counter -= 1
                    
            elif event.key == pygame.K_RIGHT:
                if is_paused and counter < MAX_VALUE:
                    counter += 1
                    
        elif event.type == TIMER_EVENT:
            if not is_paused:
                if counter < MAX_VALUE:
                    counter += 1
                else:
                    print("Reached 11111111! Program terminating safely.")
                    running = False

    # 2. Canvas Refresh
    screen.fill(COLOR_BG)

    # 3. Calculate Bit Values
    binary_str = f"{counter:08b}"
    hex_str = f"0x{counter:02X}"

    # 4. Render Hexadecimal (Top-Middle Layer)
    hex_surface = font_giant.render(hex_str, True, COLOR_HEX)
    hex_rect = hex_surface.get_rect(center=(WINDOW_WIDTH // 2, START_Y - 140))
    screen.blit(hex_surface, hex_rect)

    # 5. Render Visual Byte Matrix
    for i in range(8):
        bit_val = binary_str[i]
        x_pos = bit_x_positions[i]
        
        box_color = COLOR_BIT_ON if bit_val == '1' else COLOR_BIT_OFF
        rect = pygame.Rect(x_pos, START_Y, BIT_WIDTH, BIT_HEIGHT)
        
        # Core block
        pygame.draw.rect(screen, box_color, rect, border_radius=12)
        pygame.draw.rect(screen, COLOR_BORDER, rect, width=3, border_radius=12)
        
        # Character glyph inside block ('0' or '1' explicitly drawn here; no extra binaries duplicated)
        char_surface = font_large.render(bit_val, True, COLOR_TEXT)
        char_rect = char_surface.get_rect(center=rect.center)
        screen.blit(char_surface, char_rect)

    # 6. Build and Render the 3-Row Explicit Decimal Breakdowns
    # Filter active powers of 2
    active_powers = [7 - i for i in range(8) if binary_str[i] == '1']
    
    # Calculate baseline vertical spacing underneath the byte block matrix
    row_start_y = START_Y + BIT_HEIGHT + 60
    line_spacing = 55
    
    # --- Line 1: Sum of Powers (e.g., 2⁷ + 2⁵ + 2⁰) ---
    if active_powers:
        # Calculate total width dynamically to keep the equation perfectly centered
        total_eq_width = 0
        for idx, p in enumerate(active_powers):
            term_w = font_medium.render("2", True, COLOR_TEXT).get_width() + font_super.render(str(p), True, COLOR_TEXT).get_width() + 4
            plus_w = font_medium.render(" + ", True, COLOR_TEXT).get_width() if idx < len(active_powers) - 1 else 0
            total_eq_width += term_w + plus_w
            
        current_eq_x = (WINDOW_WIDTH - total_eq_width) // 2
        for idx, p in enumerate(active_powers):
            added_w = draw_superscript_text(screen, "2", str(p), current_eq_x, row_start_y, font_medium, font_super, COLOR_TEXT)
            current_eq_x += added_w
            if idx < len(active_powers) - 1:
                plus_surf = font_medium.render(" + ", True, COLOR_TEXT)
                screen.blit(plus_surf, (current_eq_x, row_start_y))
                current_eq_x += plus_surf.get_width()
    else:
        # Zero condition handling
        zero_surf = font_medium.render("0", True, COLOR_TEXT)
        screen.blit(zero_surf, zero_surf.get_rect(center=(WINDOW_WIDTH // 2, row_start_y)))

    # --- Line 2: Sum of Computed Values (e.g., 128 + 32 + 1) ---
    computed_str = " + ".join([str(2**p) for p in active_powers]) if active_powers else "0"
    comp_surface = font_medium.render(computed_str, True, COLOR_TEXT)
    comp_rect = comp_surface.get_rect(center=(WINDOW_WIDTH // 2, row_start_y + line_spacing))
    screen.blit(comp_surface, comp_rect)

    # --- Line 3: Final Computed Decimal Total ---
    dec_surface = font_giant.render(str(counter), True, COLOR_DECIMAL)
    dec_rect = dec_surface.get_rect(center=(WINDOW_WIDTH // 2, row_start_y + (line_spacing * 2) + 20))
    screen.blit(dec_surface, dec_rect)

    # 7. Paused/Active Overlay Hint Indicators
    if is_paused:
        status_surface = font_small.render("[ PAUSED ]  Use ◀ or ▶ to step manually  •  SPACE to resume", True, COLOR_MUTED)
    else:
        status_surface = font_small.render("Running...  [ SPACE ] to pause  •  [ ESC ] to exit", True, COLOR_BORDER if (counter % 2 == 0) else COLOR_MUTED)
    status_rect = status_surface.get_rect(center=(WINDOW_WIDTH // 2, WINDOW_HEIGHT - 50))
    screen.blit(status_surface, status_rect)

    # 8. Frame Sync Refresh
    pygame.display.flip()
    clock.tick(60)

# Graceful system exit closure
pygame.quit()
sys.exit()
