import pygame
import sys

pygame.init()

WIDTH, HEIGHT = 1000, 400
screen = pygame.display.set_mode((WIDTH, HEIGHT))
clock = pygame.time.Clock()

BACKGROUND = (30, 30, 30)
TEXT_COLOR = (240, 240, 240)
PLUS_COLOR = (255, 100, 100)
FONT = pygame.font.SysFont("calibri", 60, bold=True)

start_x = 70
spacing = 120

'''
|              width1                           width2
|  (center1 + --------) + (center1 + spacing - --------)
|                 2                                2
| -------------------------------------------------------
|                        2


|            spacing     width1 - width2
| center1 + --------- + -----------------
|               2              4



'''

def draw_row_of_numbers(numbers, y_position):
    surfaces = [FONT.render(str(num), True, TEXT_COLOR) for num in numbers]
    widths = [surf.get_width() for surf in surfaces]

    for i in range(8):
        num_center_x = start_x + (i * spacing)
        
        num_rect = surfaces[i].get_rect(center=(num_center_x, y_position))
        screen.blit(surfaces[i], num_rect)

        if i < 7:
            plus_center_x = num_center_x + (spacing // 2) + (widths[i] - widths[i + 1]) // 4
            
            plus_surf = FONT.render("+", True, PLUS_COLOR)
            plus_rect = plus_surf.get_rect(center=(plus_center_x, y_position))
            screen.blit(plus_surf, plus_rect)

row_1 = [7, 256, 12, 8, 512, 3, 99, 4]
row_2 = [128, 7, 55, 128, 7, 6, 312, 81]
row_3 = [9, 5, 124, 7, 256, 8, 1, 555]

while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()

    screen.fill(BACKGROUND)

    draw_row_of_numbers(row_1, y_position=100)
    draw_row_of_numbers(row_2, y_position=200)
    draw_row_of_numbers(row_3, y_position=300)

    pygame.display.flip()
    clock.tick(60)
