import sys
import pygame

pygame.init()

screen = pygame.display.set_mode((0, 0), pygame.NOFRAME)
WINDOW_WIDTH, WINDOW_HEIGHT = screen.get_size()
print(WINDOW_WIDTH, WINDOW_HEIGHT)
clock = pygame.time.Clock()

COLOR_BG       = pygame.Color("black")
COLOR_BIT_ON   = pygame.Color("mediumseagreen")
COLOR_BIT_OFF  = pygame.Color("darkslategray")
COLOR_TEXT     = pygame.Color("whitesmoke")
COLOR_TEXT_DIM = pygame.Color("slategrey")
COLOR_HEX      = pygame.Color("mediumorchid")
COLOR_DECIMAL  = pygame.Color("pink")
COLOR_BORDER   = pygame.Color("white")

BIT_WIDTH = 110
BIT_HEIGHT = 110
BIT_SPACING = 25

total_width = (BIT_WIDTH * 8) + (BIT_SPACING * 7)
start_x = (WINDOW_WIDTH - total_width) // 2

center_y = WINDOW_HEIGHT // 2

row_hex = center_y - 250
row_powers = center_y - 130
row_bits = center_y - (BIT_HEIGHT // 2)
row_sum = center_y + 130
row_dec = center_y + 250

bit_centers = []
for i in range(8):
    x_pos = start_x + i * (BIT_WIDTH + BIT_SPACING)
    bit_centers.append(x_pos + BIT_WIDTH // 2)

font_giant = pygame.font.SysFont("calibri", 110, bold=True)
font_large = pygame.font.SysFont("calibri", 70, bold=True)
font_math_large = pygame.font.SysFont("calibri", 52, bold=True)
font_super_large = pygame.font.SysFont("calibri", 32, bold=True)
font_medium = pygame.font.SysFont("calibri", 60, bold=True)

counter = 150
MAX_VALUE = 255
is_paused = False

TIMER_EVENT = pygame.USEREVENT + 1
pygame.time.set_timer(TIMER_EVENT, 1000)

def draw_power_of_two(power, center_x, y, color):
    base_surf = font_math_large.render("2", True, color)
    super_surf = font_super_large.render(power, True, color)
    
    total_w = base_surf.get_width() + super_surf.get_width() + 2
    start_x = center_x - (total_w // 2)
    
    screen.blit(base_surf, (start_x, y))
    screen.blit(super_surf, (start_x + base_surf.get_width() + 2, y - 10))

running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                running = False
            elif event.key == pygame.K_SPACE:
                is_paused = not is_paused
            elif event.key == pygame.K_DOWN:
                if is_paused and counter > 0:
                    counter -= 1
            elif event.key == pygame.K_UP:
                if is_paused and counter < MAX_VALUE:
                    counter += 1
        elif event.type == TIMER_EVENT:
            if not is_paused:
                if counter < MAX_VALUE:
                    counter += 1
                else:
                    running = False

    screen.fill(COLOR_BG)

    hex_str = f"{counter:02X}"

    hex_surface = font_giant.render(hex_str[0], True, COLOR_HEX)
    hex_rect = hex_surface.get_rect()
    hex_rect.centerx = int(WINDOW_WIDTH // 2 - hex_rect.width * 0.55)
    hex_rect.centery = row_hex
    screen.blit(hex_surface, hex_rect)

    hex_surface = font_giant.render(hex_str[1], True, COLOR_HEX)
    hex_rect = hex_surface.get_rect()
    hex_rect.centerx = int(WINDOW_WIDTH // 2 + hex_rect.width * 0.55)
    hex_rect.centery = row_hex
    screen.blit(hex_surface, hex_rect)

    binary_str = f"{counter:08b}"
    for i in range(8):
        bit_val = binary_str[i]
        x_pos = start_x + i * (BIT_WIDTH + BIT_SPACING)
        
        box_color = COLOR_BIT_ON if bit_val == '1' else COLOR_BIT_OFF
        rect = pygame.Rect(x_pos, row_bits, BIT_WIDTH, BIT_HEIGHT)
        
        pygame.draw.rect(screen, box_color, rect, border_radius=12)
        pygame.draw.rect(screen, COLOR_BORDER, rect, width=3, border_radius=12)
        
        char_surface = font_large.render(bit_val, True, COLOR_TEXT)
        char_rect = char_surface.get_rect(center=rect.center)
        screen.blit(char_surface, char_rect)

    for i in range(8):
        draw_power_of_two(str(7 - i), bit_centers[i], row_powers, COLOR_TEXT)

    for i in range(8):
        bit_active = (binary_str[i] == '1')
        value_str = str(2 ** (7 - i)) if bit_active else "0"
        
        val_surf = font_medium.render(value_str, True, COLOR_TEXT)
        val_rect = val_surf.get_rect(center=(bit_centers[i], row_sum))
        screen.blit(val_surf, val_rect)
        
        if i < 7:
            plus_surf = font_medium.render("+", True, COLOR_TEXT)
            mid_x = (bit_centers[i] + bit_centers[i+1]) // 2
            plus_rect = plus_surf.get_rect(center=(mid_x, row_sum))
            screen.blit(plus_surf, plus_rect)

    dec_surface = font_giant.render(str(counter), True, COLOR_DECIMAL)
    dec_rect = dec_surface.get_rect(center=(WINDOW_WIDTH // 2, row_dec))
    screen.blit(dec_surface, dec_rect)

    pygame.display.flip()
    clock.tick(60)
