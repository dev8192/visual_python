import sys
import pygame

# Initialize Pygame
pygame.init()

# --- Configuration & Constants ---
WINDOW_WIDTH = 800
WINDOW_HEIGHT = 400
FPS = 60

# Colors
COLOR_BG = (20, 24, 33)          # Dark sleek background
COLOR_BIT_ON = (46, 204, 113)     # Vibrant Green for '1'
COLOR_BIT_OFF = (52, 73, 94)      # Muted Blue-Gray for '0'
COLOR_TEXT = (236, 240, 241)     # White for labels
COLOR_ACCENT = (241, 196, 15)     # Yellow for decimal tracker
COLOR_BORDER = (44, 62, 80)

# Bit box layout
BIT_WIDTH = 60
BIT_HEIGHT = 80
BIT_SPACING = 15
TOTAL_BITS_WIDTH = (BIT_WIDTH * 8) + (BIT_SPACING * 7)
START_X = (WINDOW_WIDTH - TOTAL_BITS_WIDTH) // 2
START_Y = 120

# Set up display
screen = pygame.display.set_with = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
pygame.display.set_caption("Byte & Binary Counter Visualization")
clock = pygame.time.Clock()

# Fonts
try:
    font_large = pygame.font.SysFont("monospace", 50, bold=True)
    font_medium = pygame.font.SysFont("monospace", 32, bold=True)
    font_small = pygame.font.SysFont("sans-serif", 20)
except:
    font_large = pygame.font.Font(None, 60)
    font_medium = pygame.font.Font(None, 40)
    font_small = pygame.font.Font(None, 24)

# Counter variables
counter = 0
MAX_VALUE = 255  # 11111111 in binary

# Timer configuration (1000 milliseconds = 1 second)
INCREMENT_EVENT = pygame.USEREVENT + 1
pygame.time.set_timer(INCREMENT_EVENT, 1000)

# --- Main Game Loop ---
running = True
while running:
    # 1. Handle Events
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
            
        elif event.type == INCREMENT_EVENT:
            if counter < MAX_VALUE:
                counter += 1
            else:
                # Terminate when 11111111 (255) is reached
                print("Reached 11111111! Program terminating safely.")
                running = False

    # 2. Background Fill
    screen.fill(COLOR_BG)

    # 3. Calculate Binary Representation
    # Formats the counter into an 8-character wide binary string padded with zeros
    binary_str = f"{counter:08b}"

    # 4. Draw the 8 Visual Bits
    for i in range(8):
        bit_val = binary_str[i]
        
        # Determine bit box position
        x_pos = START_X + i * (BIT_WIDTH + BIT_SPACING)
        y_pos = START_Y
        
        # Choose color based on bit state (0 or 1)
        box_color = COLOR_BIT_ON if bit_val == '1' else COLOR_BIT_OFF
        
        # Draw bit box background
        rect = pygame.Rect(x_pos, y_pos, BIT_WIDTH, BIT_HEIGHT)
        pygame.draw.rect(screen, box_color, rect, border_radius=8)
        pygame.draw.rect(screen, COLOR_BORDER, rect, width=2, border_radius=8)
        
        # Render the '0' or '1' text inside the box
        bit_text = font_large.render(bit_val, True, COLOR_TEXT)
        text_rect = bit_text.get_rect(center=rect.center)
        screen.blit(bit_text, text_rect)
        
        # Draw bit index/place value helper above the box (2^7 down to 2^0)
        place_value = str(2 ** (7 - i))
        pv_text = font_small.render(f"2^{7-i}", True, COLOR_BIT_OFF if bit_val == '0' else COLOR_ACCENT)
        pv_rect = pv_text.get_rect(center=(x_pos + BIT_WIDTH // 2, y_pos - 25))
        screen.blit(pv_text, pv_rect)

    # 5. Draw the Summary Text (Binary & Decimal side-by-side)
    summary_string = f"Binary: {binary_str}   |   Decimal: {counter}"
    summary_surface = font_medium.render(summary_string, True, COLOR_TEXT)
    summary_rect = summary_surface.get_rect(center=(WINDOW_WIDTH // 2, START_Y + BIT_HEIGHT + 80))
    screen.blit(summary_surface, summary_rect)

    # 6. Update Screen & Tick Clock
    pygame.display.flip()
    clock.tick(FPS)

# Clean up and exit
pygame.quit()
sys.exit()
