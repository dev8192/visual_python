
def main():
    print("main1")
    print(1000 / 30)
    print(1000 / 60)

main()
