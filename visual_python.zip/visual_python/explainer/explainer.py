
def main1():
    print("main1")
    print(1000 / 30)
    print(1000 / 60)

def main():
    for col in range(32):
        print(col, (col - 3) % 26)

main()
