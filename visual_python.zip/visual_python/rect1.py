import pygame
import sys

pygame.init()

screen = pygame.display.set_mode((600, 400))

WHITE = (255, 255, 255)
SKY_BLUE = (0, 128, 255)
DARK_BLUE = (0, 0, 150)

gap = 20
border_width = 5

rect1 = pygame.Rect(50, 50, 100, 100)

rect2 = rect1.copy()
rect2.move_ip(rect1.width + gap, 0)

rect3 = rect2.move(rect2.width + gap, 0)

rect4 = rect3.copy()
rect4.move_ip(rect1.width + gap, 0)

inflation = -(border_width * 2 + 2)
rect5 = rect4.inflate(inflation, inflation)

while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()

    screen.fill(WHITE)

    pygame.draw.rect(screen, DARK_BLUE, rect1, width=border_width)

    pygame.draw.rect(screen, DARK_BLUE, rect2)
    
    pygame.draw.rect(screen, SKY_BLUE, rect3)
    pygame.draw.rect(screen, DARK_BLUE, rect3, width=border_width)
    
    pygame.draw.rect(screen, SKY_BLUE, rect5)
    pygame.draw.rect(screen, DARK_BLUE, rect4, width=border_width)

    pygame.display.flip()
