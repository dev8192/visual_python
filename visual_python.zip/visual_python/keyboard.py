import pygame

pygame.init()

screen = pygame.display.set_mode((0, 0), pygame.NOFRAME)
WIDTH, HEIGHT = screen.get_size()

COLOR_BG = pygame.Color("gray10")
COLOR_KEY = pygame.Color("gray20")
COLOR_TEXT = pygame.Color("whitesmoke")
COLOR_ACTIVE = pygame.Color("cyan3")
COLOR_BORDER = pygame.Color("gray30")

KEYBOARD_LAYOUT = [
    {"keys": [
        (pygame.K_BACKQUOTE, "`", 1), (pygame.K_1, "1", 1), (pygame.K_2, "2", 1), 
        (pygame.K_3, "3", 1), (pygame.K_4, "4", 1), (pygame.K_5, "5", 1), 
        (pygame.K_6, "6", 1), (pygame.K_7, "7", 1), (pygame.K_8, "8", 1), 
        (pygame.K_9, "9", 1), (pygame.K_0, "0", 1), (pygame.K_MINUS, "-", 1), 
        (pygame.K_EQUALS, "=", 1), (pygame.K_BACKSPACE, "Backspace", 2)
    ]},
    {"keys": [
        (pygame.K_TAB, "Tab", 1.5), (pygame.K_q, "Q", 1), (pygame.K_w, "W", 1), 
        (pygame.K_e, "E", 1), (pygame.K_r, "R", 1), (pygame.K_t, "T", 1), 
        (pygame.K_y, "Y", 1), (pygame.K_u, "U", 1), (pygame.K_i, "I", 1), 
        (pygame.K_o, "O", 1), (pygame.K_p, "P", 1), (pygame.K_LEFTBRACKET, "[", 1), 
        (pygame.K_RIGHTBRACKET, "]", 1), (pygame.K_BACKSLASH, "\\", 1.5)
    ]},
    {"keys": [
        (pygame.K_CAPSLOCK, "Caps", 1.8), (pygame.K_a, "A", 1), (pygame.K_s, "S", 1), 
        (pygame.K_d, "D", 1), (pygame.K_f, "F", 1), (pygame.K_g, "G", 1), 
        (pygame.K_h, "H", 1), (pygame.K_j, "J", 1), (pygame.K_k, "K", 1), 
        (pygame.K_l, "L", 1), (pygame.K_SEMICOLON, ";", 1), (pygame.K_QUOTE, "'", 1), 
        (pygame.K_RETURN, "Enter", 2.2)
    ]},
    {"keys": [
        (pygame.K_LSHIFT, "Shift", 2.4), (pygame.K_z, "Z", 1), (pygame.K_x, "X", 1), 
        (pygame.K_c, "C", 1), (pygame.K_v, "V", 1), (pygame.K_b, "B", 1), 
        (pygame.K_n, "N", 1), (pygame.K_m, "M", 1), (pygame.K_COMMA, ",", 1), 
        (pygame.K_PERIOD, ".", 1), (pygame.K_SLASH, "/", 1), (pygame.K_RSHIFT, "Shift", 2.6)
    ]},
    {"keys": [
        (pygame.K_LCTRL, "Ctrl", 1.25), (pygame.K_LSUPER, "Win", 1.25), (pygame.K_LALT, "Alt", 1.25), 
        (pygame.K_SPACE, "Space", 6.25), 
        (pygame.K_RALT, "Alt", 1.25), (pygame.K_RSUPER, "Win", 1.25), (pygame.K_MENU, "Menu", 1.25), 
        (pygame.K_RCTRL, "Ctrl", 1.25)
    ]}
]

NAV_LAYOUT = [
    (pygame.K_INSERT, "Ins"), (pygame.K_HOME, "Home"), (pygame.K_PAGEUP, "PgUp"),
    (pygame.K_DELETE, "Del"), (pygame.K_END, "End"), (pygame.K_PAGEDOWN, "PgDn")
]

ARROW_LAYOUT = [
    (pygame.K_UP, "↑"),
    (pygame.K_LEFT, "←"), (pygame.K_DOWN, "↓"), (pygame.K_RIGHT, "→")
]

BASE_UNIT = WIDTH // 24
KEY_GAP = 6
FONT_SIZE = int(BASE_UNIT * 0.3)
FONT = pygame.font.SysFont("Arial", FONT_SIZE, bold=True)

TOTAL_ALPHA_WIDTH = 15 * BASE_UNIT + 14 * KEY_GAP
TOTAL_KEYBOARD_WIDTH = TOTAL_ALPHA_WIDTH + (4 * BASE_UNIT)
START_X = (WIDTH - TOTAL_KEYBOARD_WIDTH) // 2
START_Y = (HEIGHT - (5 * BASE_UNIT + 4 * KEY_GAP)) // 2

def draw_key(screen, rect, label, is_active):
    color = COLOR_ACTIVE if is_active else COLOR_KEY
    pygame.draw.rect(screen, color, rect, border_radius=6)
    pygame.draw.rect(screen, COLOR_BORDER, rect, width=2, border_radius=6)
    
    # Render label text
    text_surf = FONT.render(label, True, COLOR_TEXT)
    text_rect = text_surf.get_rect(center=rect.center)
    screen.blit(text_surf, text_rect)

clock = pygame.time.Clock()
running = True

while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:  # Quick exit via Escape key
                running = False

    pressed_keys = pygame.key.get_pressed()

    screen.fill(COLOR_BG)

    current_y = START_Y
    for row in KEYBOARD_LAYOUT:
        current_x = START_X
        for key_code, label, width_mult in row["keys"]:
            key_width = int(BASE_UNIT * width_mult)
            key_rect = pygame.Rect(current_x, current_y, key_width, BASE_UNIT)
            
            is_pressed = pressed_keys[key_code] if key_code < len(pressed_keys) else False
            draw_key(screen, key_rect, label, is_pressed)
            
            current_x += key_width + KEY_GAP
        current_y += BASE_UNIT + KEY_GAP

    nav_start_x = START_X + TOTAL_ALPHA_WIDTH + BASE_UNIT // 2
    for i, (key_code, label) in enumerate(NAV_LAYOUT):
        row = i // 3
        col = i % 3
        x = nav_start_x + col * (BASE_UNIT + KEY_GAP)
        y = START_Y + row * (BASE_UNIT + KEY_GAP)
        
        key_rect = pygame.Rect(x, y, BASE_UNIT, BASE_UNIT)
        is_pressed = pressed_keys[key_code]
        draw_key(screen, key_rect, label, is_pressed)

    arrow_start_x = nav_start_x
    arrow_start_y = START_Y + 3 * (BASE_UNIT + KEY_GAP) # Placed on rows 4 and 5
    
    up_rect = pygame.Rect(arrow_start_x + (BASE_UNIT + KEY_GAP), arrow_start_y, BASE_UNIT, BASE_UNIT)
    draw_key(screen, up_rect, ARROW_LAYOUT[0][1], pressed_keys[ARROW_LAYOUT[0][0]])
    
    for col, (key_code, label) in enumerate(ARROW_LAYOUT[1:]):
        x = arrow_start_x + col * (BASE_UNIT + KEY_GAP)
        y = arrow_start_y + BASE_UNIT + KEY_GAP
        key_rect = pygame.Rect(x, y, BASE_UNIT, BASE_UNIT)
        draw_key(screen, key_rect, label, pressed_keys[key_code])

    pygame.display.flip()
    clock.tick(60)
