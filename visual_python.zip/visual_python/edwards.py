import pygame
import sys
import math

# Initialize Pygame
pygame.init()
pygame.font.init()

# Window Setup
WIDTH, HEIGHT = 900, 900
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Ed25519 Edwards Curve Visualization")
clock = pygame.time.Clock()
FONT = pygame.font.SysFont("Consolas", 20)

# Colors
COLOR_BG = (15, 15, 22)
COLOR_AXIS = (100, 100, 110)
COLOR_GRID = (40, 40, 50)
COLOR_CURVE = (0, 230, 180)
COLOR_TEXT = (240, 240, 250)

# Curve constant d for Ed25519
D = 121665 / 121666

# State Machine Configuration
# States: 0=Normal, 1=Pause1, 2=ZoomIn, 3=Pause2, 4=ZoomOut
STATE_NORMAL = 0
STATE_PAUSE1 = 1
STATE_ZOOM_IN = 2
STATE_PAUSE2 = 3
STATE_ZOOM_OUT = 4

current_state = STATE_NORMAL
state_timer = 0.0  # Seconds spent in the current state

# Zoom Bounds Config
# At normal zoom, X and Y ranges are roughly [-1.5, 1.5]
X_BOUNDS_NORMAL = (-1.5, 1.5)
Y_BOUNDS_NORMAL = (-1.5, 1.5)

# Zoomed-in bounds (Heavy horizontal zoom near top to show curve variation)
X_BOUNDS_ZOOMED = (-0.005, 0.005)
Y_BOUNDS_ZOOMED = (0.9995, 1.0005)

# Current viewing window coordinates
current_x_min, current_x_max = X_BOUNDS_NORMAL
current_y_min, current_y_max = Y_BOUNDS_NORMAL


def get_screen_coords(x, y):
    """Convert math coordinates to screen pixel positions."""
    px = int(
        (x - current_x_min) / (current_x_max - current_x_min) * WIDTH
    )
    py = int(
        HEIGHT
        - (y - current_y_min) / (current_y_max - current_y_min) * HEIGHT
    )
    return px, py


def get_math_coords(px, py):
    """Convert screen pixel positions back to math coordinates."""
    x = current_x_min + (px / WIDTH) * (current_x_max - current_x_min)
    y = current_y_min + ((HEIGHT - py) / HEIGHT) * (
        current_y_max - current_y_min
    )
    return x, y


def draw_grid_and_axes():
    """Draws dynamic grid lines, axes, and corresponding value ticks based on current scale."""
    x_range = current_x_max - current_x_min
    y_range = current_y_max - current_y_min

    # Calculate optimal step sizes for grids based on range magnitude
    def get_grid_step(v_range):
        order = 10 ** math.floor(math.log10(v_range))
        normalized = v_range / order
        if normalized < 2:
            return order * 0.2
        elif normalized < 5:
            return order * 0.5
        else:
            return order

    x_step = get_grid_step(x_range)
    y_step = get_grid_step(y_range)

    # Calculate starting grid positions
    x_start = math.ceil(current_x_min / x_step) * x_step
    y_start = math.ceil(current_y_min / y_step) * y_step

    # Draw vertical grid lines & X-ticks
    x_val = x_start
    while x_val <= current_x_max:
        px, _ = get_screen_coords(x_val, 0)
        if 0 <= px <= WIDTH:
            pygame.draw.line(screen, COLOR_GRID, (px, 0), (px, HEIGHT), 1)
            # Label
            lbl = FONT.render(f"{x_val:.4f}", True, COLOR_AXIS)
            screen.blit(lbl, (px + 4, HEIGHT - 25))
        x_val += x_step

    # Draw horizontal grid lines & Y-ticks
    y_val = y_start
    while y_val <= current_y_max:
        _, py = get_screen_coords(0, y_val)
        if 0 <= py <= HEIGHT:
            pygame.draw.line(screen, COLOR_GRID, (0, py), (WIDTH, py), 1)
            # Label
            lbl = FONT.render(f"{y_val:.4f}", True, COLOR_AXIS)
            screen.blit(lbl, (10, py - 22))
        y_val += y_step

    # Draw Primary X and Y axes if visible
    ax_x, ax_y = get_screen_coords(0, 0)
    if 0 <= ax_x <= WIDTH:
        pygame.draw.line(screen, COLOR_AXIS, (ax_x, 0), (ax_x, HEIGHT), 2)
    if 0 <= ax_y <= HEIGHT:
        pygame.draw.line(screen, COLOR_AXIS, (0, ax_y), (WIDTH, ax_y), 2)


def draw_edwards_curve():
    """Renders the Ed25519 curve by solving the formula directly across screen columns."""
    points = []

    # Sample explicitly per screen column to handle crazy slope variations during zooming
    for px in range(0, WIDTH, 2):
        x, _ = get_math_coords(px, 0)

        # Formula: -x^2 + y^2 = 1 - d * x^2 * y^2
        # Rearranging to solve for y^2:
        # y^2 * (1 + d * x^2) = 1 + x^2
        # y^2 = (1 + x^2) / (1 + d * x^2)
        numerator = 1 + x**2
        denominator = 1 + D * x**2

        if denominator != 0:
            y2 = numerator / denominator
            if y2 >= 0:
                y_pos = math.sqrt(y2)
                y_neg = -y_pos

                # Check and add positive solution
                if current_y_min <= y_pos <= current_y_max:
                    points.append(get_screen_coords(x, y_pos))
                # Check and add negative solution
                if current_y_min <= y_neg <= current_y_max:
                    points.append(get_screen_coords(x, y_neg))

    # Draw points as small pixel segments or circles
    for pt in points:
        if 0 <= pt[0] <= WIDTH and 0 <= pt[1] <= HEIGHT:
            pygame.draw.circle(screen, COLOR_CURVE, pt, 2)


def draw_info_panel():
    """Displays scale, state metrics, and current bounds in the top left corner."""
    x_span = current_x_max - current_x_min
    y_span = current_y_max - current_y_min

    lines = [
        "--- Ed25519 Curve Scale Info ---",
        f"Curve Eq: -x² + y² = 1 - (121665/121666)x²y²",
        f"X-Axis Span: {x_span:.6f}",
        f"Y-Axis Span: {y_span:.6f}",
        f"Current State: {['Normal Vista', 'Holding...', 'Zooming In...', 'Holding...', 'Zooming Out...'][current_state]}",
    ]

    for i, line in enumerate(lines):
        text_surface = FONT.render(line, True, COLOR_TEXT)
        screen.blit(text_surface, (20, 20 + i * 25))


# --- Main Loop ---
running = True
while running:
    # Handle Delta Time
    dt = clock.tick(60) / 1000.0  # Convert milliseconds to seconds
    state_timer += dt

    # Handle Events
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    # State Transitions and Zoom Interpolations
    if current_state == STATE_NORMAL:
        current_x_min, current_x_max = X_BOUNDS_NORMAL
        current_y_min, current_y_max = Y_BOUNDS_NORMAL
        if state_timer >= 2.0:  # Stay at normal zoom for 2 seconds initially
            current_state = STATE_PAUSE1
            state_timer = 0.0

    elif current_state == STATE_PAUSE1:
        if state_timer >= 1.0:  # 1-second pause
            current_state = STATE_ZOOM_IN
            state_timer = 0.0

    elif current_state == STATE_ZOOM_IN:
        # Interpolation progress factor (0.0 to 1.0 over 2 seconds)
        t = min(state_timer / 2.0, 1.0)
        # Using a smooth sine easing profile for realistic acceleration
        ease_t = math.sin(t * math.pi / 2)

        current_x_min = (
            X_BOUNDS_NORMAL[0] + (X_BOUNDS_ZOOMED[0] - X_BOUNDS_NORMAL[0]) * ease_t
        )
        current_x_max = (
            X_BOUNDS_NORMAL[1] + (X_BOUNDS_ZOOMED[1] - X_BOUNDS_NORMAL[1]) * ease_t
        )
        current_y_min = (
            Y_BOUNDS_NORMAL[0] + (Y_BOUNDS_ZOOMED[0] - Y_BOUNDS_NORMAL[0]) * ease_t
        )
        current_y_max = (
            Y_BOUNDS_NORMAL[1] + (Y_BOUNDS_ZOOMED[1] - Y_BOUNDS_NORMAL[1]) * ease_t
        )

        if t >= 1.0:
            current_state = STATE_PAUSE2
            state_timer = 0.0

    elif current_state == STATE_PAUSE2:
        if state_timer >= 1.0:  # 1-second pause
            current_state = STATE_ZOOM_OUT
            state_timer = 0.0

    elif current_state == STATE_ZOOM_OUT:
        # Interpolation progress factor (0.0 to 1.0 over 2 seconds)
        t = min(state_timer / 2.0, 1.0)
        ease_t = math.sin(t * math.pi / 2)

        current_x_min = (
            X_BOUNDS_ZOOMED[0] + (X_BOUNDS_NORMAL[0] - X_BOUNDS_ZOOMED[0]) * ease_t
        )
        current_x_max = (
            X_BOUNDS_ZOOMED[1] + (X_BOUNDS_NORMAL[1] - X_BOUNDS_ZOOMED[1]) * ease_t
        )
        current_y_min = (
            Y_BOUNDS_ZOOMED[0] + (Y_BOUNDS_NORMAL[0] - Y_BOUNDS_ZOOMED[0]) * ease_t
        )
        current_y_max = (
            Y_BOUNDS_ZOOMED[1] + (Y_BOUNDS_NORMAL[1] - Y_BOUNDS_ZOOMED[1]) * ease_t
        )

        if t >= 1.0:
            current_state = STATE_NORMAL
            state_timer = 0.0

    # Rendering Pipeline
    screen.fill(COLOR_BG)
    draw_grid_and_axes()
    draw_edwards_curve()
    draw_info_panel()

    pygame.display.flip()

pygame.quit()
sys.exit()
