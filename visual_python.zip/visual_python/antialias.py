import os
import sys
os.environ['PYGAME_HIDE_SUPPORT_PROMPT'] = "1"
import pygame

pygame.init()
pygame.font.init()

screen = pygame.display.set_mode((0, 0), pygame.NOFRAME)
# pygame.mouse.set_visible(False)

width, height = screen.get_size()

BG_COLOR  = (20, 20, 25)
TEXT_COLOR = (255, 255, 255)
LABEL_COLOR = (150, 150, 160)

font = pygame.font.SysFont("Georgia", 90)
label_font = pygame.font.SysFont("Consolas", 24)

# Syntax: font.render(text, antialias, color)
no_aa_surface = font.render("Abc 123", False, TEXT_COLOR)
no_aa_label = label_font.render("[ Anti-Aliasing: OFF ]", True, LABEL_COLOR)
with_aa_surface = font.render("Abc 123", True, TEXT_COLOR)
with_aa_label = label_font.render("[ Anti-Aliasing: ON ]", True, LABEL_COLOR)

clock = pygame.time.Clock()
running = True

while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                running = False

    screen.fill(BG_COLOR)

    left_column_x = width // 4
    right_column_x = (width * 3) // 4
    center_y = height // 2

    no_aa_rect = no_aa_surface.get_rect(center=(left_column_x, center_y))
    no_aa_label_rect = no_aa_label.get_rect(center=(left_column_x, center_y - 100))
    screen.blit(no_aa_surface, no_aa_rect)
    screen.blit(no_aa_label, no_aa_label_rect)

    with_aa_rect = with_aa_surface.get_rect(center=(right_column_x, center_y))
    with_aa_label_rect = with_aa_label.get_rect(center=(right_column_x, center_y - 100))
    screen.blit(with_aa_surface, with_aa_rect)
    screen.blit(with_aa_label, with_aa_label_rect)

    pygame.display.flip()
    clock.tick(60)

pygame.quit()
sys.exit()
