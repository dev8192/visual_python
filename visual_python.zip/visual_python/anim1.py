import sys
import pygame

# Initialize Pygame
pygame.init()

# Setup full screen window
screen = pygame.display.set_mode((0, 0), pygame.NOFRAME)
pygame.display.set_caption("Color Circle Animation")

# Hide the mouse cursor for a cleaner presentation
pygame.mouse.set_visible(False)

# Get screen center and dimensions for a responsive circle radius
width, height = screen.get_size()
center = (width // 2, height // 2)
radius = min(width, height) // 6

# Colors (RGB)
BG_COLOR = (50, 50, 50)     # Greyish background
RED = (255, 50, 50)
GREEN = (50, 255, 50)
BLUE = (50, 50, 255)

# Clock to control frame rate and track time
clock = pygame.time.Clock()
FPS = 60

# Main loop flag
running = True

while running:
    # 1. Handle Events (allows quitting with the 'Escape' key)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                running = False

    # 2. Get elapsed time in milliseconds
    ticks = pygame.time.get_ticks()

    # 3. Fill the background
    screen.fill(BG_COLOR)

    # 4. Animation Timeline Logic (Total 5 seconds / 5000 milliseconds)
    # Divide the timeline into 4 equal segments of 1.25 seconds (1250 ms) each
    if ticks < 1250:
        # 0.0s to 1.25s: Empty grey background (do nothing)
        pass
    elif ticks < 2500:
        # 1.25s to 2.5s: Red circle
        pygame.draw.circle(screen, RED, center, radius)
    elif ticks < 3750:
        # 2.5s to 3.75s: Green circle
        pygame.draw.circle(screen, GREEN, center, radius)
    elif ticks < 5000:
        # 3.75s to 5.0s: Blue circle
        pygame.draw.circle(screen, BLUE, center, radius)
    else:
        # After 5.0s: Nothing happens (just the grey background remains)
        pass

    # 5. Update the display
    pygame.display.flip()
    clock.tick(FPS)

# Clean up and exit
pygame.quit()
sys.exit()
