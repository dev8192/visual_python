# not responding

import pygame

# 2. Open the Window Canvas
screen = pygame.display.set_mode((600, 400))
pygame.display.set_caption("Simple Static Rect")

# 3. Clear Screen and Draw the Rectangle Once
screen.fill((255, 255, 255))                             # White background
pygame.draw.rect(screen, (0, 128, 255), (100, 100, 400, 200)) # Blue rect
pygame.display.flip()                                    # Push to graphics card

# 4. Freeze the program here so the window stays open
input("Press ENTER in PowerShell to close the window...")
