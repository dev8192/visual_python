import pygame
import sys
import random

# Initialize Pygame
pygame.init()
pygame.font.init()

# Window Configuration
WIDTH, HEIGHT = 900, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Insertion Sort Visualizer")
clock = pygame.time.Clock()
FONT = pygame.font.SysFont("Arial", 16)
TITLE_FONT = pygame.font.SysFont("Arial", 20, bold=True)

# Colors
BACKGROUND = (245, 247, 250)
BAR_DEFAULT = (74, 144, 226)       # Soft blue
BAR_SORTED = (46, 204, 113)        # Green
BAR_ACTIVE = (231, 76, 60)         # Red (the element being inserted)
BAR_SHIFTING = (241, 196, 15)      # Yellow (elements shifting over)
TEXT_COLOR = (44, 62, 80)
UI_COLOR = (127, 140, 141)

# Generate Random Data
NUM_ELEMENTS = 12
ARRAY_DATA = [random.randint(10, 99) for _ in range(NUM_ELEMENTS)]

def precompute_insertion_sort_states(initial_arr):
    """
    Precomputes every sub-step of insertion sort so we can easily 
    traverse forwards and backwards through the states.
    """
    arr = list(initial_arr)
    # A state consists of: (current_array_copy, active_index, comparison_index, is_shifting_step)
    # State 0: Initial array, nothing active yet
    states = [{
        "arr": list(arr),
        "active_idx": -1,
        "compare_idx": -1,
        "shifting": False,
        "done": False
    }]
    
    for i in range(1, len(arr)):
        key = arr[i]
        j = i - 1
        
        # Highlight the key selected
        states.append({
            "arr": list(arr),
            "active_idx": i,
            "compare_idx": j,
            "shifting": False,
            "done": False
        })
        
        while j >= 0 and arr[j] > key:
            arr[j + 1] = arr[j]
            # State showing the shift happening
            states.append({
                "arr": list(arr),
                "active_idx": j + 1, # The key's theoretical position at this moment
                "compare_idx": j,
                "shifting": True,
                "done": False
            })
            j -= 1
            
        arr[j + 1] = key
        # State showing the insertion completed for this round
        states.append({
            "arr": list(arr),
            "active_idx": j + 1,
            "compare_idx": -1,
            "shifting": False,
            "done": False
        })
        
    # Final state: Sorted completely
    states.append({
        "arr": list(arr),
        "active_idx": -1,
        "compare_idx": -1,
        "shifting": False,
        "done": True
    })
    return states

# Precompute animation states
states = precompute_insertion_sort_states(ARRAY_DATA)
state_index = 0

# Animation Fade variables
fade_alpha = 255
fading_out = False
target_state_index = 0

def draw_bars(current_state, alpha=255):
    arr = current_state["arr"]
    active_idx = current_state["active_idx"]
    compare_idx = current_state["compare_idx"]
    is_shifting = current_state["shifting"]
    is_done = current_state["done"]
    
    # Layout configuration
    margin = 40
    available_width = WIDTH - (margin * 2)
    bar_width = available_width // NUM_ELEMENTS
    max_val = max(arr) if max(arr) > 0 else 100
    max_bar_height = 300
    
    base_y = HEIGHT - 150  # Alignment baseline for the bars
    
    for i, val in enumerate(arr):
        # Calculate dimensions
        bar_height = (val / max_val) * max_bar_height
        x = margin + (i * bar_width) + (bar_width // 4)
        y = base_y - bar_height
        w = bar_width // 2
        
        # Determine Color based on algorithm state
        if is_done:
            color = BAR_SORTED
        elif i == active_idx:
            color = BAR_ACTIVE
        elif is_shifting and i == compare_idx + 1:
            color = BAR_SHIFTING
        else:
            color = BAR_DEFAULT
            
        # Create a surface to apply alpha (fade effect)
        bar_surface = pygame.Surface((w, bar_height), pygame.SRCALPHA)
        
        # Apply custom fading to moving elements if a fade transition is active
        current_color_alpha = alpha
        if fading_out:
            # Fade out moving elements more aggressively to show departure
            if i == active_idx or (is_shifting and i == compare_idx + 1):
                current_color_alpha = max(0, alpha - 50)
                
        bar_surface.fill((*color, current_color_alpha))
        screen.blit(bar_surface, (x, y))
        
        # Draw Numbers below the bars
        num_text = FONT.render(str(val), True, TEXT_COLOR)
        text_rect = num_text.get_rect(center=(x + w // 2, base_y + 25))
        
        # Fade text surface along with the visual state
        if current_color_alpha != 255:
            text_surface = pygame.Surface(num_text.get_size(), pygame.SRCALPHA)
            text_surface.blit(num_text, (0, 0))
            text_surface.set_alpha(current_color_alpha)
            screen.blit(text_surface, text_rect.topleft)
        else:
            screen.blit(num_text, text_rect)

def draw_ui():
    # Title
    title = TITLE_FONT.render("Insertion Sort Step-by-Step", True, TEXT_COLOR)
    screen.blit(title, (40, 30))
    
    # Instructions
    controls = [
        "[SPACE] -> Next Step (Forward)",
        "[BACKSPACE] -> Previous Step (Backward)",
        f"Step: {state_index} / {len(states) - 1}"
    ]
    
    for idx, text in enumerate(controls):
        ui_text = FONT.render(text, True, UI_COLOR)
        screen.blit(ui_text, (40, 70 + (idx * 22)))

# Main Loop
running = True
while running:
    screen.fill(BACKGROUND)
    
    # Handle Fade Animations
    if fading_out:
        fade_alpha -= 35  # Adjust speed of fade out
        if fade_alpha <= 0:
            fade_alpha = 0
            fading_out = False
            state_index = target_state_index  # Commit the step change
    else:
        if fade_alpha < 255:
            fade_alpha += 35  # Adjust speed of fade in
            if fade_alpha > 255:
                fade_alpha = 255

    # Event Processing
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
            
        elif event.type == pygame.KEYDOWN and not fading_out and fade_alpha == 255:
            if event.key == pygame.K_SPACE:
                if state_index < len(states) - 1:
                    target_state_index = state_index + 1
                    fading_out = True
                    
            elif event.key == pygame.K_BACKSPACE:
                if state_index > 0:
                    target_state_index = state_index - 1
                    fading_out = True

    # Render Visuals
    draw_bars(states[state_index], alpha=fade_alpha)
    draw_ui()
    
    pygame.display.flip()
    clock.tick(60)

pygame.quit()
sys.exit()
