import random
import pygame

# Initialize Pygame
pygame.init()
pygame.font.init()

# --- Configuration & Styling ---
WINDOW_WIDTH = 900
WINDOW_HEIGHT = 650
FONT_SIZE = 22

# Uniform styling (No color-based partition sorting)
COLOR_BG = (248, 249, 250)         # Crisp light background
COLOR_BAR_NORMAL = (52, 73, 94)    # Uniform dark slate for all bars
COLOR_BAR_HIGHLIGHT = (231, 76, 60) # Crimson red only for the active key
COLOR_TEXT = (44, 62, 80)          # Dark text
COLOR_DIVIDER = (149, 165, 166)    # Gray partition line

screen = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
pygame.display.set_caption("Insertion Sort Step Visualizer")
font = pygame.font.SysFont("Arial", FONT_SIZE)
large_font = pygame.font.SysFont("Arial", 26, bold=True)

# --- Algorithmic Snapshot Generation ---
def generate_data(num_elements=12):
    return [random.randint(15, 95) for _ in range(num_elements)]

def capture_insertion_sort_steps(arr):
    """
    Traces insertion sort sequentially. 
    Captures exact structural shifts, item highlights, and text labels.
    """
    states = []
    current_arr = list(arr)
    n = len(current_arr)
    
    # Initial state
    states.append({
        "arr": list(current_arr),
        "highlight_idx": -1,
        "sorted_boundary": 0,
        "description": "Ready to begin. Element at index 0 is trivially sorted."
    })
    
    for i in range(1, n):
        key = current_arr[i]
        j = i - 1
        
        # Pick up element
        states.append({
            "arr": list(current_arr),
            "highlight_idx": i,
            "sorted_boundary": i,
            "description": f"Pick up key {key} at index {i} to find its position."
        })
        
        while j >= 0 and current_arr[j] > key:
            # Physical replacement movement tracking
            current_arr[j + 1] = current_arr[j]
            states.append({
                "arr": list(current_arr),
                "highlight_idx": j,  # Highlight where the shift is actively happening
                "sorted_boundary": i + 1,
                "description": f"Shift {current_arr[j]} right to index {j+1} because it's greater than {key}."
            })
            j -= 1
            
        # Place key back into position
        current_arr[j + 1] = key
        states.append({
            "arr": list(current_arr),
            "highlight_idx": j + 1,
            "sorted_boundary": i + 1,
            "description": f"Inserted key {key} into its correct spot at index {j + 1}."
        })
        
    states.append({
        "arr": list(current_arr),
        "highlight_idx": -1,
        "sorted_boundary": n,
        "description": "Sorting complete! All elements are organized."
    })
    return states

# --- Data Initialization ---
initial_data = generate_data(12)
all_states = capture_insertion_sort_steps(initial_data)
state_index = 0

# Fade Alpha Trackers
current_alpha = 255
fade_direction = 0  # -1 for fade out, 1 for fade in, 0 for idle
target_state_index = 0

# --- Core Drawing and Layout Function ---
def draw_screen(state_idx, alpha_val):
    screen.fill(COLOR_BG)
    
    # Extract current state data
    state = all_states[state_idx]
    arr = state["arr"]
    hl_idx = state["highlight_idx"]
    boundary = state["sorted_boundary"]
    desc = state["description"]
    
    # Top Interface Info
    ui_text = font.render(f"Step {state_idx + 1} / {len(all_states)}   |   [SPACE] Next   |   [BACKSPACE] Back   |   [R] Reset", True, COLOR_DIVIDER)
    screen.blit(ui_text, (30, 20))
    
    desc_text = large_font.render(desc, True, COLOR_TEXT)
    screen.blit(desc_text, (30, 60))
    
    # Visual Dimensions Layout
    num_elements = len(arr)
    padding_x = 40
    base_bar_width = 50
    gap = 12
    partition_gap = 35  # Extra physical separation distance
    max_height = 320
    base_y = WINDOW_HEIGHT - 120
    
    # Compute horizontal rendering positions factoring the visual structural gap
    x_positions = []
    current_x = padding_x
    
    for idx in range(num_elements):
        # Insert extra space after the sorted boundary limit to separate sections visually
        if idx == boundary and boundary > 0 and boundary < num_elements:
            current_x += partition_gap
            
            # Draw visual vertical divider line in the center of the gap
            line_x = current_x - (partition_gap // 2)
            pygame.draw.line(screen, COLOR_DIVIDER, (line_x, base_y - max_height - 20), (line_x, base_y + 60), 2)
            
            # Sub-labels for structural parts
            lbl_sorted = font.render("SORTED PARTITION", True, COLOR_DIVIDER)
            screen.blit(lbl_sorted, (padding_x, base_y + 45))
            lbl_unsorted = font.render("UNSORTED PARTITION", True, (127, 140, 141))
            screen.blit(lbl_unsorted, (line_x + 15, base_y + 45))
            
        x_positions.append(current_x)
        current_x += base_bar_width + gap

    # Render Bars & Numbers Below Them
    for idx, val in enumerate(arr):
        x = x_positions[idx]
        bar_h = int((val / 100) * max_height)
        y = base_y - bar_h
        
        # Determine Color Context
        is_highlighted = (idx == hl_idx)
        bar_color = COLOR_BAR_HIGHLIGHT if is_highlighted else COLOR_BAR_NORMAL
        
        # Create surfaces supporting transparency alpha blending
        bar_surface = pygame.Surface((base_bar_width, bar_h), pygame.SRCALPHA)
        num_surface = pygame.Surface((base_bar_width, 30), pygame.SRCALPHA)
        
        # Apply local alpha for fade execution if this element is actively transitioning
        item_alpha = alpha_val if is_highlighted else 255
        
        # Fill surfaces
        bar_surface.fill((*bar_color, item_alpha))
        
        # Numbers rendered directly below the boundary base line
        text_node = font.render(str(val), True, (*COLOR_TEXT, item_alpha))
        text_x_offset = (base_bar_width - text_node.get_width()) // 2
        num_surface.blit(text_node, (text_x_offset, 0))
        
        # Blit components onto main frame window
        screen.blit(bar_surface, (x, y))
        screen.blit(num_surface, (x, base_y + 10))

    pygame.display.flip()

# --- Main Runtime Loop ---
clock = pygame.time.Clock()
running = True

while running:
    # Handle Fade Anim Transitions
    if fade_direction == -1:  # Fading Out
        current_alpha -= 25
        if current_alpha <= 0:
            current_alpha = 0
            state_index = target_state_index  # Commit data step change mid-fade
            fade_direction = 1                # Begin Fading back In
    elif fade_direction == 1:   # Fading In
        current_alpha += 25
        if current_alpha >= 255:
            current_alpha = 255
            fade_direction = 0                # Animation cycle complete

    draw_screen(state_index, current_alpha)
    
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
            
        elif event.type == pygame.KEYDOWN and fade_direction == 0:
            if event.key == pygame.K_SPACE:
                if state_index < len(all_states) - 1:
                    target_state_index = state_index + 1
                    fade_direction = -1  # Trigger fade sequence out
            elif event.key == pygame.K_BACKSPACE:
                if state_index > 0:
                    target_state_index = state_index - 1
                    fade_direction = -1  # Trigger fade sequence out
            elif event.key == pygame.K_r:
                initial_data = generate_data(12)
                all_states = capture_insertion_sort_steps(initial_data)
                state_index = 0
                current_alpha = 255
                fade_direction = 0

    clock.tick(60)  # Maintain stable 60 FPS update structure

pygame.quit()
