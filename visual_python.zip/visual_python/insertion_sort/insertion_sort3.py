import pygame
import random
import sys

# Initialize pygame
pygame.init()

# Window Configuration
SCREEN_WIDTH = 900
SCREEN_HEIGHT = 600
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("Insertion Sort Visualizer")

# Frame rate / Speed control
clock = pygame.time.Clock()
FPS = 60  # Adjust this to change the visualization speed

# Colors (RGB)
COLOR_BG = (24, 28, 36)         # Dark slate blue
COLOR_BAR = (74, 144, 226)       # Blue (default unsorted)
COLOR_ACTIVE = (231, 76, 60)     # Red (the element being positioned)
COLOR_COMPARE = (241, 196, 15)   # Yellow (elements being compared)
COLOR_SORTED = (46, 204, 113)    # Green (final completed sort)
COLOR_TEXT = (236, 240, 241)     # Off-white

# Data Parameters
NUM_BARS = 100
BAR_PADDING = 1
TOTAL_BAR_WIDTH = SCREEN_WIDTH // NUM_BARS
BAR_WIDTH = TOTAL_BAR_WIDTH - BAR_PADDING

# Global Variables
data_list = []
active_idx = -1
compare_idx = -1
sorting = False
sorting_generator = None
is_sorted = False

def generate_new_list():
    """Generates a random list of sizes fitting the screen height."""
    global data_list, active_idx, compare_idx, sorting, is_sorted
    # Leave room at the top of the screen for text padding
    data_list = [random.randint(20, SCREEN_HEIGHT - 80) for _ in range(NUM_BARS)]
    active_idx = -1
    compare_idx = -1
    sorting = False
    is_sorted = False

def insertion_sort_generator(arr):
    """A generator that yields control back to the game loop at each step 
       of the insertion sort algorithm to allow for rendering."""
    global active_idx, compare_idx
    
    for i in range(1, len(arr)):
        key = arr[i]
        active_idx = i
        j = i - 1
        
        while j >= 0 and arr[j] > key:
            compare_idx = j
            arr[j + 1] = arr[j]
            j -= 1
            # Yield at every swap/shift step to draw the update
            yield
            
        arr[j + 1] = key
        # Yield when placing the item into its destination position
        yield

def draw_screen():
    """Renders the bars and textual UI instructions to the screen."""
    screen.fill(COLOR_BG)
    
    # 1. Draw Text Instructions
    font = pygame.font.SysFont("Arial", 20)
    title_font = pygame.font.SysFont("Arial", 22, bold=True)
    
    title_surface = title_font.render("Insertion Sort Visualizer", True, COLOR_TEXT)
    screen.blit(title_surface, (20, 15))
    
    controls_str = "[SPACE] Start Sorting  |  [R] Generate New Array"
    if is_sorted:
        controls_str = "Sorting Complete! Press [R] to Generate a New Array."
    elif sorting:
        controls_str = "Sorting... Please wait."
        
    controls_surface = font.render(controls_str, True, COLOR_TEXT)
    screen.blit(controls_surface, (20, 45))
    
    # 2. Draw Data Bars
    for idx, val in enumerate(data_list):
        # Calculate screen X and Y coordinates
        x_pos = idx * TOTAL_BAR_WIDTH + (SCREEN_WIDTH - (NUM_BARS * TOTAL_BAR_WIDTH)) // 2
        y_pos = SCREEN_HEIGHT - val
        
        # Color assigning logic based on sorting state
        if is_sorted:
            color = COLOR_SORTED
        elif idx == active_idx:
            color = COLOR_ACTIVE
        elif idx == compare_idx:
            color = COLOR_COMPARE
        else:
            color = COLOR_BAR
            
        pygame.draw.rect(screen, color, (x_pos, y_pos, BAR_WIDTH, val))
        
    pygame.display.flip()

# Initial Data State
generate_new_list()

# Main App Loop
while True:
    # 1. Event Handling
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
            
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE and not sorting and not is_sorted:
                # Initialize the generator when starting
                sorting = True
                sorting_generator = insertion_sort_generator(data_list)
                
            elif event.key == pygame.K_r:
                generate_new_list()

    # 2. Sorting Step Progression
    if sorting and sorting_generator:
        try:
            # Advance the algorithm by exactly one step
            next(sorting_generator)
        except StopIteration:
            # Generator exhausted, which means the array is fully sorted
            sorting = False
            is_sorted = True
            active_idx = -1
            compare_idx = -1

    # 3. Draw & Refresh Screen
    draw_screen()
    clock.tick(FPS)
