import random
import pygame

pygame.init()
pygame.font.init()

# --- Configuration & Styling ---
WINDOW_WIDTH = 800
WINDOW_HEIGHT = 600
FONT_SIZE = 20

# Colors (Hex RGB)
COLOR_BG = (245, 247, 250)         # Soft light gray
COLOR_BAR_DEFAULT = (74, 144, 226) # Muted blue
COLOR_BAR_ACTIVE = (230, 57, 70)   # Coral red (current items being compared)
COLOR_BAR_SORTED = (46, 204, 113)  # Emerald green (sorted section)
COLOR_TEXT = (44, 62, 80)          # Dark charcoal
COLOR_UI_TEXT = (127, 140, 141)    # Muted gray

# Setup Screen and Font
screen = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
font = pygame.font.SysFont("Arial", FONT_SIZE)

# --- Generate Data & Pre-compute States ---
def generate_data(num_elements=15):
    """Generates a random array of numbers."""
    return [random.randint(10, 100) for _ in range(num_elements)]

def capture_states(arr):
    """
    Runs insertion sort and saves a snapshot of the array 
    at every meaningful comparison and movement step.
    """
    # State format: (current_array_snapshot, active_indices_list, sorted_until_index)
    states = []
    
    # Initial state
    states.append((list(arr), [], 0))
    
    for i in range(1, len(arr)):
        key = arr[i]
        j = i - 1
        
        # Capture state showing the element we are picking up
        states.append((list(arr), [j, j + 1], i - 1))
        
        while j >= 0 and arr[j] > key:
            arr[j + 1] = arr[j]
            j -= 1
            # Capture state as elements shift right
            states.append((list(arr), [max(0, j), j + 1], i))
            
        arr[j + 1] = key
        # Capture state after placing the key in its correct position
        states.append((list(arr), [j + 1], i))
        
    # Final fully sorted state
    states.append((list(arr), [], len(arr) - 1))
    return states

# --- State Management ---
initial_array = generate_data(15)
all_states = capture_states(initial_array)
state_index = 0

def draw_screen(state_idx):
    screen.fill(COLOR_BG)
    
    # Get data for current step
    current_arr, active_indices, sorted_until = all_states[state_idx]
    num_elements = len(current_arr)
    
    # Layout math
    padding = 20
    available_width = WINDOW_WIDTH - (padding * 2)
    bar_width = available_width // num_elements - 10
    total_bar_area_width = num_elements * (bar_width + 10) - 10
    start_x = (WINDOW_WIDTH - total_bar_area_width) // 2
    
    max_val = 100
    max_bar_height = WINDOW_HEIGHT - 200  # Leave room for text and UI
    
    # Draw instructions
    instruction_str = "Controls: [SPACE] Next Step  |  [BACKSPACE] Previous Step  |  [R] Reset"
    inst_text = font.render(instruction_str, True, COLOR_UI_TEXT)
    screen.blit(inst_text, (20, 20))
    
    step_str = f"Step: {state_idx + 1} / {len(all_states)}"
    step_text = font.render(step_str, True, COLOR_UI_TEXT)
    screen.blit(step_text, (WINDOW_WIDTH - step_text.get_width() - 20, 20))

    # Draw Bars and Numbers
    for idx, val in enumerate(current_arr):
        # Calculate heights and positions
        bar_height = int((val / max_val) * max_bar_height)
        x_pos = start_x + idx * (bar_width + 10)
        y_pos = WINDOW_HEIGHT - 100 - bar_height  # Base line for bars
        
        # Color coding logic
        if idx in active_indices:
            color = COLOR_BAR_ACTIVE
        elif idx <= sorted_until and state_idx == len(all_states) - 1:
            color = COLOR_BAR_SORTED  # All green at the very end
        elif idx <= sorted_until:
            color = COLOR_BAR_SORTED
        else:
            color = COLOR_BAR_DEFAULT
            
        # Draw Bar
        pygame.draw.rect(screen, color, (x_pos, y_pos, bar_width, bar_height))
        
        # Draw Number below the bar
        num_text = font.render(str(val), True, COLOR_TEXT)
        text_x = x_pos + (bar_width - num_text.get_width()) // 2
        text_y = WINDOW_HEIGHT - 80  # Positioned safely under the bars
        screen.blit(num_text, (text_x, text_y))

    pygame.display.flip()

running = True
while running:
    draw_screen(state_index)
    
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
            
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE:
                # Move Forward
                if state_index < len(all_states) - 1:
                    state_index += 1
            elif event.key == pygame.K_BACKSPACE:
                # Move Backward
                if state_index > 0:
                    state_index -= 1
            elif event.key == pygame.K_r:
                # Regenerate and Reset
                initial_array = generate_data(15)
                all_states = capture_states(initial_array)
                state_index = 0

pygame.quit()
