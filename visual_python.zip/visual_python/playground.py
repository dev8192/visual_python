import os
os.environ['PYGAME_HIDE_SUPPORT_PROMPT'] = "1"
import pygame

def main():
    print("main1")
    screen = pygame.display.set_mode((0, 0), pygame.NOFRAME)
    width, height = screen.get_size()
    print(width, height)

def main2():
    print("main2")
    screen = pygame.display.set_mode((0, 0), pygame.NOFRAME | pygame.HIDDEN)
    width, height = screen.get_size()
    print(width, height)

def main3():
    print("main3")
    pygame.init()
    info = pygame.display.Info()
    SCREEN_WIDTH = info.current_w
    SCREEN_HEIGHT = info.current_h
    print(SCREEN_WIDTH, SCREEN_HEIGHT)

main()
