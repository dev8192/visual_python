import os
os.environ['PYGAME_HIDE_SUPPORT_PROMPT'] = "1"
import pygame

def main1():
    # pygame.init()
    # screen = pygame.display.set_mode((0, 0), pygame.NOFRAME)
    screen = pygame.display.set_mode((0, 0), pygame.NOFRAME | pygame.HIDDEN)
    width, height = screen.get_size()
    print(width, height)

def main2():
    # pygame.init()
    screen = pygame.display.set_mode((0, 0), pygame.NOFRAME)
    # screen = pygame.display.set_mode((0, 0), pygame.NOFRAME | pygame.HIDDEN)
    # width, height = screen.get_size()
    # print(width, height)

main()
