import pygame
import sys
import time

NUM_A = 105
NUM_B = 33

pygame.init()

# Set up screen size dynamically
SCREEN_WIDTH = 1000
SCREEN_HEIGHT = 800
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))

# Colors
COLOR_BG = (18, 18, 24)
COLOR_RECT_BORDER = (100, 110, 120)
COLOR_TEXT = (240, 240, 240)
# Pastel square palettes that cycle to easily see distinct steps
COLOR_PALETTE = [
    (255, 107, 107),  # Coral
    (78, 205, 196),   # Mint
    (255, 230, 109),  # Yellow
    (149, 117, 205),  # Lavender
    (247, 143, 179),  # Pink
    (119, 139, 235)   # Light Blue
]

# Fonts
font_large = pygame.font.SysFont("Consolas", 28)
font_small = pygame.font.SysFont("Consolas", 18)

# Calculate optimal scaling to maximize the rectangle within canvas margins
MARGIN = 80
AVAILABLE_WIDTH = SCREEN_WIDTH - (2 * MARGIN)
AVAILABLE_HEIGHT = SCREEN_HEIGHT - (2 * MARGIN) - 50 # Leave space for the text at top

# Map dimension ratio to screen space
scale_w = AVAILABLE_WIDTH / NUM_A
scale_h = AVAILABLE_HEIGHT / NUM_B
SCALE = min(scale_w, scale_h)

# Coordinates for drawing the main container rectangle
RECT_X = MARGIN + (AVAILABLE_WIDTH - (NUM_A * SCALE)) // 2
RECT_Y = MARGIN + 50 + (AVAILABLE_HEIGHT - (NUM_B * SCALE)) // 2

def generate_euclidean_steps(a, b):
    curr_w, curr_h = a, b
    # Tracking coordinates relative to the math matrix (top-left of container is 0,0)
    offset_x, offset_y = 0, 0
    color_index = 0

    while curr_w > 0 and curr_h > 0:
        color = COLOR_PALETTE[color_index % len(COLOR_PALETTE)]
        color_index += 1

        if curr_w >= curr_h:
            # Width is greater/equal: Place squares of size (curr_h x curr_h) from left to right
            num_squares = curr_w // curr_h
            remainder = curr_w % curr_h
            
            for _ in range(num_squares):
                yield (offset_x, offset_y, curr_h, curr_h, color, f"{curr_w} = {num_squares}*({curr_h}) + {remainder}")
                offset_x += curr_h
                
            curr_w = remainder
        else:
            # Height is greater: Place squares of size (curr_w x curr_w) from top to bottom
            num_squares = curr_h // curr_w
            remainder = curr_h % curr_w
            
            for _ in range(num_squares):
                yield (offset_x, offset_y, curr_w, curr_w, color, f"{curr_h} = {num_squares}*({curr_w}) + {remainder}")
                offset_y += curr_w
                
            curr_h = remainder

# Pre-calculate steps
steps_generator = generate_euclidean_steps(NUM_A, NUM_B)
placed_squares = []
current_equation = f"Finding GCD({NUM_A}, {NUM_B})..."
gcd_found = None

PAUSE_DURATION = 0.8
last_step_time = time.time()

running = True
clock = pygame.time.Clock()

while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                running = False

    current_time = time.time()
    if current_time - last_step_time > PAUSE_DURATION:
        try:
            next_square = next(steps_generator)
            placed_squares.append(next_square)
            current_equation = next_square[5]
            last_step_time = current_time
        except StopIteration:
            if placed_squares:
                gcd_found = placed_squares[-1][2] # the size of the final square
                current_equation = f"GCD Found! Great Common Divisor = {gcd_found}"

    screen.fill(COLOR_BG)

    eq_surface = font_large.render(current_equation, True, COLOR_TEXT)
    screen.blit(eq_surface, (MARGIN, 30))

    container_rect = pygame.Rect(RECT_X, RECT_Y, NUM_A * SCALE, NUM_B * SCALE)
    pygame.draw.rect(screen, COLOR_RECT_BORDER, container_rect, 3)

    # Draw all successfully placed sub-squares so far
    for sq_x, sq_y, sq_w, sq_h, color, _ in placed_squares:
        # Scale mathematical coordinates up to viewport coordinates
        screen_sq_x = RECT_X + (sq_x * SCALE)
        screen_sq_y = RECT_Y + (sq_y * SCALE)
        screen_sq_w = sq_w * SCALE
        screen_sq_h = sq_h * SCALE

        square_rect = pygame.Rect(screen_sq_x, screen_sq_y, screen_sq_w, screen_sq_h)
        
        # Fill the square inside
        pygame.draw.rect(screen, color, square_rect)
        # Draw dark inner bounds to distinguish tightly packed uniform squares
        pygame.draw.rect(screen, COLOR_BG, square_rect, 1)

        # Label square dimensions if they are large enough to fit text
        if screen_sq_w > 35:
            lbl_surface = font_small.render(str(sq_w), True, COLOR_BG)
            lbl_rect = lbl_surface.get_rect(center=square_rect.center)
            screen.blit(lbl_surface, lbl_rect)

    pygame.display.flip()
    clock.tick(60)

pygame.quit()
sys.exit()
