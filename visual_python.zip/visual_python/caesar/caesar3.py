import pygame
import sys
import math

# Initialize Pygame
pygame.init()

# Get the native desktop screen resolution for true fullscreen borderless experience
info = pygame.display.Info()
WINDOW_WIDTH = info.current_w
WINDOW_HEIGHT = info.current_h
FPS = 60

# --- Colors ---
COLOR_BG = (22, 26, 29)          # Dark Gunmetal
COLOR_TEXT_PRIMARY = (245, 245, 247) # Off-White
COLOR_TEXT_MUTED = (141, 153, 174)   # Slate Grey
COLOR_PLAIN = (58, 125, 68)         # Emerald Green (Plain Text)
COLOR_CIPHER = (217, 4, 41)         # Crimson Red (Cipher Text)
COLOR_HIGHLIGHT = (255, 183, 3)     # Amber/Gold
COLOR_SUCCESS = (0, 180, 216)       # Cyan for Done indication
COLOR_DIVIDER = (73, 80, 87)        # Dark grey for the padding lines

# --- Fonts ---
font_large = pygame.font.SysFont("Courier New", 28, bold=True)
font_medium = pygame.font.SysFont("Courier New", 22, bold=True)
font_small = pygame.font.SysFont("Courier New", 16)

# --- UI Grid Setup ---
ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
BOX_SIZE = 32
BOX_PADDING = 4
TOTAL_BOX_WIDTH = BOX_SIZE + BOX_PADDING

# Centralized spacing including 3 helper letters on left and 3 on right
TOTAL_COLUMNS = 3 + 26 + 3 # 32 total cells visible
START_X = (WINDOW_WIDTH - (TOTAL_COLUMNS * TOTAL_BOX_WIDTH)) // 2

# Row Positions balanced for standard screen profiles
Y_ROW_PLAIN = WINDOW_HEIGHT // 2 - 60
Y_ROW_CIPHER = WINDOW_HEIGHT // 2 + 40

class CaesarVisualizer:
    def __init__(self):
        # Fullscreen canvas initialization via NOFRAME
        self.screen = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT), pygame.NOFRAME)
        pygame.display.set_caption("Caesar Cipher Algorithm Visualizer")
        self.clock = pygame.time.Clock()
        
        # State tracking matrices
        self.shift = 3
        self.target_shift_raw = 3.0
        self.current_shift_offset = 3.0
        
        self.mode = "ENCRYPT"
        
        # Dynamic context strings
        self.plain_source = "HELLO WORLD"
        self.cipher_source = "KHOOR ZRUOG"
        
        # Operational variables
        self.history = []
        self.current_char_idx = 0
        self.demo_output = ""
        self.active_map_source = None  # Clear logical alpha index (0 to 25)
        self.is_done = False

    def reset_animation(self):
        self.current_char_idx = 0
        self.demo_output = ""
        self.active_map_source = None
        self.history.clear()
        self.is_done = False

    def update_shift_animation(self):
        """Linearly interpolates tracking configurations smoothly to fix row jitters."""
        diff = self.target_shift_raw - self.current_shift_offset
        if abs(diff) > 0.001:
            self.current_shift_offset += diff * 0.15
        else:
            self.current_shift_offset = self.target_shift_raw
        
        # Keep actual math shift cleanly wrapped inside 0-25 boundaries
        self.shift = int(round(self.target_shift_raw)) % 26

    def get_current_input_text(self):
        return self.plain_source if self.mode == "ENCRYPT" else self.cipher_source

    def step_forward(self):
        input_text = self.get_current_input_text()
        if self.is_done or self.current_char_idx >= len(input_text):
            self.is_done = True
            return

        char = input_text[self.current_char_idx]
        state_snapshot = (char, self.demo_output, self.active_map_source)
        self.history.append(state_snapshot)

        if char.isalpha():
            alpha_idx = ALPHABET.index(char.upper())
            self.active_map_source = alpha_idx
            
            if self.mode == "ENCRYPT":
                target_idx = (alpha_idx + self.shift) % 26
            else: # DECRYPT
                target_idx = (alpha_idx - self.shift) % 26
                
            self.demo_output += ALPHABET[target_idx]
        else:
            self.active_map_source = None
            self.demo_output += char

        self.current_char_idx += 1
        if self.current_char_idx >= len(input_text):
            self.is_done = True

    def step_backward(self):
        if not self.history:
            return
        _, prev_output, prev_src = self.history.pop()
        self.demo_output = prev_output
        self.active_map_source = prev_src
        self.current_char_idx -= 1
        self.is_done = False

    def draw_arrow_head(self, target_x, target_y, direction="down"):
        """Draws a clean directional vector triangle pointing precisely at target elements."""
        size = 8
        if direction == "down":
            pt1 = (target_x, target_y)
            pt2 = (target_x - size, target_y - size)
            pt3 = (target_x + size, target_y - size)
        else: # up
            pt1 = (target_x, target_y)
            pt2 = (target_x - size, target_y + size)
            pt3 = (target_x + size, target_y + size)
        pygame.draw.polygon(self.screen, COLOR_HIGHLIGHT, [pt1, pt2, pt3])

    def draw_alphabet_row(self, y_pos, is_shifted_row=False, color=COLOR_PLAIN, label="Plain"):
        """Renders the sequential block rows containing helper boxes and absolute mapping."""
        # Row Header Label Positioning
        lbl_surface = font_medium.render(f"{label}:", True, color)
        self.screen.blit(lbl_surface, (START_X - 110, y_pos + 5))

        # Shift application context logic
        shift_val = self.current_shift_offset if is_shifted_row else 0.0

        for col in range(TOTAL_COLUMNS):
            # Calculate physical rendering footprint coordinates
            x_pos = START_X + col * TOTAL_BOX_WIDTH
            
            # Map structural logical index positioning context
            if col < 3:
                # Left helper letters block
                logical_alphabet_idx = (col - 3) % 26
                is_helper = True
            elif col >= 29:
                # Right helper letters block
                logical_alphabet_idx = (col - 3) % 26
                is_helper = True
            else:
                # Core sequence block
                logical_alphabet_idx = col - 3
                is_helper = False

            if is_shifted_row:
                # Apply shift value inversion cleanly to ensure the row moves correctly
                logical_alphabet_idx = (logical_alphabet_idx - int(math.floor(shift_val))) % 26
                fractional_offset = (shift_val % 1.0) * TOTAL_BOX_WIDTH
                x_pos += fractional_offset
                
                # Dynamic clip bounding wrap corrections
                if x_pos >= START_X + TOTAL_COLUMNS * TOTAL_BOX_WIDTH:
                    x_pos -= TOTAL_COLUMNS * TOTAL_BOX_WIDTH
                elif x_pos < START_X:
                    x_pos += TOTAL_COLUMNS * TOTAL_BOX_WIDTH

            char = ALPHABET[logical_alphabet_idx]
            rect = pygame.Rect(x_pos, y_pos, BOX_SIZE, BOX_SIZE)

            # Highlighting checks mapping logical elements accurately
            is_highlighted = False
            if not self.is_done and self.active_map_source is not None:
                if not is_shifted_row:
                    # Plain row lights up matching source character indexes
                    if not is_helper and logical_alphabet_idx == self.active_map_source:
                        is_highlighted = True
                else:
                    # Cipher row lights up matched destination character indexes natively
                    expected_target = (self.active_map_source + (self.shift if self.mode == "ENCRYPT" else -self.shift)) % 26
                    if logical_alphabet_idx == expected_target:
                        # Only highlight inside the real center display index bounds
                        center_col_equivalent = logical_alphabet_idx + 3 + int(math.floor(shift_val))
                        # Match current relative physical display alignment tracking
                        if abs((x_pos - (START_X + (logical_alphabet_idx + 3) * TOTAL_BOX_WIDTH)) % (26 * TOTAL_BOX_WIDTH)) < BOX_SIZE:
                           pass 
                        is_highlighted = True

            # Draw cell bounds context
            if START_X - BOX_SIZE <= x_pos <= WINDOW_WIDTH - START_X:
                if is_highlighted:
                    pygame.draw.rect(self.screen, COLOR_HIGHLIGHT, rect)
                    text_color = COLOR_BG
                else:
                    draw_color = COLOR_DIVIDER if is_helper else color
                    pygame.draw.rect(self.screen, draw_color, rect, 1 if is_helper else 2)
                    text_color = COLOR_TEXT_MUTED if is_helper else COLOR_TEXT_PRIMARY

                char_surface = font_medium.render(char, True, text_color)
                char_rect = char_surface.get_rect(center=rect.center)
                self.screen.blit(char_surface, char_rect)

        # Explicitly render pipeline safety structural separator graphics lines ( | )
        sep1_x = START_X + 3 * TOTAL_BOX_WIDTH - 2
        sep2_x = START_X + 29 * TOTAL_BOX_WIDTH - 2
        pygame.draw.line(self.screen, COLOR_DIVIDER, (sep1_x, y_pos - 5), (sep1_x, y_pos + BOX_SIZE + 5), 2)
        pygame.draw.line(self.screen, COLOR_DIVIDER, (sep2_x, y_pos - 5), (sep2_x, y_pos + BOX_SIZE + 5), 2)

    def draw_mapping_indicators(self):
        """Draws orthogonal connecting lines tracking encryption/decryption pathways."""
        if self.is_done or self.active_map_source is None:
            return

        # Calculate exact visual midpoint offsets
        src_col = self.active_map_source + 3
        src_x = START_X + src_col * TOTAL_BOX_WIDTH + BOX_SIZE // 2
        
        # Target block calculation mappings
        if self.mode == "ENCRYPT":
            target_logical = (self.active_map_source + self.shift) % 26
        else:
            target_logical = (self.active_map_source - self.shift) % 26

        # Convert target location back to the moving row's screen space representation coordinates
        # Offset matches original physical block coordinate locations perfectly
        floor_shift = int(math.floor(self.current_shift_offset))
        frac_shift = (self.current_shift_offset % 1.0) * TOTAL_BOX_WIDTH
        
        target_physical_col = (target_logical + 3 + floor_shift)
        # Ensure projection wraps within the visible column matrix framework boundaries
        if target_physical_col >= TOTAL_COLUMNS:
            target_physical_col -= 26
        elif target_physical_col < 0:
            target_physical_col += 26
            
        tgt_x = START_X + target_physical_col * TOTAL_BOX_WIDTH + BOX_SIZE // 2 + int(frac_shift)
        mid_y = (Y_ROW_PLAIN + Y_ROW_CIPHER + BOX_SIZE) // 2

        # Draw ortho trace steps segments
        pygame.draw.line(self.screen, COLOR_HIGHLIGHT, (src_x, Y_ROW_PLAIN + BOX_SIZE), (src_x, mid_y), 3)
        pygame.draw.line(self.screen, COLOR_HIGHLIGHT, (src_x, mid_y), (tgt_x, mid_y), 3)
        pygame.draw.line(self.screen, COLOR_HIGHLIGHT, (tgt_x, mid_y), (tgt_x, Y_ROW_CIPHER), 3)

        # Place target vector point arrow indicators contextually
        if self.mode == "ENCRYPT":
            self.draw_arrow_head(tgt_x, Y_ROW_CIPHER, direction="down")
        else:
            self.draw_arrow_head(src_x, Y_ROW_PLAIN + BOX_SIZE, direction="up")

    def draw_ui(self):
        # Title Setup
        title_surface = font_large.render("CAESAR CIPHER ALGORITHM VISUALIZER", True, COLOR_TEXT_PRIMARY)
        self.screen.blit(title_surface, (WINDOW_WIDTH // 2 - title_surface.get_width() // 2, WINDOW_HEIGHT // 2 - 240))

        # Two Column Info Panel HUD
        instr_left = [
            "LEFT / RIGHT Arrows : Adjust Key Shift Value",
            "SPACEBAR            : Step Animation FORWARD",
            "BACKSPACE           : Step Animation BACKWARD",
        ]
        instr_right = [
            "TAB  : Switch ENCRYPT / DECRYPT Mode",
            "R    : Reset Current Input Structure",
            "ESC  : Terminate Window Environment",
        ]

        y_offset = WINDOW_HEIGHT // 2 + 160
        for idx, text in enumerate(instr_left):
            self.screen.blit(font_small.render(text, True, COLOR_TEXT_MUTED), (START_X, y_offset + idx * 26))
        for idx, text in enumerate(instr_right):
            self.screen.blit(font_small.render(text, True, COLOR_TEXT_MUTED), (WINDOW_WIDTH // 2 + 40, y_offset + idx * 26))

        # Dynamic Status Configuration Parameters
        mode_color = COLOR_PLAIN if self.mode == "ENCRYPT" else COLOR_CIPHER
        mode_surface = font_large.render(f"MODE: {self.mode}", True, mode_color)
        self.screen.blit(mode_surface, (START_X, WINDOW_HEIGHT // 2 - 170))

        key_surface = font_large.render(f"KEY SHIFT: {self.shift}", True, COLOR_HIGHLIGHT)
        self.screen.blit(key_surface, (WINDOW_WIDTH - START_X - key_surface.get_width(), WINDOW_HEIGHT // 2 - 170))

        # Processing Context Wrapper Box HUD
        box_y = WINDOW_HEIGHT // 2 - 125
        pygame.draw.rect(self.screen, (33, 37, 41), (START_X, box_y, TOTAL_COLUMNS * TOTAL_BOX_WIDTH - BOX_PADDING, 50), border_radius=6)
        
        lbl_in = "Plaintext: " if self.mode == "ENCRYPT" else "Ciphertext:"
        lbl_out = "Ciphertext:" if self.mode == "ENCRYPT" else "Plaintext: "
        
        input_lbl = font_medium.render(lbl_in, True, COLOR_TEXT_MUTED)
        input_val = font_medium.render(self.get_current_input_text(), True, COLOR_TEXT_PRIMARY)
        self.screen.blit(input_lbl, (START_X + 15, box_y + 13))
        self.screen.blit(input_val, (START_X + 165, box_y + 13))

        output_lbl = font_medium.render(lbl_out, True, COLOR_TEXT_MUTED)
        self.screen.blit(output_lbl, (WINDOW_WIDTH // 2 + 15, box_y + 13))

        if self.is_done:
            output_val = font_medium.render(self.demo_output, True, COLOR_SUCCESS)
            self.screen.blit(output_val, (WINDOW_WIDTH // 2 + 165, box_y + 13))
            
            done_surface = font_large.render("[DONE]", True, COLOR_SUCCESS)
            self.screen.blit(done_surface, (WINDOW_WIDTH // 2 - done_surface.get_width() // 2, WINDOW_HEIGHT // 2 + 105))
        else:
            cursor = "_" if pygame.time.get_ticks() % 500 < 250 else ""
            output_val = font_medium.render(self.demo_output + cursor, True, COLOR_HIGHLIGHT)
            self.screen.blit(output_val, (WINDOW_WIDTH // 2 + 165, box_y + 13))

    def run(self):
        running = True
        while running:
            self.screen.fill(COLOR_BG)
            
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        running = False
                    
                    elif event.key == pygame.K_TAB:
                        self.mode = "DECRYPT" if self.mode == "ENCRYPT" else "ENCRYPT"
                        self.reset_animation()
                        
                    elif event.key == pygame.K_r:
                        self.reset_animation()

                    elif event.key == pygame.K_RIGHT:
                        self.target_shift_raw += 1
                        self.reset_animation()
                        
                    elif event.key == pygame.K_LEFT:
                        self.target_shift_raw -= 1
                        self.reset_animation()
                        
                    elif event.key == pygame.K_SPACE:
                        self.step_forward()
                        
                    elif event.key == pygame.K_BACKSPACE:
                        self.step_backward()
            
            self.update_shift_animation()

            # Render Pipeline
            self.draw_ui()
            # Plain alphabet stays static contextually
            self.draw_alphabet_row(Y_ROW_PLAIN, is_shifted_row=False, color=COLOR_PLAIN, label="PLAINTEXT")
            # Cipher alphabet row moves dynamically using inverse sliding offsets mapping
            self.draw_alphabet_row(Y_ROW_CIPHER, is_shifted_row=True, color=COLOR_CIPHER, label="CIPHERTEXT")
            self.draw_mapping_indicators()

            pygame.display.flip()
            self.clock.tick(FPS)

        pygame.quit()
        sys.exit()

if __name__ == "__main__":
    visualizer = CaesarVisualizer()
    visualizer.run()
