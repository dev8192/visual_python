import pygame
import sys
import math

pygame.init()

info = pygame.display.Info()
WINDOW_WIDTH = info.current_w
WINDOW_HEIGHT = info.current_h
FPS = 60

COLOR_BG = pygame.Color("black")
COLOR_TEXT_PRIMARY = pygame.Color("whitesmoke")
COLOR_TEXT_MUTED = pygame.Color("lightslategrey")
COLOR_PLAIN = pygame.Color("seagreen")
COLOR_CIPHER = pygame.Color("crimson")
COLOR_HIGHLIGHT = pygame.Color("orange")
COLOR_SUCCESS = pygame.Color("darkturquoise")
COLOR_DIVIDER = pygame.Color("darkslategray")

font_large = pygame.font.SysFont("Courier New", 28, bold=True)
font_medium = pygame.font.SysFont("Courier New", 22, bold=True)
font_small = pygame.font.SysFont("Courier New", 16)

ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
BOX_SIZE = 32
BOX_PADDING = 4
TOTAL_BOX_WIDTH = BOX_SIZE + BOX_PADDING

TOTAL_COLUMNS = 3 + 26 + 3
START_X = (WINDOW_WIDTH - (TOTAL_COLUMNS * TOTAL_BOX_WIDTH)) // 2

Y_ROW_PLAIN = WINDOW_HEIGHT // 2 - 60
Y_ROW_CIPHER = WINDOW_HEIGHT // 2 + 40

class CaesarVisualizer:
    def __init__(self):
        self.screen = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT), pygame.NOFRAME)
        self.clock = pygame.time.Clock()
        
        self.shift = 3
        self.target_shift_raw = 3.0
        self.current_shift_offset = 3.0
        
        self.mode = "ENCRYPT"
        self.base_plaintext = "HELLO WORLD"
        
        self.history = []
        self.current_char_idx = 0
        self.demo_output = ""
        self.active_map_source = None
        self.is_done = False

    def reset_animation(self):
        self.current_char_idx = 0
        self.demo_output = ""
        self.active_map_source = None
        self.history.clear()
        self.is_done = False

    def update_shift_animation(self):
        diff = self.target_shift_raw - self.current_shift_offset
        if abs(diff) > 0.001:
            self.current_shift_offset += diff * 0.15
        else:
            self.current_shift_offset = self.target_shift_raw
        
        self.shift = int(round(self.target_shift_raw)) % 26

    def get_dynamic_ciphertext(self):
        cipher_chars = []
        for char in self.base_plaintext:
            if char.isalpha():
                idx = ALPHABET.index(char.upper())
                cipher_chars.append(ALPHABET[(idx + self.shift) % 26])
            else:
                cipher_chars.append(char)
        return "".join(cipher_chars)

    def get_current_input_text(self):
        return self.base_plaintext if self.mode == "ENCRYPT" else self.get_dynamic_ciphertext()

    def step_forward(self):
        input_text = self.get_current_input_text()
        if self.is_done or self.current_char_idx >= len(input_text):
            self.is_done = True
            return

        char = input_text[self.current_char_idx]
        state_snapshot = (char, self.demo_output, self.active_map_source)
        self.history.append(state_snapshot)

        if char.isalpha():
            alpha_idx = ALPHABET.index(char.upper())
            
            if self.mode == "ENCRYPT":
                self.active_map_source = alpha_idx
                target_idx = (alpha_idx + self.shift) % 26
            else: # DECRYPT
                # Convert active ciphertext index back to its plaintext source index mapping context
                self.active_map_source = (alpha_idx - self.shift) % 26
                target_idx = (alpha_idx - self.shift) % 26
                
            self.demo_output += ALPHABET[target_idx]
        else:
            self.active_map_source = None
            self.demo_output += char

        self.current_char_idx += 1
        if self.current_char_idx >= len(input_text):
            self.is_done = True

    def step_backward(self):
        if not self.history:
            return
        _, prev_output, prev_src = self.history.pop()
        self.demo_output = prev_output
        self.active_map_source = prev_src
        self.current_char_idx -= 1
        self.is_done = False

    def draw_arrow_head(self, target_x, target_y, direction="down"):
        size = 8
        if direction == "down":
            pt1 = (target_x, target_y)
            pt2 = (target_x - size, target_y - size)
            pt3 = (target_x + size, target_y - size)
        else: # up
            pt1 = (target_x, target_y)
            pt2 = (target_x - size, target_y + size)
            pt3 = (target_x + size, target_y + size)
        pygame.draw.polygon(self.screen, COLOR_HIGHLIGHT, [pt1, pt2, pt3])

    def draw_alphabet_row(self, y_pos, is_shifted_row, color):
        shift_val = self.current_shift_offset if is_shifted_row else 0.0

        for col in range(TOTAL_COLUMNS):
            x_pos = START_X + col * TOTAL_BOX_WIDTH
            
            if col < 3:
                logical_alphabet_idx = (col - 3) % 26
                is_helper = True
            elif col >= 29:
                logical_alphabet_idx = (col - 3) % 26
                is_helper = True
            else:
                logical_alphabet_idx = col - 3
                is_helper = False

            if is_shifted_row:
                logical_alphabet_idx = (logical_alphabet_idx + int(math.floor(shift_val))) % 26
                fractional_offset = (shift_val % 1.0) * TOTAL_BOX_WIDTH
                x_pos -= fractional_offset  
                
                if x_pos >= START_X + TOTAL_COLUMNS * TOTAL_BOX_WIDTH:
                    x_pos -= TOTAL_COLUMNS * TOTAL_BOX_WIDTH
                elif x_pos < START_X:
                    x_pos += TOTAL_COLUMNS * TOTAL_BOX_WIDTH

            char = ALPHABET[logical_alphabet_idx]
            rect = pygame.Rect(x_pos, y_pos, BOX_SIZE, BOX_SIZE)

            is_highlighted = False
            if not self.is_done and self.active_map_source is not None:
                if not is_shifted_row:
                    if not is_helper and logical_alphabet_idx == self.active_map_source:
                        is_highlighted = True
                else:
                    # In shifted row, the highlighted letter must match the encrypted value context
                    expected_cipher_letter_idx = (self.active_map_source + self.shift) % 26
                    if logical_alphabet_idx == expected_cipher_letter_idx:
                        is_highlighted = True

            if START_X - BOX_SIZE <= x_pos <= WINDOW_WIDTH - START_X:
                if is_highlighted and not self.is_done:
                    pygame.draw.rect(self.screen, COLOR_HIGHLIGHT, rect)
                    text_color = COLOR_BG
                else:
                    draw_color = COLOR_DIVIDER if is_helper else color
                    pygame.draw.rect(self.screen, draw_color, rect, 1 if is_helper else 2)
                    text_color = COLOR_TEXT_MUTED if is_helper else COLOR_TEXT_PRIMARY

                char_surface = font_medium.render(char, True, text_color)
                char_rect = char_surface.get_rect(center=rect.center)
                self.screen.blit(char_surface, char_rect)

    def draw_mapping_indicators(self):
        """Draws direct vertical connection vectors pointing to exact matches below."""
        if self.is_done or self.active_map_source is None:
            return

        # Both rows match column locations cleanly on a straight vertical plane
        src_col = self.active_map_source + 3
        target_x = START_X + src_col * TOTAL_BOX_WIDTH + BOX_SIZE // 2

        pygame.draw.line(self.screen, COLOR_HIGHLIGHT, (target_x, Y_ROW_PLAIN + BOX_SIZE), (target_x, Y_ROW_CIPHER), 3)

        if self.mode == "ENCRYPT":
            self.draw_arrow_head(target_x, Y_ROW_CIPHER, direction="down")
        else:
            self.draw_arrow_head(target_x, Y_ROW_PLAIN + BOX_SIZE, direction="up")

    def draw_ui(self):
        title_surface = font_large.render("CAESAR CIPHER ALGORITHM VISUALIZER", True, COLOR_TEXT_PRIMARY)
        self.screen.blit(title_surface, (WINDOW_WIDTH // 2 - title_surface.get_width() // 2, WINDOW_HEIGHT // 2 - 240))

        instr_left = [
            "LEFT / RIGHT Arrows : Adjust Key Shift Value",
            "SPACEBAR            : Step Animation FORWARD",
            "BACKSPACE           : Step Animation BACKWARD",
        ]
        instr_right = [
            "TAB  : Switch ENCRYPT / DECRYPT Mode",
            "R    : Reset Current Input Structure",
            "ESC  : Terminate Window Environment",
        ]

        y_offset = WINDOW_HEIGHT // 2 + 160
        for idx, text in enumerate(instr_left):
            self.screen.blit(font_small.render(text, True, COLOR_TEXT_MUTED), (START_X, y_offset + idx * 26))
        for idx, text in enumerate(instr_right):
            self.screen.blit(font_small.render(text, True, COLOR_TEXT_MUTED), (WINDOW_WIDTH // 2 + 40, y_offset + idx * 26))

        y_offset = WINDOW_HEIGHT // 2 - 170

        mode_color = COLOR_PLAIN if self.mode == "ENCRYPT" else COLOR_CIPHER
        mode_surface = font_large.render(f"MODE: {self.mode}", True, mode_color)
        self.screen.blit(mode_surface, (START_X, y_offset))

        key_surface = font_large.render(f"KEY SHIFT: {self.shift}", True, COLOR_HIGHLIGHT)
        self.screen.blit(key_surface, (WINDOW_WIDTH - START_X - key_surface.get_width(), y_offset))

        box_y = WINDOW_HEIGHT // 2 - 125
        pygame.draw.rect(self.screen, (33, 37, 41), (START_X, box_y, TOTAL_COLUMNS * TOTAL_BOX_WIDTH - BOX_PADDING, 50), border_radius=6)
        
        lbl_in = "Plaintext: " if self.mode == "ENCRYPT" else "Ciphertext:"
        lbl_out = "Ciphertext:" if self.mode == "ENCRYPT" else "Plaintext: "
        
        input_lbl = font_medium.render(lbl_in, True, COLOR_TEXT_MUTED)
        input_val = font_medium.render(self.get_current_input_text(), True, COLOR_TEXT_PRIMARY)
        self.screen.blit(input_lbl, (START_X + 15, box_y + 13))
        self.screen.blit(input_val, (START_X + 165, box_y + 13))

        output_lbl = font_medium.render(lbl_out, True, COLOR_TEXT_MUTED)
        self.screen.blit(output_lbl, (WINDOW_WIDTH // 2 + 15, box_y + 13))

        if self.is_done:
            output_val = font_medium.render(self.demo_output, True, COLOR_SUCCESS)
            self.screen.blit(output_val, (WINDOW_WIDTH // 2 + 165, box_y + 13))
            
            done_surface = font_large.render("[DONE]", True, COLOR_SUCCESS)
            done_x = WINDOW_WIDTH // 2 - done_surface.get_width() // 2
            self.screen.blit(done_surface, (done_x, WINDOW_HEIGHT // 2 + 105))
        else:
            cursor = "_" if pygame.time.get_ticks() % 500 < 250 else ""
            output_val = font_medium.render(self.demo_output + cursor, True, COLOR_HIGHLIGHT)
            self.screen.blit(output_val, (WINDOW_WIDTH // 2 + 165, box_y + 13))

    def run(self):
        running = True
        while running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        running = False
                    elif event.key == pygame.K_TAB:
                        self.mode = "DECRYPT" if self.mode == "ENCRYPT" else "ENCRYPT"
                        self.reset_animation()
                    elif event.key == pygame.K_r:
                        self.reset_animation()
                    elif event.key == pygame.K_RIGHT:
                        self.target_shift_raw += 1
                        self.reset_animation()
                    elif event.key == pygame.K_LEFT:
                        self.target_shift_raw -= 1
                        self.reset_animation()
                    elif event.key == pygame.K_SPACE:
                        self.step_forward()
                    elif event.key == pygame.K_BACKSPACE:
                        self.step_backward()
            
            self.screen.fill(COLOR_BG)

            self.update_shift_animation()

            self.draw_ui()
            self.draw_alphabet_row(Y_ROW_PLAIN, False, COLOR_PLAIN)
            self.draw_alphabet_row(Y_ROW_CIPHER, True, COLOR_CIPHER)
            self.draw_mapping_indicators()

            pygame.display.flip()
            self.clock.tick(FPS)

def main():
    visualizer = CaesarVisualizer()
    visualizer.run()


main()
