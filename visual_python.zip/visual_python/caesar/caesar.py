import pygame
import sys

# Initialize Pygame
pygame.init()

# --- Configuration & Constants ---
WINDOW_WIDTH = 900
WINDOW_HEIGHT = 500
FPS = 60

# Colors
COLOR_BG = (22, 26, 29)          # Dark Gunmetal
COLOR_TEXT_PRIMARY = (245, 245, 247) # Off-White
COLOR_TEXT_MUTED = (141, 153, 174)   # Slate Grey
COLOR_PLAIN = (58, 125, 68)         # Emerald Green (Plain Text)
COLOR_CIPHER = (217, 4, 41)         # Crimson Red (Cipher Text)
COLOR_HIGHLIGHT = (255, 183, 3)     # Amber/Gold

# Fonts
font_large = pygame.font.SysFont("Courier New", 28, bold=True)
font_medium = pygame.font.SysFont("Courier New", 22, bold=True)
font_small = pygame.font.SysFont("Courier New", 16)

# UI Parameters
ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
BOX_SIZE = 30
BOX_PADDING = 4
TOTAL_BOX_WIDTH = BOX_SIZE + BOX_PADDING
START_X = (WINDOW_WIDTH - (26 * TOTAL_BOX_WIDTH)) // 2

# Row Positions
Y_ROW_PLAIN = 180
Y_ROW_CIPHER = 280

class CaesarVisualizer:
    def __init__(self):
        self.screen = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
        pygame.display.set_caption("Caesar Cipher Algorithm Visualizer")
        self.clock = pygame.time.Clock()
        
        # State variables
        self.shift = 3
        self.target_shift = 3
        self.current_shift_offset = 3.0  # Smooth sliding position
        
        # Demo encryption variables
        self.demo_input = "HELLO WORLD"
        self.demo_output = ""
        self.current_char_idx = 0
        self.is_animating_text = False
        self.animation_timer = 0
        self.active_map_source = None
        self.active_map_target = None

    def update_shift_animation(self):
        """Smoothly slides the cipher ring alphabet to match the chosen shift value."""
        # Simple lerp for visual smoothness
        diff = self.target_shift - self.current_shift_offset
        if abs(diff) > 0.01:
            self.current_shift_offset += diff * 0.1
        else:
            self.current_shift_offset = self.target_shift
        self.shift = self.target_shift

    def start_text_animation(self):
        """Resets and initiates the step-by-step text transformation animation."""
        self.is_animating_text = True
        self.current_char_idx = 0
        self.demo_output = ""
        self.animation_timer = 0
        self.active_map_source = None
        self.active_map_target = None

    def update_text_animation(self):
        """Steps through the message character by character to show the shift mapping."""
        if not self.is_animating_text:
            return

        self.animation_timer += 1
        
        # Control animation speed (every 60 frames / 1 second)
        if self.animation_timer >= 60:
            self.animation_timer = 0
            
            if self.current_char_idx < len(self.demo_input):
                char = self.demo_input[self.current_char_idx]
                
                if char.isalpha():
                    # Calculate indices
                    plain_idx = ALPHABET.index(char.upper())
                    cipher_idx = (plain_idx + self.shift) % 26
                    
                    self.active_map_source = plain_idx
                    self.active_map_target = cipher_idx
                    
                    # Append transformed character
                    self.demo_output += ALPHABET[cipher_idx]
                else:
                    # Pass through spaces/punctuation instantly
                    self.active_map_source = None
                    self.active_map_target = None
                    self.demo_output += char
                
                self.current_char_idx += 1
            else:
                # Finished animating string
                self.is_animating_text = False
                self.active_map_source = None
                self.active_map_target = None

    def draw_alphabet_row(self, y_pos, shift_offset=0.0, color=COLOR_PLAIN, label="Plain"):
        """Renders a row of alphabetic character blocks."""
        # Draw Row Label
        lbl_surface = font_medium.render(f"{label}:", True, color)
        self.screen.blit(lbl_surface, (START_X - 100, y_pos + 4))

        for i in range(26):
            # Calculate standard coordinate space
            base_x = START_X + i * TOTAL_BOX_WIDTH
            
            # If tracking the cipher row, it moves dynamically based on the offset
            if shift_offset != 0.0:
                # Apply negative shift offset to visually move rightward
                display_idx = (i - int(shift_offset)) % 26
                # Sub-pixel adjustments for slide transitions
                fractional_offset = (shift_offset % 1) * TOTAL_BOX_WIDTH
                x_pos = base_x + fractional_offset
                char = ALPHABET[display_idx]
            else:
                x_pos = base_x
                char = ALPHABET[i]

            # Box background
            rect = pygame.Rect(x_pos, y_pos, BOX_SIZE, BOX_SIZE)
            
            # Check if this character block is currently highlighted in the animation
            is_highlighted = False
            if shift_offset == 0.0 and self.active_map_source == i:
                is_highlighted = True
            elif shift_offset != 0.0 and self.active_map_target == i:
                is_highlighted = True

            # Boundary clipping check to keep items within reasonable view limits
            if START_X - BOX_SIZE <= x_pos <= START_X + (26 * TOTAL_BOX_WIDTH):
                if is_highlighted:
                    pygame.draw.rect(self.screen, COLOR_HIGHLIGHT, rect)
                    text_color = COLOR_BG
                else:
                    pygame.draw.rect(self.screen, color, rect, 2)
                    text_color = COLOR_TEXT_PRIMARY

                char_surface = font_medium.render(char, True, text_color)
                char_rect = char_surface.get_rect(center=rect.center)
                self.screen.blit(char_surface, char_rect)

    def draw_mapping_indicators(self):
        """Draws visual connectors highlighting the current active character mapping."""
        if self.active_map_source is not None and self.active_map_target is not None:
            # Source center coordinates
            src_x = START_X + self.active_map_source * TOTAL_BOX_WIDTH + BOX_SIZE // 2
            src_y = Y_ROW_PLAIN + BOX_SIZE
            
            # Target center coordinates
            tgt_x = START_X + self.active_map_target * TOTAL_BOX_WIDTH + BOX_SIZE // 2
            tgt_y = Y_ROW_CIPHER

            # Draw pointer trace lines
            pygame.draw.line(self.screen, COLOR_HIGHLIGHT, (src_x, src_y), (src_x, src_y + 25), 3)
            pygame.draw.line(self.screen, COLOR_HIGHLIGHT, (src_x, src_y + 25), (tgt_x, tgt_y - 25), 3)
            pygame.draw.line(self.screen, COLOR_HIGHLIGHT, (tgt_x, tgt_y - 25), (tgt_x, tgt_y), 3)

    def draw_ui(self):
        """Fills standard textual headers and instruction graphics."""
        # Main Title
        title_surface = font_large.render("CAESAR CIPHER ALGORITHM VISUALIZER", True, COLOR_TEXT_PRIMARY)
        self.screen.blit(title_surface, (WINDOW_WIDTH // 2 - title_surface.get_width() // 2, 25))

        # Instructions Console
        instr_1 = "Use LEFT / RIGHT arrow keys to alter Key Shift value."
        instr_2 = "Press SPACEBAR to animate text conversion."
        self.screen.blit(font_small.render(instr_1, True, COLOR_TEXT_MUTED), (40, 410))
        self.screen.blit(font_small.render(instr_2, True, COLOR_TEXT_MUTED), (40, 435))

        # Current Key Display
        key_surface = font_large.render(f"KEY SHIFT: {self.target_shift}", True, COLOR_HIGHLIGHT)
        self.screen.blit(key_surface, (WINDOW_WIDTH - key_surface.get_width() - 40, 415))

        # String Conversion Display Box
        pygame.draw.rect(self.screen, (33, 37, 41), (40, 90, 820, 60), border_radius=6)
        
        # Render current calculation state text
        input_lbl = font_medium.render("Input: ", True, COLOR_TEXT_MUTED)
        input_val = font_medium.render(self.demo_input, True, COLOR_TEXT_PRIMARY)
        self.screen.blit(input_lbl, (60, 108))
        self.screen.blit(input_val, (150, 108))

        output_lbl = font_medium.render("Output: ", True, COLOR_TEXT_MUTED)
        # Highlight running cursor end
        cursor = "_" if self.is_animating_text and pygame.time.get_ticks() % 500 < 250 else ""
        output_val = font_medium.render(self.demo_output + cursor, True, COLOR_HIGHLIGHT)
        self.screen.blit(output_lbl, (480, 108))
        self.screen.blit(output_val, (580, 108))

    def run(self):
        running = True
        while running:
            self.screen.fill(COLOR_BG)
            
            # --- Event Handling ---
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                
                elif event.type == pygame.KEYDOWN:
                    if not self.is_animating_text:
                        if event.key == pygame.K_RIGHT:
                            self.target_shift = (self.target_shift + 1) % 26
                        elif event.key == pygame.K_LEFT:
                            self.target_shift = (self.target_shift - 1) % 26
                        elif event.key == pygame.K_SPACE:
                            self.start_text_animation()
            
            # --- State Transitions ---
            self.update_shift_animation()
            self.update_text_animation()

            # --- Render Steps ---
            self.draw_ui()
            self.draw_alphabet_row(Y_ROW_PLAIN, shift_offset=0.0, color=COLOR_PLAIN, label="PLAIN")
            self.draw_alphabet_row(Y_ROW_CIPHER, shift_offset=self.current_shift_offset, color=COLOR_CIPHER, label="CIPHER")
            self.draw_mapping_indicators()

            pygame.display.flip()
            self.clock.tick(FPS)

        pygame.quit()
        sys.exit()

visualizer = CaesarVisualizer()
visualizer.run()
