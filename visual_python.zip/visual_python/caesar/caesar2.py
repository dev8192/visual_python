import pygame
import sys

# Initialize Pygame
pygame.init()

# --- Configuration & Constants ---
WINDOW_WIDTH = 900
WINDOW_HEIGHT = 500
FPS = 60

# Colors
COLOR_BG = (22, 26, 29)          # Dark Gunmetal
COLOR_TEXT_PRIMARY = (245, 245, 247) # Off-White
COLOR_TEXT_MUTED = (141, 153, 174)   # Slate Grey
COLOR_PLAIN = (58, 125, 68)         # Emerald Green (Plain Text)
COLOR_CIPHER = (217, 4, 41)         # Crimson Red (Cipher Text)
COLOR_HIGHLIGHT = (255, 183, 3)     # Amber/Gold
COLOR_SUCCESS = (0, 180, 216)       # Cyan for Done indication

# Fonts
font_large = pygame.font.SysFont("Courier New", 28, bold=True)
font_medium = pygame.font.SysFont("Courier New", 22, bold=True)
font_small = pygame.font.SysFont("Courier New", 16)

# UI Parameters
ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
BOX_SIZE = 30
BOX_PADDING = 4
TOTAL_BOX_WIDTH = BOX_SIZE + BOX_PADDING
START_X = (WINDOW_WIDTH - (26 * TOTAL_BOX_WIDTH)) // 2

# Row Positions
Y_ROW_PLAIN = 180
Y_ROW_CIPHER = 280

class CaesarVisualizer:
    def __init__(self):
        # Use pygame.NOFRAME as requested
        self.screen = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT), pygame.NOFRAME)
        pygame.display.set_caption("Caesar Cipher Algorithm Visualizer")
        self.clock = pygame.time.Clock()
        
        # State variables
        self.shift = 3
        self.target_shift_raw = 3        # Endless continuous value to prevent wrapping glitch
        self.current_shift_offset = 3.0  # Smooth sliding position
        
        # Mode variable: 'ENCRYPT' or 'DECRYPT'
        self.mode = "ENCRYPT"
        
        # Demo data
        self.demo_input = "HELLO WORLD"
        self.history = []  # Tracks past (char, output_snapshot, src_highlight, tgt_highlight) for undoing steps
        
        # Animation states
        self.current_char_idx = 0
        self.demo_output = ""
        self.active_map_source = None
        self.active_map_target = None
        self.is_done = False

    def reset_animation(self):
        """Resets the process structure variables."""
        self.current_char_idx = 0
        self.demo_output = ""
        self.active_map_source = None
        self.active_map_target = None
        self.history.clear()
        self.is_done = False

    def update_shift_animation(self):
        """Smoothly slides the cipher ring alphabet to match the chosen raw shift value."""
        diff = self.target_shift_raw - self.current_shift_offset
        if abs(diff) > 0.001:
            self.current_shift_offset += diff * 0.15
        else:
            self.current_shift_offset = self.target_shift_raw
        
        # Keep actual math shift constrained neatly inside 0-25 boundaries
        self.shift = int(round(self.target_shift_raw)) % 26

    def step_forward(self):
        """Advances the algorithm by exactly one step manually."""
        if self.is_done or self.current_char_idx >= len(self.demo_input):
            self.is_done = True
            return

        char = self.demo_input[self.current_char_idx]
        
        # Push current state onto history stack before making modifications
        state_snapshot = (char, self.demo_output, self.active_map_source, self.active_map_target)
        self.history.append(state_snapshot)

        if char.isalpha():
            plain_idx = ALPHABET.index(char.upper())
            
            if self.mode == "ENCRYPT":
                cipher_idx = (plain_idx + self.shift) % 26
                added_char = ALPHABET[cipher_idx]
            else: # DECRYPT
                cipher_idx = (plain_idx - self.shift) % 26
                added_char = ALPHABET[cipher_idx]
                
            self.active_map_source = plain_idx
            self.active_map_target = (plain_idx + self.shift) % 26 # Visual box index in moving cipher row
            self.demo_output += added_char
        else:
            # Pass spaces through automatically
            self.active_map_source = None
            self.active_map_target = None
            self.demo_output += char

        self.current_char_idx += 1
        if self.current_char_idx >= len(self.demo_input):
            self.is_done = True

    def step_backward(self):
        """Reverts the algorithm by exactly one step manually using the history stack."""
        if not self.history:
            return

        # Restore from history stack
        _, prev_output, prev_src, prev_tgt = self.history.pop()
        self.demo_output = prev_output
        self.active_map_source = prev_src
        self.active_map_target = prev_tgt
        self.current_char_idx -= 1
        self.is_done = False

    def draw_alphabet_row(self, y_pos, shift_offset=0.0, color=COLOR_PLAIN, label="Plain"):
        """Renders a row of alphabetic character blocks using continuous offsets."""
        lbl_surface = font_medium.render(f"{label}:", True, color)
        self.screen.blit(lbl_surface, (START_X - 100, y_pos + 4))

        for i in range(26):
            base_x = START_X + i * TOTAL_BOX_WIDTH
            
            if shift_offset != 0.0:
                # Use standard modulo calculations on float properties to retain pure directional stability
                display_idx = (i - int(floor_offset := int(shift_offset))) % 26
                fractional_offset = (shift_offset - floor_offset) * TOTAL_BOX_WIDTH
                x_pos = base_x + fractional_offset
                
                # Double wrap calculation for continuous infinite edge visibility rendering
                if x_pos >= START_X + 26 * TOTAL_BOX_WIDTH:
                    x_pos -= 26 * TOTAL_BOX_WIDTH
                    display_idx = (display_idx - 26) % 26
                elif x_pos < START_X:
                    x_pos += 26 * TOTAL_BOX_WIDTH
                    display_idx = (display_idx + 26) % 26
                    
                char = ALPHABET[display_idx]
                box_logical_idx = (display_idx + self.shift) % 26
            else:
                x_pos = base_x
                char = ALPHABET[i]
                box_logical_idx = i

            rect = pygame.Rect(x_pos, y_pos, BOX_SIZE, BOX_SIZE)
            
            # Map highlighted item matches
            is_highlighted = False
            if shift_offset == 0.0 and self.active_map_source == box_logical_idx:
                is_highlighted = True
            elif shift_offset != 0.0 and self.active_map_target == i:
                # Highlight based on physical cell match index configuration 
                if self.active_map_source is not None:
                    target_physical_cell = (self.active_map_source - floor_offset) % 26
                    if i == target_physical_cell:
                        is_highlighted = True

            if is_highlighted and not self.is_done:
                pygame.draw.rect(self.screen, COLOR_HIGHLIGHT, rect)
                text_color = COLOR_BG
            else:
                pygame.draw.rect(self.screen, color, rect, 2)
                text_color = COLOR_TEXT_PRIMARY

            char_surface = font_medium.render(char, True, text_color)
            char_rect = char_surface.get_rect(center=rect.center)
            self.screen.blit(char_surface, char_rect)

    def draw_mapping_indicators(self):
        """Draws visual directional connectors tracking data transformation pathways."""
        if self.is_done or self.active_map_source is None:
            return

        # Base math offsets to locate sliding block targets cleanly
        floor_offset = int(self.current_shift_offset)
        fractional_offset = (self.current_shift_offset - floor_offset) * TOTAL_BOX_WIDTH
        target_cell_idx = (self.active_map_source - floor_offset) % 26
        
        src_x = START_X + self.active_map_source * TOTAL_BOX_WIDTH + BOX_SIZE // 2
        tgt_x = START_X + target_cell_idx * TOTAL_BOX_WIDTH + BOX_SIZE // 2 + int(fractional_offset)
        
        if self.mode == "ENCRYPT":
            src_y, tgt_y = Y_ROW_PLAIN + BOX_SIZE, Y_ROW_CIPHER
            mid_y = src_y + 25
        else: # DECRYPT (indicators point from cipher text back into source spaces contextually)
            src_y, tgt_y = Y_ROW_CIPHER, Y_ROW_PLAIN + BOX_SIZE
            mid_y = src_y - 25

        pygame.draw.line(self.screen, COLOR_HIGHLIGHT, (src_x, src_y), (src_x, mid_y), 3)
        pygame.draw.line(self.screen, COLOR_HIGHLIGHT, (src_x, mid_y), (tgt_x, mid_y), 3)
        pygame.draw.line(self.screen, COLOR_HIGHLIGHT, (tgt_x, mid_y), (tgt_x, tgt_y), 3)

    def draw_ui(self):
        """Fills standard textual headers and instruction graphics."""
        # Title Status Tracking Setup
        title_text = "CAESAR CIPHER VISUALIZER"
        title_surface = font_large.render(title_text, True, COLOR_TEXT_PRIMARY)
        self.screen.blit(title_surface, (WINDOW_WIDTH // 2 - title_surface.get_width() // 2, 20))

        # Instructions Bar Console
        instr_left = [
            "LEFT/RIGHT Arrows : Shift Key Value",
            "SPACEBAR          : Step Animation FORWARD",
            "BACKSPACE         : Step Animation BACKWARD",
        ]
        instr_right = [
            "TAB  : Toggle ENCRYPT/DECRYPT Mode",
            "R    : Reset Current Animation Structure",
            "ESC  : Exit Boundary Environment",
        ]

        for idx, text in enumerate(instr_left):
            self.screen.blit(font_small.render(text, True, COLOR_TEXT_MUTED), (40, 395 + idx * 24))
        for idx, text in enumerate(instr_right):
            self.screen.blit(font_small.render(text, True, COLOR_TEXT_MUTED), (460, 395 + idx * 24))

        # Highlight Core Configuration States
        mode_color = COLOR_PLAIN if self.mode == "ENCRYPT" else COLOR_CIPHER
        mode_surface = font_large.render(f"MODE: {self.mode}", True, mode_color)
        self.screen.blit(mode_surface, (40, 75))

        key_surface = font_large.render(f"KEY SHIFT: {self.shift}", True, COLOR_HIGHLIGHT)
        self.screen.blit(key_surface, (WINDOW_WIDTH - key_surface.get_width() - 40, 75))

        # Display Data Processing HUD Box Wrapper
        pygame.draw.rect(self.screen, (33, 37, 41), (40, 115, 820, 50), border_radius=6)
        
        lbl_in = "Plain In: " if self.mode == "ENCRYPT" else "Cipher In:"
        lbl_out = "Cipher Out:" if self.mode == "ENCRYPT" else "Plain Out:"
        
        input_lbl = font_medium.render(lbl_in, True, COLOR_TEXT_MUTED)
        input_val = font_medium.render(self.demo_input, True, COLOR_TEXT_PRIMARY)
        self.screen.blit(input_lbl, (55, 128))
        self.screen.blit(input_val, (185, 128))

        output_lbl = font_medium.render(lbl_out, True, COLOR_TEXT_MUTED)
        self.screen.blit(output_lbl, (460, 128))

        if self.is_done:
            # Done Indicator Alert 
            output_val = font_medium.render(self.demo_output, True, COLOR_SUCCESS)
            self.screen.blit(output_val, (600, 128))
            done_surface = font_large.render("[DONE]", True, COLOR_SUCCESS)
            self.screen.blit(done_surface, (WINDOW_WIDTH // 2 - done_surface.get_width() // 2, 340))
        else:
            cursor = "_" if pygame.time.get_ticks() % 500 < 250 else ""
            output_val = font_medium.render(self.demo_output + cursor, True, COLOR_HIGHLIGHT)
            self.screen.blit(output_val, (600, 128))

    def run(self):
        running = True
        while running:
            self.screen.fill(COLOR_BG)
            
            # --- Event Handling ---
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        running = False
                    
                    elif event.key == pygame.K_TAB:
                        # Toggle Modes and auto-reset positions to avoid string layout conflicts
                        self.mode = "DECRYPT" if self.mode == "ENCRYPT" else "ENCRYPT"
                        self.reset_animation()
                        
                    elif event.key == pygame.K_r:
                        self.reset_animation()

                    elif event.key == pygame.K_RIGHT:
                        # Infinite positive increase tracking ensures raw smooth math interpolation continuity
                        self.target_shift_raw += 1
                        self.reset_animation()
                        
                    elif event.key == pygame.K_LEFT:
                        # Infinite negative decrease tracking matches identical visual linear velocity behavior
                        self.target_shift_raw -= 1
                        self.reset_animation()
                        
                    elif event.key == pygame.K_SPACE:
                        self.step_forward()
                        
                    elif event.key == pygame.K_BACKSPACE:
                        self.step_backward()
            
            # --- State Transitions ---
            self.update_shift_animation()

            # --- Render Steps ---
            self.draw_ui()
            self.draw_alphabet_row(Y_ROW_PLAIN, shift_offset=0.0, color=COLOR_PLAIN, label="PLAIN")
            self.draw_alphabet_row(Y_ROW_CIPHER, shift_offset=self.current_shift_offset, color=COLOR_CIPHER, label="CIPHER")
            self.draw_mapping_indicators()

            pygame.display.flip()
            self.clock.tick(FPS)

        pygame.quit()
        sys.exit()

if __name__ == "__main__":
    visualizer = CaesarVisualizer()
    visualizer.run()
