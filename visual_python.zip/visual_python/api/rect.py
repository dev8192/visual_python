import pygame

def main():
    rect1 = pygame.Rect(0, 100, 200, 100)
    print(rect1)
    print(rect1.x, rect1.y, rect1.width, rect1.height)
    print(rect1.left, rect1.top, rect1.right, rect1.bottom)
    print(rect1.topleft, rect1.topright, rect1.bottomleft, rect1.bottomright)

def main5():
    rect1 = pygame.Rect(100, 100, 400, 200)
    rect2 = rect1.copy()
    rect2.move_ip(50, 20)
    print(rect1)
    print(rect2)


main()
