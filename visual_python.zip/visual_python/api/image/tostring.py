import pygame
import sys


def find_square1(surface, color):
    print("find_square1")

    # surf_bytes = pygame.image.tostring(surface, "RGB")
    surf_bytes = pygame.image.tobytes(surface, "RGB")
    surf_width, surf_height = surface.get_size()

    detected_width = 0
    detected_height = 0

    for y in range(surf_height):
        row_has_red = False
        row_red_pixels = 0
        
        for x in range(surf_width):
            idx = (y * surf_width + x) * 3
            r = surf_bytes[idx]
            g = surf_bytes[idx+1]
            b = surf_bytes[idx+2]

            if r == color[0] and g == color[1] and b == color[2]:
                row_has_red = True
                row_red_pixels += 1
                
        if row_has_red:
            detected_height += 1
            detected_width = max(detected_width, row_red_pixels)

    return detected_width, detected_height

def find_square2(surface, color):
    print("find_square2")
    
    surf_bytes = pygame.image.tobytes(surface, "RGB")
    width, height = surface.get_size()
    
    min_x, max_x = width, -1
    min_y, max_y = height, -1
    
    for y in range(height):
        for x in range(width):
            idx = (y * width + x) * 3
            if (surf_bytes[idx], surf_bytes[idx+1], surf_bytes[idx+2]) == color:
                if x < min_x: min_x = x
                if x > max_x: max_x = x
                if y < min_y: min_y = y
                if y > max_y: max_y = y
                
    # If no pixels of the target color were found at all
    if max_x == -1:
        print("Validation Failed: No shape found.")
        return None
        
    # Calculate geometric bounding box metrics
    detected_width = (max_x - min_x) + 1
    detected_height = (max_y - min_y) + 1
    
    # 3. Geometric Check: Must have a perfect 1:1 aspect ratio
    if detected_width != detected_height:
        print(f"Validation Failed: Shape is rectangular ({detected_width}x{detected_height}), not square.")
        return None
        
    square_size = detected_width
    
    # 4. Integrity Check: Ensure it is a completely filled solid square
    # Every pixel inside the bounding box MUST match target_color
    # Every pixel outside the bounding box MUST NOT match target_color
    for y in range(height):
        for x in range(width):
            idx = (y * width + x) * 3
            is_target_color = (surf_bytes[idx], surf_bytes[idx+1], surf_bytes[idx+2]) == target_color
            is_inside_box = (min_x <= x <= max_x) and (min_y <= y <= max_y)
            
            if is_inside_box and not is_target_color:
                print(f"Validation Failed: Hollow or broken shape. Missing target pixel at ({x}, {y}).")
                return None
            elif not is_inside_box and is_target_color:
                print(f"Validation Failed: Stray pixels detected outside the square boundaries at ({x}, {y}).")
                return None

    return square_size

def main():
    pygame.init()
    SQUARE_SIZE = 50
    surface = pygame.Surface((100, 100))
    surface.fill((0, 0, 0))
    color = (255, 0, 0)
    pygame.draw.rect(surface, color, (10, 10, SQUARE_SIZE, SQUARE_SIZE))
    detected_width, detected_height = find_square1(surface, color)
    # detected_width, detected_height = find_square2(surface, color)
    print(SQUARE_SIZE, detected_width, detected_height)

main()
