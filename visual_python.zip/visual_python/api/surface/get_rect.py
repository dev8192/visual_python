import pygame
import sys

pygame.init()
screen = pygame.display.set_mode((800, 600))
clock = pygame.time.Clock()

font = pygame.font.SysFont(None, 40)

button_rect = pygame.Rect(0, 0, 300, 100)
button_rect.center = (400, 300)

while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()

    screen.fill("gray12")
    pygame.draw.rect(screen, "dodgerblue", button_rect)
    text_surf = font.render("Click Me!", True, (255, 255, 255))
    text_rect = text_surf.get_rect(center=button_rect.center)
    screen.blit(text_surf, text_rect)
    pygame.display.flip()
    clock.tick(60)
