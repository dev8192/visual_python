import os
os.environ['PYGAME_HIDE_SUPPORT_PROMPT'] = "1"
import pygame

def get_color_name(color):
    for name, rgba_value in pygame.color.THECOLORS.items():
        if color == rgba_value:
            return name

def test_color(color_name):
    color = pygame.Color(color_name)
    red = str(color.r).rjust(3)
    green = str(color.g).rjust(3)
    blue = str(color.b).rjust(3)
    print(color_name.ljust(7), red, green, blue)

def main1():
    print('main1')
    colors = [
        "black", "white",
        "red", "green", "blue",
        "yellow", "cyan", "magenta",
    ]
    for color in colors:
        test_color(color)

def main15():
    print('main15')
    color1 = pygame.Color("yellow")
    print(color1.r, color1.g, color1.b)

def main2():
    print('main2')
    color1 = pygame.Color("orange")
    # Set brightness to 80%
    color1.hsva = (color1.hsva[0], color1.hsva[1], 80, color1.hsva[3])

def main3():
    print('main3')
    for name, rgba_value in pygame.color.THECOLORS.items():
        print(name, rgba_value)

def main():
    print('main4')
    for num, (name, rgba_value) in enumerate(pygame.color.THECOLORS.items(), start=1):
        print(num, name, rgba_value)

main()
