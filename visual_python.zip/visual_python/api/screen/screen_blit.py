import os
import sys
os.environ['PYGAME_HIDE_SUPPORT_PROMPT'] = "1"
import pygame

pygame.init()

screen = pygame.display.set_mode((0, 0), pygame.NOFRAME)
pygame.mouse.set_visible(False)

width, height = screen.get_size()
center_x = width // 2
center_y = height // 2

box_surface = pygame.Surface((150, 150))
box_surface.fill((0, 150, 255))

clock = pygame.time.Clock()
running = True

while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                running = False

    screen.fill((30, 30, 35))

    # screen.blit(source_surface, (destination_x, destination_y))
    # screen.blit(box_surface, (center_x - 75, center_y - 75))
    screen.blit(box_surface, (10, 10))

    pygame.display.flip()
    clock.tick(60)

pygame.quit()
sys.exit()
