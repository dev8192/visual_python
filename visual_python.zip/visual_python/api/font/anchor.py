import pygame
import sys

pygame.init()
screen = pygame.display.set_mode((800, 600))

font = pygame.font.SysFont(None, 36)

layout_config = [
    "topleft", "midtop", "topright",
    "midleft", "center", "midright",
    "bottomleft", "midbottom", "bottomright"
]

screen_rect = screen.get_rect()

text_pairs = []
def prepare_text1():
    for position_anchor in layout_config:
        surf = font.render(position_anchor, True, "white")
        rect = surf.get_rect(**{position_anchor: getattr(screen_rect, position_anchor)})        
        text_pairs.append((surf, rect))

def prepare_text():
    for position_anchor in layout_config:
        surf = font.render(position_anchor, True, "white")
        rect = surf.get_rect()
        setattr(rect, position_anchor, getattr(screen_rect, position_anchor))
        text_pairs.append((surf, rect))

prepare_text()

while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()

    screen.fill("gray12")

    for surf, rect in text_pairs:
        screen.blit(surf, rect)

    pygame.display.flip()
