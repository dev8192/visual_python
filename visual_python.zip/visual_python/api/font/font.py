import os
import sys
os.environ['PYGAME_HIDE_SUPPORT_PROMPT'] = "1"
import pygame

pygame.init()
screen = pygame.display.set_mode((400, 200))

font = pygame.font.SysFont(None, 50)
text_surf = font.render("Hello World", True, "white")

while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()

    screen.fill("gray12")
    screen.blit(text_surf, (50, 70))
    pygame.display.flip()
