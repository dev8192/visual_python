import os
os.environ['PYGAME_HIDE_SUPPORT_PROMPT'] = "1"
import pygame

def main():
    print('main1')

def main2():
    print('main2')

main()
