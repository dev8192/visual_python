import sys
import pygame

pygame.init()

screen = pygame.display.set_mode((0, 0), pygame.NOFRAME)
pygame.mouse.set_visible(False)

width, height = screen.get_size()

origin_x = width // 2
origin_y = height // 2

PIXELS_PER_UNIT = 40  

# y = a * (x - h)^2 + k
a = 0.5   # Width factor (higher = narrower, lower = wider)
h = 0.0   # Horizontal shift (vertex X position)
k = 0.0   # Vertical shift (vertex Y position)

BG_COLOR = (30, 30, 30)       # Dark charcoal
AXIS_COLOR = (100, 100, 100)  # Muted grey
CURVE_COLOR = (0, 200, 255)   # Cyan curve

clock = pygame.time.Clock()
running = True

while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                running = False

    keys = pygame.key.get_pressed()
    if keys[pygame.K_LEFT]:  h -= 0.1
    if keys[pygame.K_RIGHT]: h += 0.1
    if keys[pygame.K_UP]:    k += 0.1
    if keys[pygame.K_DOWN]:  k -= 0.1
    
    if keys[pygame.K_EQUALS] or keys[pygame.K_KP_PLUS]:
        a += 0.02
    if keys[pygame.K_MINUS] or keys[pygame.K_KP_MINUS]:
        a -= 0.02
        if a == 0: a = 0.001

    screen.fill(BG_COLOR)

    pygame.draw.line(screen, AXIS_COLOR, (0, origin_y), (width, origin_y), 2)
    pygame.draw.line(screen, AXIS_COLOR, (origin_x, 0), (origin_x, height), 2)

    points = []
    for pixel_x in range(width):
        math_x = (pixel_x - origin_x) / PIXELS_PER_UNIT

        # y = a * x^2 + b * x + c
        # y = a * (x - h)^2 + k
        math_y = a * (math_x - h) ** 2 + k
        pixel_y = int(origin_y - (math_y * PIXELS_PER_UNIT))
        if -1000 < pixel_y < height + 1000:
            points.append((pixel_x, pixel_y))
    if len(points) >= 2:
        pygame.draw.lines(screen, CURVE_COLOR, False, points, 3)

    pygame.display.flip()
    clock.tick(60)

# pygame.quit()
# sys.exit()
