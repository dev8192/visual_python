import sys
import pygame

# Initialize Pygame
pygame.init()

# Create a window that covers the full screen safely
screen = pygame.display.set_mode((0, 0), pygame.NOFRAME)
pygame.mouse.set_visible(False)

width, height = screen.get_size()

# Math setup: Cartesian origin (0,0) will map to the visual center of your screen
origin_x = width // 2
origin_y = height // 2

# Scale factor: how many pixels represent 1 mathematical unit
PIXELS_PER_UNIT = 40  

# Parabola vertex parameters in mathematical units: y = a * (x - h)^2 + k
a = 0.5   # Width factor (higher = narrower, lower = wider)
h = 0.0   # Horizontal shift (vertex X position)
k = 0.0   # Vertical shift (vertex Y position)

# Color variables
BG_COLOR = (30, 30, 30)       # Dark charcoal
AXIS_COLOR = (100, 100, 100)  # Muted grey
CURVE_COLOR = (0, 200, 255)   # Cyan curve

clock = pygame.time.Clock()
running = True

while running:
    # 1. Input Handling
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                running = False

    # Continuous keyboard press handling for smooth movement
    keys = pygame.key.get_pressed()
    
    # Move Parabola Vertex (h, k)
    if keys[pygame.K_LEFT]:  h -= 0.1
    if keys[pygame.K_RIGHT]: h += 0.1
    if keys[pygame.K_UP]:    k += 0.1
    if keys[pygame.K_DOWN]:  k -= 0.1
    
    # Scale Parabola (Width factor 'a')
    # Supports both main keyboard and numpad keys
    if keys[pygame.K_EQUALS] or keys[pygame.K_KP_PLUS]: # (EQUALS is the un-shifted '+' key)
        a += 0.02
    if keys[pygame.K_MINUS] or keys[pygame.K_KP_MINUS]:
        a -= 0.02
        if a == 0: a = 0.001 # Prevent it from flattening completely out of existence

    # 2. Rendering
    screen.fill(BG_COLOR)

    # Draw X and Y Axes lines
    pygame.draw.line(screen, AXIS_COLOR, (0, origin_y), (width, origin_y), 2)
    pygame.draw.line(screen, AXIS_COLOR, (origin_x, 0), (origin_x, height), 2)

    # Plot the Parabola
    # We iterate across every pixel column on your screen from left to right
    points = []
    for pixel_x in range(width):
        # Convert screen pixel coordinate to math X coordinate
        math_x = (pixel_x - origin_x) / PIXELS_PER_UNIT
        
        # Calculate standard vertex formula: y = a(x - h)^2 + k
        math_y = a * (math_x - h) ** 2 + k
        
        # Convert math Y coordinate back to screen pixel coordinate
        # Note: We subtract because screen coordinates go downwards, but math axes go upwards
        pixel_y = int(origin_y - (math_y * PIXELS_PER_UNIT))
        
        # Keep points roughly bounded within screen limits to save memory
        if -1000 < pixel_y < height + 1000:
            points.append((pixel_x, pixel_y))

    # Render the continuous curve if we gathered valid points
    if len(points) >= 2:
        pygame.draw.lines(screen, CURVE_COLOR, False, points, 3)

    pygame.display.flip()
    clock.tick(60)

pygame.quit()
sys.exit()
