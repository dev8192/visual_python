import os
import sys
os.environ['PYGAME_HIDE_SUPPORT_PROMPT'] = "1"
import pygame

pygame.init()
pygame.font.init()

# Set up standard windowed mode for this demo
SCREEN_WIDTH, SCREEN_HEIGHT = 1000, 700
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("Ultimate pygame.Rect Interactive Demo")
font = pygame.font.SysFont("Consolas", 18)

# Color Palette
BG_COLOR = (25, 25, 30)
WHITE = (240, 240, 245)
GRAY = (80, 80, 90)
BLUE = (0, 150, 255)
GREEN = (50, 220, 100)
RED = (255, 80, 80)
PURPLE = (180, 100, 255)

user_rect = pygame.Rect(100, 150, 200, 120)

static_obstacle = pygame.Rect(450, 250, 250, 150)
point_obstacle = (850, 200)

clamp_boundary = pygame.Rect(50, 50, 900, 600)

# ==============================================================================
# 2. DUPLICATION & MODIFICATION
# ==============================================================================
# .copy() creates an entirely separate duplicate with identical dimensions
duplicate_rect = user_rect.copy()
# Relocate the duplicate using an absolute anchor attribute so they don't overlap
duplicate_rect.topleft = (100, 500)

# Interactive control variables
dragging = False
offset_x, offset_y = 0, 0
enable_clamping = False

clock = pygame.time.Clock()
running = True

while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                running = False
            
            elif event.key in (pygame.K_EQUALS, pygame.K_KP_PLUS):
                user_rect.inflate_ip(20, 10)
            elif event.key in (pygame.K_MINUS, pygame.K_KP_MINUS):
                if user_rect.width > 30 and user_rect.height > 30:
                    user_rect.inflate_ip(-20, -10)
                    
            elif event.key == pygame.K_SPACE:
                duplicate_rect.move_ip(50, 0)
                # Keep it wrapped on screen if it goes too far right
                if duplicate_rect.left > SCREEN_WIDTH:
                    duplicate_rect.left = 50

            # Toggle clamping constraint
            elif event.key == pygame.K_c:
                enable_clamping = not enable_clamping

        elif event.type == pygame.MOUSEBUTTONDOWN:
            if event.button == 1: # Left click
                # .collidepoint(x, y) checks if a single coordinate is inside the Rect
                if user_rect.collidepoint(event.pos):
                    dragging = True
                    # Calculate vector offset to prevent the rect center from snapping to cursor
                    offset_x = user_rect.x - event.pos[0]
                    offset_y = user_rect.y - event.pos[1]

        elif event.type == pygame.MOUSEBUTTONUP:
            if event.button == 1:
                dragging = False

        elif event.type == pygame.MOUSEMOTION:
            if dragging:
                # Update position based on mouse position and original drag offset
                user_rect.x = event.pos[0] + offset_x
                user_rect.y = event.pos[1] + offset_y

    if enable_clamping:
        # .clamp(other_rect) forces a rect to stay completely inside a target rect.
        # It guarantees the moving object cannot escape the boundaries.
        user_rect.clamp_ip(clamp_boundary)

    # ==============================================================================
    # 4. COLLISION CHECKS (RECT vs RECT)
    # ==============================================================================
    # .colliderect(other_rect) returns True if two rectangles overlap anywhere
    colliding_with_box = user_rect.colliderect(static_obstacle)
    colliding_with_point = user_rect.collidepoint(point_obstacle)

    # ---------------------------------------------------------
    # RENDERING THE SCENE
    # ---------------------------------------------------------
    screen.fill(BG_COLOR)

    # Draw Clamp Boundary line
    pygame.draw.rect(screen, GRAY, clamp_boundary, 2)

    # Draw Point Obstacle (Radius 8)
    point_color = RED if colliding_with_point else WHITE
    pygame.draw.circle(screen, point_color, point_obstacle, 8)

    box_color = RED if colliding_with_box else GRAY
    pygame.draw.rect(screen, box_color, static_obstacle)
    pygame.draw.rect(screen, PURPLE, duplicate_rect, 3)
    pygame.draw.rect(screen, BLUE, user_rect)
    
    # --- PRACTICAL ASPECT: USING VIRTUAL ANCHOR ATTRIBUTES ---
    # Pygame rects have multiple automatic anchors: .center, .topleft, .bottomright, etc.
    # We can draw circles directly on them to show where they live!
    pygame.draw.circle(screen, GREEN, user_rect.center, 6)
    pygame.draw.circle(screen, WHITE, user_rect.topleft, 5)
    pygame.draw.circle(screen, WHITE, user_rect.bottomright, 5)

    stats = [
        f"--- USER RECT ATTRIBUTES ---",
        f"Raw Properties  (x, y, w, h) : ({user_rect.x}, {user_rect.y}, {user_rect.width}, {user_rect.height})",
        f"Virtual Anchors (top, left)  : ({user_rect.top}, {user_rect.left})",
        f"Virtual Anchors (right, bottom): ({user_rect.right}, {user_rect.bottom})",
        f"Virtual Anchor  (center)      : {user_rect.center}",
        f"--- REALTIME OPERATIONS ---",
        f"Colliding with Box Obstacle   : {colliding_with_box}",
        f"Colliding with Point Target   : {colliding_with_point}",
        f"Clamping State (Press 'C')   : {'ENABLED (Locked Inside Box)' if enable_clamping else 'DISABLED'}",
        f"--- CONTROLS ---",
        f"• Drag main blue box with Mouse",
        f"• Press [ + ] or [ - ] to inflate/deflate rect size",
        f"• Press [ Spacebar ] to execute .move_ip() on the purple duplicate"
    ]

    for index, text_line in enumerate(stats):
        rendered_surface = font.render(text_line, True, WHITE)
        screen.blit(rendered_surface, (20, 20 + (index * 22)))

    pygame.display.flip()
    clock.tick(60)

pygame.quit()
sys.exit()
