import os
import sys
os.environ['PYGAME_HIDE_SUPPORT_PROMPT'] = "1"
import pygame

pygame.init()

screen = pygame.display.set_mode((0, 0), pygame.NOFRAME)
pygame.mouse.set_visible(False)
width, height = screen.get_size()

try:
    # 1. Use .convert_alpha() for transparent images (.png) to handle alpha channels
    # 2. Use .convert() for solid background images (.jpg) to match pixel formats
    character_sprite = pygame.image.load("circle.png").convert_alpha()
    
except pygame.error:
    print("Warning: 'circle.png' not found. Creating placeholder.")
    character_sprite = pygame.Surface((200, 200))
    character_sprite.fill((255, 165, 0))

sprite_rect = character_sprite.get_rect()
sprite_rect.center = (width // 2, height // 2)

clock = pygame.time.Clock()
running = True

while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                running = False

    screen.fill((30, 30, 35))

    screen.blit(character_sprite, sprite_rect)

    pygame.display.flip()
    clock.tick(60)

pygame.quit()
sys.exit()
