import pygame
import sys

# Initialize Pygame
pygame.init()

# Setup Window
WIDTH, HEIGHT = 1100, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Layout Engine Verification Sandbox")
clock = pygame.time.Clock()

# Color Configuration
BACKGROUND = (22, 22, 28)
GRID_LINE = (44, 44, 56)
RULER_COLOR = (120, 125, 140)
TEXT_COLOR = (245, 245, 250)
PLUS_COLOR = (255, 215, 0)       # Vivid gold for visibility

# Focused state colors
FOCUS_BOX = (0, 150, 255)        # Bright Blue
FOCUS_FILL = (0, 150, 255, 60)
NORMAL_BOX = (100, 110, 130)     # Gray
NORMAL_FILL = (100, 110, 130, 25)

FONT = pygame.font.Font(None, 34)
FORMULA_FONT = pygame.font.Font(None, 32)
SMALL_FONT = pygame.font.Font(None, 18)

# --- Initial Simulation State ---
# Starting widths simulating combinations of 1, 2, or 3 digits (e.g. font pixels)
box_widths = [28, 56, 84, 28, 84, 56, 28, 84]
focus_index = 0

# Spacing definitions
START_X = 120
SPACING = 120
Y_POSITION = 320

def draw_pixel_ruler():
    """Draws a pixel-perfect scale at the bottom to verify raw X coordinates."""
    ruler_y = HEIGHT - 80
    pygame.draw.line(screen, RULER_COLOR, (40, ruler_y), (WIDTH - 40, ruler_y), 2)
    
    # Render ticks every 20 pixels, numbers every 100 pixels
    for x in range(0, WIDTH, 20):
        if x < 40 or x > WIDTH - 40: 
            continue
        tick_len = 12 if x % 100 == 0 else 6
        pygame.draw.line(screen, RULER_COLOR, (x, ruler_y), (x, ruler_y + tick_len), 1)
        
        if x % 100 == 0:
            val_surf = SMALL_FONT.render(str(x), True, RULER_COLOR)
            screen.blit(val_surf, (x - val_surf.get_width() // 2, ruler_y + 16))

while True:
    screen.fill(BACKGROUND)
    
    # --- Input Handling ---
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
            
        elif event.type == pygame.KEYDOWN:
            # Move selection between slots
            if event.key == pygame.K_RIGHT:
                focus_index = min(focus_index + 1, 7)
            elif event.key == pygame.K_LEFT:
                focus_index = max(focus_index - 1, 0)
                
            # Change digit simulation sizes (widths bounded between 20px and 110px)
            elif event.key == pygame.K_UP:
                box_widths[focus_index] = min(box_widths[focus_index] + 28, 112) # Simulate adding a digit
            elif event.key == pygame.K_DOWN:
                box_widths[focus_index] = max(box_widths[focus_index] - 28, 28)  # Simulate removing a digit

    # 1. Background Anchor Guides
    for i in range(8):
        cx = START_X + (i * SPACING)
        pygame.draw.line(screen, GRID_LINE, (cx, 160), (cx, 440), 1)

    # Calculate absolute Rect spaces for all blocks
    rects = []
    for i in range(8):
        cx = START_X + (i * SPACING)
        w = box_widths[i]
        
        r = pygame.Rect(0, 0, w, 50)
        r.center = (cx, Y_POSITION)
        rects.append(r)

    # 2. Render Equation Blocks (Numbers)
    for i in range(8):
        is_focused = (i == focus_index)
        box_c = FOCUS_BOX if is_focused else NORMAL_BOX
        fill_c = FOCUS_FILL if is_focused else NORMAL_FILL
        
        # Transparent surface overlay
        surf = pygame.Surface((rects[i].width, rects[i].height), pygame.SRCALPHA)
        surf.fill(fill_c)
        pygame.draw.rect(surf, box_c, (0, 0, rects[i].width, rects[i].height), 2)
        screen.blit(surf, rects[i].topleft)
        
        # Show dynamic numeric value based on width tier
        digits_label = "128" if rects[i].width > 60 else ("42" if rects[i].width > 30 else "7")
        lbl_surf = FONT.render(digits_label, True, TEXT_COLOR)
        screen.blit(lbl_surf, lbl_surf.get_rect(center=rects[i].center))
        
        # Highlight anchor pinpoint
        pygame.draw.circle(screen, (0, 255, 150), (START_X + (i * SPACING), Y_POSITION), 4)

    # 3. Dynamic Midpoint Tracking Loop for Plus Signs
    for i in range(7):
        left_cx = START_X + (i * SPACING)
        grid_midpoint = left_cx + (SPACING // 2)
        
        # --- THE PROVEN ALGORITHM ---
        space_offset = (box_widths[i] - box_widths[i + 1]) // 4
        plus_x = grid_midpoint + space_offset
        # -----------------------------

        # Render plus sign
        p_surf = FONT.render("+", True, PLUS_COLOR)
        screen.blit(p_surf, p_surf.get_rect(center=(plus_x, Y_POSITION)))

    # 4. Render Live Computation Formula (Top Layout Window)
    if focus_index < 7:
        # Show mathematical data for the current focused gap (between current and next)
        i = focus_index
        l_cx = START_X + (i * SPACING)
        g_mid = l_cx + (SPACING // 2)
        offset = (box_widths[i] - box_widths[i + 1]) // 4
        final_x = g_mid + offset
        
        formula_str = f"Selected Slot Gap: Index {i} to {i+1}"
        math_str_1 = f"Grid Midpoint = Center({l_cx}) + (Spacing({SPACING}) / 2) = {g_mid}"
        math_str_2 = f"Space Offset  = (Width_Left({box_widths[i]}) - Width_Right({box_widths[i+1]})) / 4 = {offset}"
        math_str_3 = f"Plus Position = {g_mid} + ({offset}) = Target X: {final_x}"
        
        # Render calculation blocks to screen
        screen.blit(FORMULA_FONT.render(formula_str, True, FOCUS_BOX), (40, 30))
        screen.blit(FORMULA_FONT.render(math_str_1, True, TEXT_COLOR), (40, 65))
        screen.blit(FORMULA_FONT.render(math_str_2, True, TEXT_COLOR), (40, 100))
        screen.blit(FORMULA_FONT.render(math_str_3, True, PLUS_COLOR), (40, 135))
    else:
        # End of boundary safety check
        screen.blit(FORMULA_FONT.render("Slot 7 Selected (Last Element). Press LEFT to view a gap equation calculation.", True, FOCUS_BOX), (40, 30))

    # 5. Interactive Instruction Labels
    inst_1 = "Controls: LEFT / RIGHT arrows to switch active box selection."
    inst_2 = "          UP / DOWN arrows to scale text size (change digits)."
    screen.blit(SMALL_FONT.render(inst_1, True, (150, 160, 175)), (650, 35))
    screen.blit(SMALL_FONT.render(inst_2, True, (150, 160, 175)), (650, 55))

    # 6. Render the checking system ruler scale
    draw_pixel_ruler()

    pygame.display.flip()
    clock.tick(60)
