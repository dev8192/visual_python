import pygame
import sys
import math

# Initialize Pygame
pygame.init()

# Window Setup
WIDTH, HEIGHT = 1000, 500
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Visualizing the Math Layout Engine")
clock = pygame.time.Clock()

# Colors
BACKGROUND = (20, 20, 20)
GRID_LINE_COLOR = (50, 50, 60)
TEXT_COLOR = (255, 255, 255)
PLUS_COLOR = (255, 235, 59)

# Debug Overlay Colors
CENTER_ANCHOR_COLOR = (0, 230, 118)   # Green dots = Rigid grid anchors
BOX_COLOR = (33, 150, 243, 80)       # Blue boxes = The space numbers take up
GAP_COLOR = (244, 67, 54, 40)         # Translucent Red = The empty space between bounding boxes

FONT = pygame.font.Font(None, 40)

def draw_visualizer(dynamic_width, time_tick):
    # Anchor settings
    start_x = 150
    spacing = 160
    y_position = HEIGHT // 2
    
    # Let's mock the text box widths for 5 slots
    # Slot index 2 will expand and shrink smoothly over time to show the mechanic
    base_widths = [30, 60, int(dynamic_width), 25, 90]
    
    # Render string placeholders matching the target widths
    labels = ["7", "42", "128" if dynamic_width > 65 else ("88" if dynamic_width > 40 else "5"), "0", "512"]

    # 1. Draw the background rigid grid lines first
    for i in range(5):
        cx = start_x + (i * spacing)
        pygame.draw.line(screen, GRID_LINE_COLOR, (cx, 0), (cx, HEIGHT), 1)
    
    # 2. Main layout loops
    calculated_rects = []
    for i in range(5):
        cx = start_x + (i * spacing)
        w = base_widths[i]
        h = 50
        
        # Formulate box geometry locked strictly onto the center grid coordinate
        box_rect = pygame.Rect(0, 0, w, h)
        box_rect.center = (cx, y_position)
        calculated_rects.append(box_rect)
        
        # Visual: Draw the bounding box representing font geometry
        box_surface = pygame.Surface((w, h), pygame.SRCALPHA)
        box_surface.fill((33, 150, 243, 70)) # Semi-transparent blue
        pygame.draw.rect(box_surface, (33, 150, 243), (0, 0, w, h), 2)
        screen.blit(box_surface, box_rect.topleft)
        
        # Visual: Draw the text string centered
        text_surf = FONT.render(labels[i], True, TEXT_COLOR)
        text_rect = text_surf.get_rect(center=(cx, y_position))
        screen.blit(text_surf, text_rect)
        
        # Visual: Draw the immutable green center anchor dot
        pygame.draw.circle(screen, CENTER_ANCHOR_COLOR, (cx, y_position), 5)

    # 3. Process gaps and calculate balanced plus sign coordinates
    for i in range(4):
        left_rect = calculated_rects[i]
        right_rect = calculated_rects[i + 1]
        
        # Highlight the exact physical gap in dark red
        gap_w = right_rect.left - left_rect.right
        if gap_w > 0:
            gap_surface = pygame.Surface((gap_w, 40), pygame.SRCALPHA)
            gap_surface.fill((244, 67, 54, 35)) # Semi-transparent red
            pygame.draw.rect(gap_surface, (244, 67, 54, 90), (0, 0, gap_w, 40), 1)
            screen.blit(gap_surface, (left_rect.right, y_position - 20))

        # --- THE ALGORITHM ---
        current_center = start_x + (i * spacing)
        grid_midpoint = current_center + (spacing // 2)
        space_offset = (base_widths[i] - base_widths[i + 1]) // 4
        plus_x = grid_midpoint + space_offset
        # ---------------------

        # Visual: Draw the plus sign
        plus_surf = FONT.render("+", True, PLUS_COLOR)
        plus_rect = plus_surf.get_rect(center=(plus_x, y_position))
        screen.blit(plus_surf, plus_rect)
        
        # Visual: Small tick mark plotting where the un-adjusted grid center was
        pygame.draw.line(screen, (100, 100, 100), (grid_midpoint, y_position - 35), (grid_midpoint, y_position - 25), 2)

    # Draw a quick on-screen legend
    legend_y = 40
    pygame.draw.circle(screen, CENTER_ANCHOR_COLOR, (40, legend_y), 6)
    screen.blit(FONT.render("Rigid Grid Center Anchor (Stays Static)", True, (180, 180, 180)), (60, legend_y - 12))
    
    pygame.draw.rect(screen, (33, 150, 243), (40, legend_y + 30, 15, 15))
    screen.blit(FONT.render("Text Width Boundary (Changes with digits)", True, (180, 180, 180)), (60, legend_y + 18))
    
    pygame.draw.rect(screen, (244, 67, 54), (40, legend_y + 60, 15, 15))
    screen.blit(FONT.render("Physical Gap Bounding Region", True, (180, 180, 180)), (60, legend_y + 48))

# --- Main Engine Loop ---
frame_count = 0

while True:
    screen.fill(BACKGROUND)
    
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
            
    frame_count += 1
    
    # Create an oscillating target width using a sine wave (ranging smoothly from 20px up to 110px)
    oscillating_width = 65 + math.sin(frame_count * 0.04) * 45
    
    # Execute visualization
    draw_visualizer(oscillating_width, frame_count)
    
    pygame.display.flip()
    clock.tick(60)
