import pygame
import random

pygame.init()

info = pygame.display.Info()
WIDTH, HEIGHT = info.current_w, info.current_h
screen = pygame.display.set_mode((WIDTH, HEIGHT), pygame.NOFRAME)
clock = pygame.time.Clock()

BACKGROUND = (20, 20, 25)
GRID_LINE = (35, 35, 45)
RULER_COLOR = (140, 145, 160)
TEXT_COLOR = (245, 245, 250)
PLUS_COLOR = (255, 215, 0)
TRACKER_LINE_COLOR = (255, 215, 0, 80)
FOCUS_BOX = (0, 150, 255)
FOCUS_FILL = (0, 150, 255, 50)
NORMAL_BOX = (90, 100, 115)
NORMAL_FILL = (90, 100, 115, 20)

FONT = pygame.font.SysFont("calibri", 40, bold=False)
SMALL_FONT = pygame.font.SysFont("calibri", 30, bold=False)

# State 0 (1-digit): Width=40  | State 1 (2-digit): Width=80  | State 2 (3-digit): Width=120
DIGIT_STATES = [0, 1, 2] 
STATE_WIDTHS = [40, 80, 120]

NUM_POOLS = {
    0: [1, 2, 3, 4, 5, 6, 7, 8, 9],
    1: [10, 20, 30, 40, 50, 60, 70, 80, 90],
    2: [100, 200, 300, 400, 500, 600, 700, 800, 900]
}

# 0 - one digit; 1 - two digits; 2 - three digits
current_states = [1, 1, 1, 1, 1, 1, 1, 1]
box_widths = [STATE_WIDTHS[s] for s in current_states]
box_values = [str(random.choice(NUM_POOLS[s])) for s in current_states]
focus_index = 3 # Start selection near the middle

START_X = 200
SPACING = 200
Y_POSITION = HEIGHT // 2 + 50
RULER_Y = HEIGHT - 120

def draw_pixel_ruler():
    pygame.draw.line(screen, RULER_COLOR, (50, RULER_Y), (WIDTH - 50, RULER_Y), 2)
    for x in range(0, WIDTH, 50):
        if x < 50 or x > WIDTH - 50:
            continue
        is_major = (x % 100 == 0)
        tick_len = 14 if is_major else 7
        pygame.draw.line(screen, RULER_COLOR, (x, RULER_Y), (x, RULER_Y + tick_len), 1)
        
        if is_major:
            val_surf = SMALL_FONT.render(str(x), True, RULER_COLOR)
            screen.blit(val_surf, (x - val_surf.get_width() // 2, RULER_Y + 18))

running = True
while running:    
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                running = False
            elif event.key == pygame.K_RIGHT:
                focus_index = min(focus_index + 1, 7)
            elif event.key == pygame.K_LEFT:
                focus_index = max(focus_index - 1, 0)
            elif event.key == pygame.K_UP:
                if current_states[focus_index] < 2:
                    current_states[focus_index] += 1
                    s = current_states[focus_index]
                    box_widths[focus_index] = STATE_WIDTHS[s]
                    box_values[focus_index] = str(random.choice(NUM_POOLS[s]))
            elif event.key == pygame.K_DOWN:
                if current_states[focus_index] > 0:
                    current_states[focus_index] -= 1
                    s = current_states[focus_index]
                    box_widths[focus_index] = STATE_WIDTHS[s]
                    box_values[focus_index] = str(random.choice(NUM_POOLS[s]))

    screen.fill(BACKGROUND)
    
    for i in range(8):
        cx = START_X + (i * SPACING)
        pygame.draw.line(screen, GRID_LINE, (cx, 250), (cx, Y_POSITION + 80), 2) # 670

    rects = []
    for i in range(8):
        cx = START_X + (i * SPACING)
        rect = pygame.Rect(0, 0, box_widths[i], 60)
        rect.center = (cx, Y_POSITION)
        rects.append(rect)

    for i in range(8):
        is_focused = (i == focus_index)
        box_c = FOCUS_BOX if is_focused else NORMAL_BOX
        fill_c = FOCUS_FILL if is_focused else NORMAL_FILL
        
        box_surf = pygame.Surface((rects[i].width, rects[i].height), pygame.SRCALPHA)
        box_surf.fill(fill_c)
        pygame.draw.rect(box_surf, box_c, (0, 0, rects[i].width, rects[i].height), 2)
        screen.blit(box_surf, rects[i].topleft)
        
        lbl_surf = FONT.render(box_values[i], True, TEXT_COLOR)
        screen.blit(lbl_surf, lbl_surf.get_rect(center=rects[i].center))

    plus_positions = []
    for i in range(7):
        left_cx = START_X + (i * SPACING)
        grid_midpoint = left_cx + (SPACING // 2)
        space_offset = (box_widths[i] - box_widths[i + 1]) // 4
        plus_x = grid_midpoint + space_offset
        plus_positions.append(plus_x)

        tracker_surf = pygame.Surface((2, RULER_Y - (Y_POSITION - 20)), pygame.SRCALPHA)
        tracker_surf.fill((255, 215, 0, 70))
        screen.blit(tracker_surf, (plus_x - 1, Y_POSITION - 20))

        p_surf = FONT.render("+", True, PLUS_COLOR)
        screen.blit(p_surf, p_surf.get_rect(center=(plus_x, Y_POSITION)))

    col1_x, col2_x, col3_x = 50, 680, 1240
    text_y_start = 40
    line_gap = 26

    text_arr = [
        "Grid Midpoint = Center_Left + (Spacing / 2)",
        "Space Offset  = (Width_Left - Width_Right) / 4",
        "Plus Target X = Grid Midpoint + Space Offset",
    ]
    for i in range(len(text_arr)):
        var1 = SMALL_FONT.render(text_arr[i], True, TEXT_COLOR)
        var2 = (col1_x, text_y_start + line_gap * (i + 1))
        screen.blit(var1, var2)

    if focus_index > 0:
        i = focus_index - 1
        l_cx = START_X + (i * SPACING)
        g_mid = l_cx + (SPACING // 2)
        offset = (box_widths[i] - box_widths[i + 1]) // 4
        f_x = g_mid + offset
        
        screen.blit(SMALL_FONT.render(f"Grid Midpoint = {l_cx} + ({SPACING} / 2) = {g_mid}", True, TEXT_COLOR),
                    (col2_x, text_y_start + line_gap))
        screen.blit(SMALL_FONT.render(f"Space Offset  = ({box_widths[i]} - {box_widths[i+1]}) / 4 = {offset}", True, TEXT_COLOR),
                    (col2_x, text_y_start + line_gap * 2))
        screen.blit(SMALL_FONT.render(f"Plus Target X = {g_mid} + ({offset}) = {f_x}", True, PLUS_COLOR),
                    (col2_x, text_y_start + line_gap * 3))
    else:
        screen.blit(SMALL_FONT.render("N/A: First box selected. No left plus sign exists.", True, (130, 135, 145)),
                    (col2_x, text_y_start + line_gap))

    if focus_index < 7:
        i = focus_index
        l_cx = START_X + (i * SPACING)
        g_mid = l_cx + (SPACING // 2)
        offset = (box_widths[i] - box_widths[i + 1]) // 4
        f_x = g_mid + offset
        
        screen.blit(SMALL_FONT.render(f"Grid Midpoint = {l_cx} + ({SPACING} / 2) = {g_mid}", True, TEXT_COLOR),
                    (col3_x, text_y_start + line_gap))
        screen.blit(SMALL_FONT.render(f"Space Offset  = ({box_widths[i]} - {box_widths[i+1]}) / 4 = {offset}", True, TEXT_COLOR),
                    (col3_x, text_y_start + line_gap * 2))
        screen.blit(SMALL_FONT.render(f"Plus Target X = {g_mid} + ({offset}) = {f_x}", True, PLUS_COLOR),
                    (col3_x, text_y_start + line_gap * 3))
    else:
        screen.blit(SMALL_FONT.render("N/A: Last box selected. No right plus sign exists.", True, (130, 135, 145)),
                    (col3_x, text_y_start + line_gap))

    inst_1 = "Controls: [LEFT/RIGHT] Change Selection | [UP/DOWN] Cycle Digits & Generate Random Value | [ESC] Close Sandbox"
    var1 = SMALL_FONT.render(inst_1, True, (160, 170, 185))
    screen.blit(var1, (50, HEIGHT - 80))

    draw_pixel_ruler()

    pygame.display.flip()
    clock.tick(60)
