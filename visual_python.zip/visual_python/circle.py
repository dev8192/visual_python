import os
import sys
os.environ['PYGAME_HIDE_SUPPORT_PROMPT'] = "1"
import pygame

pygame.init()

screen = pygame.display.set_mode((0, 0), pygame.NOFRAME)
pygame.mouse.set_visible(False)

width, height = screen.get_size()
cy = height // 2

BG_COLOR = (30, 30, 35)      # Dark grey/blue background
RED      = (255, 80, 80)     # Solid red
GREEN    = (50, 220, 100)    # Thick outline green
BLUE     = (0, 150, 255)     # Thin outline blue

radius = min(width, height) // 12
border_width = 0
# border_width = 10

clock = pygame.time.Clock()
running = True

while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                running = False

    screen.fill(BG_COLOR)

    pygame.draw.circle(screen, RED, (width // 4, cy), radius, width=border_width)
    pygame.draw.circle(screen, GREEN, (width // 2, cy), radius, width=border_width)
    pygame.draw.circle(screen, BLUE, ((width * 3) // 4, cy), radius, width=border_width)

    pygame.display.flip()
    clock.tick(60)

pygame.quit()
sys.exit()
