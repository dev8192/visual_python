import pygame
import sys

DIVIDEND, DIVISOR = 1628, 4

pygame.init()
screen = pygame.display.set_mode((1200, 750))
clock = pygame.time.Clock()

COLOR_BG = pygame.Color("gray12")
COLOR_GRID = pygame.Color("gray25")
COLOR_TEXT = pygame.Color("whitesmoke")
COLOR_HIGHLIGHT = pygame.Color("cyan3")
COLOR_MUTED = pygame.Color("gray45")
COLOR_ACCENT = pygame.Color("gold")

FONT = pygame.font.SysFont("Courier New", 28, bold=True)
HUD_FONT = pygame.font.SysFont("Arial", 18)
HUD_FONT_BOLD = pygame.font.SysFont("Arial", 18, bold=True)

str_divisor = str(DIVISOR)
str_dividend = str(DIVIDEND)
CELL_W, CELL_H = 34, 38
DIVISOR_LEN = len(str_divisor)
DIVIDEND_LEN = len(str_dividend)
TOTAL_COLS = DIVISOR_LEN + DIVIDEND_LEN
START_X, START_Y = 60, 120

def get_cell_rect(col, row):
    return pygame.Rect(START_X + col * CELL_W, START_Y + row * CELL_H, CELL_W, CELL_H)

def draw_centered_text(text, rect, color):
    surf = FONT.render(text, True, color)
    text_rect = surf.get_rect(center=rect.center)
    screen.blit(surf, text_rect)

# ---------------------------------------------------------
# GENERATION LOGIC: Build an active chronological timeline
# ---------------------------------------------------------
ALL_STEPS = []   
GRID_ITEMS = []  
TOTAL_ROWS = 3

def add_grid_item(step_idx, item_type, text, start_col, row):
    global TOTAL_ROWS
    GRID_ITEMS.append((item_type, text, start_col, row, step_idx))
    TOTAL_ROWS = max(TOTAL_ROWS, row + 1)

def precompute_division(dividend, divisor):
    div_str = str(dividend)
    quotient_map = {}
    current_row = 2
    rem = 0
    step_idx = 0
    is_at_start = True
    has_quotient_started = False
    
    for idx, next_digit in enumerate(div_str):
        # 1. BRING DOWN
        calc_val = rem * 10 + int(next_digit)
        bring_down_str = (str(rem) if rem > 0 else "") + next_digit
        start_col = DIVISOR_LEN + idx - len(bring_down_str) + 1
        
        if not is_at_start:
            add_grid_item(step_idx, "BRING_DOWN", bring_down_str, start_col, current_row)
            
        ALL_STEPS.append({
            "type": "BRING_DOWN", "focus_col": idx, "is_gap": False,
            "desc": f"Bring down: {next_digit}", "q_map": dict(quotient_map), "active_q_idx": -1
        })
        step_idx += 1
        
        if calc_val < divisor and idx + 1 < len(div_str):
            if has_quotient_started:
                quotient_map[idx] = ("0", step_idx)
            rem = calc_val
            continue
            
        # 2. DIVIDE
        q_digit = calc_val // divisor
        rem = calc_val % divisor
        
        quotient_map[idx] = (str(q_digit), step_idx)
        has_quotient_started = True
        is_at_start = False 
        
        ALL_STEPS.append({
            "type": "DIVIDE", "focus_col": idx, "is_gap": False,
            "desc": f"Divide: {calc_val} ÷ {divisor} = {q_digit}", "q_map": dict(quotient_map), "active_q_idx": idx
        })
        step_idx += 1
        
        # 3. MULTIPLY
        mult_val = q_digit * divisor
        mult_str = str(mult_val)
        m_start_col = DIVISOR_LEN + idx - len(mult_str) + 1
        
        add_grid_item(step_idx, "MULTIPLY", mult_str, m_start_col, current_row + 1)
        ALL_STEPS.append({
            "type": "MULTIPLY", "focus_col": idx, "is_gap": False,
            "desc": f"Multiply: {q_digit} × {divisor} = {mult_val}", "q_map": dict(quotient_map), "active_q_idx": -1
        })
        step_idx += 1
        
        # 4. SUBTRACT
        is_last = (idx == len(div_str) - 1)
        rem_str = str(rem) if (rem != 0 or is_last) else ""
        r_start_col = DIVISOR_LEN + idx - len(rem_str) + 1
        
        if rem_str != "":
            add_grid_item(step_idx, "SUBTRACT", rem_str, r_start_col, current_row + 2)
            
        ALL_STEPS.append({
            "type": "SUBTRACT", "focus_col": idx, "is_gap": True,
            "desc": f"Subtract: {calc_val} - {mult_val} = {rem}", "q_map": dict(quotient_map), "active_q_idx": -1
        })
        step_idx += 1
        
        # Move down exactly 2 rows only after completing a full subtraction cycle
        current_row += 2

precompute_division(DIVIDEND, DIVISOR)
current_step_idx = -1

# ---------------------------------------------------------
# CORE PYGAME LOOP
# ---------------------------------------------------------
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                running = False
            elif event.key == pygame.K_SPACE and current_step_idx < len(ALL_STEPS) - 1:
                current_step_idx += 1
            elif event.key == pygame.K_BACKSPACE and current_step_idx > -1:
                current_step_idx -= 1
            elif event.key == pygame.K_r:
                current_step_idx = -1

    screen.fill(COLOR_BG)
    is_finished = (current_step_idx == len(ALL_STEPS) - 1)
    
    # 1. Draw Workspace Grid Framework
    for r in range(TOTAL_ROWS):
        for c in range(TOTAL_COLS):
            pygame.draw.rect(screen, COLOR_GRID, get_cell_rect(c, r), 1)
            
    v_x = START_X + (DIVISOR_LEN * CELL_W)
    pygame.draw.line(screen, COLOR_TEXT, (v_x, START_Y + CELL_H), (v_x, START_Y + (2 * CELL_H)), 4)
    pygame.draw.line(screen, COLOR_TEXT, (v_x, START_Y + CELL_H), (START_X + (TOTAL_COLS * CELL_W), START_Y + CELL_H), 4)

    # 2. Render Static Math Operands
    for i, char in enumerate(str_divisor):
        draw_centered_text(char, get_cell_rect(i, 1), COLOR_TEXT)
        
    focus_col_idx = ALL_STEPS[current_step_idx]["focus_col"] if current_step_idx >= 0 else -1
    for i, char in enumerate(str_dividend):
        color = COLOR_TEXT if (current_step_idx == -1 or i <= focus_col_idx) else COLOR_MUTED
        draw_centered_text(char, get_cell_rect(DIVISOR_LEN + i, 1), color)

    # 3. Render Chronological Execution Pipeline Elements
    if current_step_idx >= 0:
        current_step = ALL_STEPS[current_step_idx]
        step_q_map = current_step["q_map"]
        active_q_idx = current_step["active_q_idx"]
        
        for div_idx, (char, added_at_step) in step_q_map.items():
            if added_at_step <= current_step_idx:
                is_active_digit = (div_idx == active_q_idx and current_step["type"] == "DIVIDE")
                color = COLOR_HIGHLIGHT if (is_active_digit and not is_finished) else COLOR_TEXT
                draw_centered_text(char, get_cell_rect(DIVISOR_LEN + div_idx, 0), color)
            
        for item_type, text, start_col, row, item_step_idx in GRID_ITEMS:
            if item_step_idx > current_step_idx:
                continue
                
            is_latest = (item_step_idx == current_step_idx)
            color = COLOR_HIGHLIGHT if (is_latest and not is_finished and item_type in ["MULTIPLY", "SUBTRACT", "BRING_DOWN"]) else COLOR_TEXT
            
            for i, char in enumerate(text):
                draw_centered_text(char, get_cell_rect(start_col + i, row), color)
                
            if item_type == "MULTIPLY":
                # Find the step index of the matching SUBTRACT action which follows MULTIPLY
                subtract_step_idx = item_step_idx + 1
                
                # Render the minus sign and line only if we have progressed to or past the SUBTRACT step
                if current_step_idx >= subtract_step_idx:
                    is_subtract_active = (current_step_idx == subtract_step_idx)
                    line_color = COLOR_HIGHLIGHT if (is_subtract_active and not is_finished) else COLOR_TEXT
                    
                    draw_centered_text("-", get_cell_rect(start_col - 1, row), line_color)
                    
                    line_y = get_cell_rect(start_col, row).bottom - 2
                    line_start = START_X + ((start_col - 1) * CELL_W)
                    line_end = START_X + ((start_col + len(text)) * CELL_W)
                    pygame.draw.line(screen, line_color, (line_start, line_y), (line_end, line_y), 3)

    # 4. HUD Layout Details
    panel_x, panel_y = 650, 60
    is_gold_state = (current_step_idx == -1 or is_finished)
    global_text_color = COLOR_ACCENT if is_gold_state else COLOR_TEXT
    
    labels = [f"dividend: {DIVIDEND}", f"divisor: {DIVISOR}"]
    if is_finished:
        labels.extend([f"quotient: {DIVIDEND // DIVISOR}", f"remainder: {DIVIDEND % DIVISOR}"])
    for idx, line in enumerate(labels):
        screen.blit(FONT.render(line, True, global_text_color), (panel_x, panel_y + (idx * 32)))
        
    screen.blit(HUD_FONT_BOLD.render("CALCULATION LOG:", True, COLOR_TEXT), (panel_x, panel_y + 160))
    y_offset = panel_y + 195
    
    for step_idx, step_data in enumerate(ALL_STEPS):
        if step_idx == current_step_idx and not is_finished:
            prefix, color, font_to_use = "▶ ", COLOR_HIGHLIGHT, HUD_FONT_BOLD
        else:
            prefix = " "
            color = COLOR_MUTED if (current_step_idx == -1 or step_idx > current_step_idx) else COLOR_TEXT
            font_to_use = HUD_FONT
            
        screen.blit(font_to_use.render(f"{prefix}{step_data['desc']}", True, color), (panel_x, y_offset))
        y_offset += 26 + (16 if step_data["is_gap"] else 0)

    # Info Footer Text
    inst_text = "Press [SPACEBAR] to begin computation mechanics." if current_step_idx == -1 else \
                ("Calculation Complete! Press [R] to restart." if is_finished else \
                 "Controls: [SPACEBAR] Step Forward | [BACKSPACE] Step Backward | [R] Reset")
    screen.blit(HUD_FONT.render(inst_text, True, COLOR_MUTED), (30, 700))

    pygame.display.flip()
    clock.tick(30)

pygame.quit()
sys.exit()
