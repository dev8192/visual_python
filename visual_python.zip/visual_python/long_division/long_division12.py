import pygame
import sys

DIVIDEND, DIVISOR = 1628, 4

pygame.init()
screen = pygame.display.set_mode((1200, 750))
clock = pygame.time.Clock()

COLOR_BG = pygame.Color("gray12")
COLOR_GRID = pygame.Color("gray25")
COLOR_TEXT = pygame.Color("whitesmoke")
COLOR_HIGHLIGHT = pygame.Color("cyan3")
COLOR_MUTED = pygame.Color("gray45")
COLOR_ACCENT = pygame.Color("gold")

FONT = pygame.font.SysFont("Courier New", 28, bold=True)
HUD_FONT = pygame.font.SysFont("Arial", 18)
HUD_FONT_BOLD = pygame.font.SysFont("Arial", 18, bold=True)

def compute_division_steps(dividend, divisor):
    steps = []
    div_str = str(dividend)
    
    quotient_str = ""
    history = [] 
    current_row = 2 
    
    current_idx = 0
    running_str = ""
    rem = 0
    
    while current_idx < len(div_str):
        next_digit = div_str[current_idx]
        
        if rem == 0 and running_str == "":
            running_str = next_digit
        else:
            running_str = str(rem) + next_digit
            
        calc_val = int(running_str)
        
        if len(history) > 0 and history[-1]["row"] == current_row:
            updated_text = next_digit if history[-1]["text"] == "" else history[-1]["text"] + next_digit
            history[-1] = {"text": updated_text, "row": current_row, "end_col": current_idx, "underline": False}
        else:
            display_rem_text = "" if rem == 0 else str(rem)
            updated_text = display_rem_text + next_digit
            history.append({"text": updated_text, "row": current_row, "end_col": current_idx, "underline": False})
        
        steps.append({
            "type": "BRING_DOWN",
            "quotient": quotient_str + ("0" if calc_val < divisor and current_idx + 1 < len(div_str) else ""),
            "desc": f"Bring down: {next_digit}",
            "history": list([dict(h) for h in history]),
            "focus_col": current_idx,
            "max_row": current_row,
            "is_gap_after": False
        })
        
        if calc_val < divisor and current_idx + 1 < len(div_str):
            quotient_str += "0"
            rem = calc_val
            current_idx += 1
            continue
            
        # 2. DIVIDE
        q_digit = calc_val // divisor
        rem = calc_val % divisor
        temp_q = quotient_str + str(q_digit)
        
        steps.append({
            "type": "DIVIDE",
            "quotient": temp_q,
            "desc": f"Divide: {calc_val} ÷ {divisor} = {q_digit}",
            "history": list([dict(h) for h in history]),
            "focus_col": current_idx,
            "max_row": current_row,
            "is_gap_after": False
        })
        
        # 3. MULTIPLY
        mult_val = q_digit * divisor
        mult_text_no_sign = f" {mult_val}" 
        
        steps.append({
            "type": "MULTIPLY",
            "quotient": temp_q,
            "desc": f"Multiply: {q_digit} × {divisor} = {mult_val}",
            "history": list([dict(h) for h in history]) + [{
                "text": mult_text_no_sign,
                "row": current_row + 1,
                "end_col": current_idx,
                "underline": False
            }],
            "focus_col": current_idx,
            "max_row": current_row + 1,
            "is_gap_after": False
        })
        
        mult_text_with_sign = f"-{mult_val}"
        history.append({"text": mult_text_with_sign, "row": current_row + 1, "end_col": current_idx, "underline": True})
        current_row += 2
        
        # 4. SUBTRACT
        is_last_step = (current_idx == len(div_str) - 1)
        rem_text = str(rem) if (rem != 0 or is_last_step) else ""
        
        steps.append({
            "type": "SUBTRACT",
            "quotient": temp_q,
            "desc": f"Subtract: {calc_val} - {mult_val} = {rem}",
            "history": list([dict(h) for h in history]) + [{
                "text": rem_text,
                "row": current_row,
                "end_col": current_idx,
                "underline": False
            }],
            "focus_col": current_idx,
            "max_row": current_row,
            "is_gap_after": True
        })
        
        history.append({"text": rem_text, "row": current_row, "end_col": current_idx, "underline": False})
        quotient_str = temp_q
        running_str = ""
        current_idx += 1
        
    return steps

ALL_STEPS = compute_division_steps(DIVIDEND, DIVISOR)
current_step_idx = -1

str_divisor = str(DIVISOR)
str_dividend = str(DIVIDEND)

CELL_W = 34
CELL_H = 38
DIVISOR_LEN = len(str_divisor)
DIVIDEND_LEN = len(str_dividend)

TOTAL_COLS = DIVISOR_LEN + DIVIDEND_LEN
TOTAL_ROWS = ALL_STEPS[-1]["max_row"] + 1

START_X = 60
START_Y = 120

def get_cell_rect(col, row):
    return pygame.Rect(START_X + col * CELL_W, START_Y + row * CELL_H, CELL_W, CELL_H)

def draw_centered_text(text, rect, color):
    surf = FONT.render(text, True, color)
    text_rect = surf.get_rect(center=rect.center)
    screen.blit(surf, text_rect)

running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                running = False
            elif event.key == pygame.K_SPACE:
                if current_step_idx < len(ALL_STEPS) - 1:
                    current_step_idx += 1
            elif event.key == pygame.K_BACKSPACE:
                if current_step_idx > -1:
                    current_step_idx -= 1
            elif event.key == pygame.K_r:
                current_step_idx = -1

    screen.fill(COLOR_BG)
    is_finished = current_step_idx == (len(ALL_STEPS) - 1)
    
    for r in range(TOTAL_ROWS):
        for c in range(TOTAL_COLS):
            pygame.draw.rect(screen, COLOR_GRID, get_cell_rect(c, r), 1)

    v_line_x = START_X + (DIVISOR_LEN * CELL_W)
    pygame.draw.line(screen, COLOR_TEXT, (v_line_x, START_Y + CELL_H), (v_line_x, START_Y + (2 * CELL_H)), 4)
    h_line_y = START_Y + CELL_H
    pygame.draw.line(screen, COLOR_TEXT, (v_line_x, h_line_y), (START_X + (TOTAL_COLS * CELL_W), h_line_y), 4)

    for i, char in enumerate(str_divisor):
        draw_centered_text(char, get_cell_rect(i, 1), COLOR_TEXT)
        
    focus_col_idx = ALL_STEPS[current_step_idx]["focus_col"] if current_step_idx >= 0 else -1
    
    for i, char in enumerate(str_dividend):
        color = COLOR_TEXT if (current_step_idx == -1 or i <= focus_col_idx) else COLOR_MUTED
        draw_centered_text(char, get_cell_rect(DIVISOR_LEN + i, 1), color)

    if current_step_idx >= 0:
        state = ALL_STEPS[current_step_idx]
        
        q_str = state["quotient"]
        for i, char in enumerate(q_str):
            is_active = (i == len(q_str) - 1 and state["type"] in ["DIVIDE", "MULTIPLY"])
            color = COLOR_HIGHLIGHT if (is_active and not is_finished) else COLOR_TEXT
            draw_centered_text(char, get_cell_rect(DIVISOR_LEN + i, 0), color)

        for item_idx, item in enumerate(state["history"]):
            text = item["text"]
            row = item["row"]
            end_col = item["end_col"]
            
            if text == "":
                continue
                
            start_col = (DIVISOR_LEN + end_col) - len(text) + 1
            is_latest = (item_idx == len(state["history"]) - 1)
            
            display_text = text
            if state["type"] == "MULTIPLY" and is_latest:
                display_text = text.replace("-", " ")

            # Clear out text neon highlighting instantly when calculations are done
            color = COLOR_HIGHLIGHT if (is_latest and not is_finished and state["type"] in ["MULTIPLY", "SUBTRACT", "BRING_DOWN"]) else COLOR_TEXT

            for i, char in enumerate(display_text):
                draw_centered_text(char, get_cell_rect(start_col + i, row), color)
                
            if item["underline"] and not (state["type"] == "MULTIPLY" and is_latest):
                cell_box = get_cell_rect(start_col, row)
                line_y = cell_box.bottom - 2
                line_start_x = START_X + (start_col * CELL_W)
                line_end_x = START_X + ((DIVISOR_LEN + end_col + 1) * CELL_W)
                pygame.draw.line(screen, COLOR_TEXT, (line_start_x, line_y), (line_end_x, line_y), 3)

    panel_x = 650
    panel_y = 60
    
    is_gold_state = (current_step_idx == -1 or is_finished)
    global_text_color = COLOR_ACCENT if is_gold_state else COLOR_TEXT
    
    labels = [
        f"dividend:  {DIVIDEND}",
        f"divisor:   {DIVISOR}"
    ]
    
    if is_finished:
        labels.append(f"quotient:  {DIVIDEND // DIVISOR}")
        labels.append(f"remainder: {DIVIDEND % DIVISOR}")
    
    for idx, line in enumerate(labels):
        lbl_surf = FONT.render(line, True, global_text_color)
        screen.blit(lbl_surf, (panel_x, panel_y + (idx * 32)))
        
    header_surf = HUD_FONT_BOLD.render("CALCULATION LOG:", True, COLOR_TEXT)
    screen.blit(header_surf, (panel_x, panel_y + 160))
    
    y_offset = panel_y + 195
    for step_idx, step_data in enumerate(ALL_STEPS):
        if step_idx == current_step_idx and not is_finished:
            prefix = "▶ "
            color = COLOR_HIGHLIGHT
            font_to_use = HUD_FONT_BOLD
        else:
            prefix = "  "
            color = COLOR_MUTED if (current_step_idx == -1 or step_idx > current_step_idx) else COLOR_TEXT
            font_to_use = HUD_FONT
            
        step_log_surf = font_to_use.render(f"{prefix}{step_data['desc']}", True, color)
        screen.blit(step_log_surf, (panel_x, y_offset))
        y_offset += 26
        
        if step_data["is_gap_after"]:
            y_offset += 16

    inst_text = "Controls: [SPACEBAR] Step Forward  |  [BACKSPACE] Step Backward  |  [R] Reset"
    if current_step_idx == -1:
        inst_text = "Press [SPACEBAR] to begin computation mechanics."
    elif is_finished:
        inst_text = "Calculation Complete! Press [R] to restart."
        
    inst_surf = HUD_FONT.render(inst_text, True, COLOR_MUTED)
    screen.blit(inst_surf, (30, 700))

    pygame.display.flip()
    clock.tick(30)

pygame.quit()
sys.exit()
