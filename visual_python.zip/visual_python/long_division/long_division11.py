import pygame
import sys

# ==========================================
# USER INPUT: Change numbers here!
# ==========================================
DIVIDEND = 1628
DIVISOR = 4

# Initialize Pygame
pygame.init()
screen = pygame.display.set_mode((1200, 750))
pygame.display.set_caption("Clean Long Division Engine")
clock = pygame.time.Clock()

# Color Palette
COLOR_BG = pygame.Color("gray12")
COLOR_GRID = pygame.Color("gray25")
COLOR_TEXT = pygame.Color("whitesmoke")
COLOR_HIGHLIGHT = pygame.Color("cyan3")
COLOR_MUTED = pygame.Color("gray45")
COLOR_ACCENT = pygame.Color("gold")

# Fonts
FONT = pygame.font.SysFont("Courier New", 28, bold=True)
HUD_FONT = pygame.font.SysFont("Arial", 18)
HUD_FONT_BOLD = pygame.font.SysFont("Arial", 18, bold=True)

def compute_division_steps(dividend, divisor):
    """Computes perfectly aligned long division steps using strict single-digit bring-downs."""
    steps = []
    div_str = str(dividend)
    
    quotient_str = ""
    history = [] 
    current_row = 2 
    
    current_idx = 0
    running_str = ""
    rem = 0
    
    # Process the entire dividend digit by digit
    while current_idx < len(div_str):
        next_digit = div_str[current_idx]
        
        # 1. BRING DOWN (Always exactly one single character)
        if rem == 0 and running_str == "":
            running_str = next_digit
        else:
            running_str = str(rem) + next_digit
            
        # Strip leading zeros for calculation but handle pure zero state
        calc_val = int(running_str)
        
        # Compute tracking string text for the layout grid cells
        if len(history) > 0 and history[-1]["row"] == current_row:
            # Append digit to the existing residual remainder row cell
            updated_text = next_digit if history[-1]["text"] == "" else history[-1]["text"] + next_digit
            history[-1] = {"text": updated_text, "row": current_row, "end_col": current_idx, "underline": False}
        else:
            # Create a brand new workspace row for this bring down step
            display_rem_text = "" if rem == 0 else str(rem)
            updated_text = display_rem_text + next_digit
            history.append({"text": updated_text, "row": current_row, "end_col": current_idx, "underline": False})
            
        padded_q = " " * (len(div_str) - len(quotient_str)) + quotient_str
        
        steps.append({
            "type": "BRING_DOWN", "quotient": padded_q, "q_col": max(0, len(quotient_str) - 1),
            "desc": f"Bring down: {next_digit}",
            "history": list([dict(h) for h in history]), "focus_col": current_idx, "max_row": current_row, "is_gap_after": False
        })
        
        # Check if the pulled slice is large enough to divide yet
        if calc_val < divisor and current_idx + 1 < len(div_str):
            # Record intermediate 0 into quotient and loop back up to fetch the next digit
            quotient_str += "0"
            rem = calc_val
            current_idx += 1
            continue
            
        # 2. DIVIDE
        q_digit = calc_val // divisor
        rem = calc_val % divisor
        
        temp_q = quotient_str + str(q_digit)
        padded_quotient = " " * (len(div_str) - len(temp_q)) + temp_q
        
        steps.append({
            "type": "DIVIDE", "quotient": padded_quotient, "q_col": len(div_str) - len(temp_q) + len(temp_q) - 1,
            "desc": f"Divide: {calc_val} ÷ {divisor} = {q_digit}",
            "history": list([dict(h) for h in history]), "focus_col": current_idx, "max_row": current_row, "is_gap_after": False
        })
        
        # 3. MULTIPLY (Keep empty spacing space where '-' sign goes later)
        mult_val = q_digit * divisor
        mult_text_no_sign = f" {mult_val}" 
        
        steps.append({
            "type": "MULTIPLY", "quotient": padded_quotient, "q_col": len(div_str) - len(temp_q) + len(temp_q) - 1,
            "desc": f"Multiply: {q_digit} × {divisor} = {mult_val}",
            "history": list([dict(h) for h in history]) + [{"text": mult_text_no_sign, "row": current_row + 1, "end_col": current_idx, "underline": False}],
            "focus_col": current_idx, "max_row": current_row + 1, "is_gap_after": False
        })
        
        # Commit updated mathematical operational lines for next structural phase
        mult_text_with_sign = f"-{mult_val}"
        history.append({"text": mult_text_with_sign, "row": current_row + 1, "end_col": current_idx, "underline": True})
        current_row += 2
        
        # 4. SUBTRACT
        is_last_step = (current_idx == len(div_str) - 1)
        rem_text = str(rem) if (rem != 0 or is_last_step) else ""
        
        steps.append({
            "type": "SUBTRACT", "quotient": padded_quotient, "q_col": len(div_str) - len(temp_q) + len(temp_q) - 1,
            "desc": f"Subtract: {calc_val} - {mult_val} = {rem}",
            "history": list([dict(h) for h in history]) + [{"text": rem_text, "row": current_row, "end_col": current_idx, "underline": False}],
            "focus_col": current_idx, "max_row": current_row, "is_gap_after": True
        })
        
        history.append({"text": rem_text, "row": current_row, "end_col": current_idx, "underline": False})
        quotient_str = temp_q
        running_str = ""
        current_idx += 1
        
    return steps

ALL_STEPS = compute_division_steps(DIVIDEND, DIVISOR)
current_step_idx = -1

str_divisor = str(DIVISOR)
str_dividend = str(DIVIDEND)

CELL_W = 34   
CELL_H = 38
DIVISOR_LEN = len(str_divisor)
DIVIDEND_LEN = len(str_dividend)

TOTAL_COLS = DIVISOR_LEN + DIVIDEND_LEN
TOTAL_ROWS = ALL_STEPS[-1]["max_row"] + 1

START_X = 60
START_Y = 120

def get_cell_rect(col, row):
    return pygame.Rect(START_X + col * CELL_W, START_Y + row * CELL_H, CELL_W, CELL_H)

def draw_centered_text(text, rect, color):
    surf = FONT.render(text, True, color)
    text_rect = surf.get_rect(center=rect.center)
    screen.blit(surf, text_rect)

running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE:
                if current_step_idx < len(ALL_STEPS) - 1:
                    current_step_idx += 1
            elif event.key == pygame.K_BACKSPACE:
                if current_step_idx > -1:
                    current_step_idx -= 1
            elif event.key == pygame.K_r:
                current_step_idx = -1

    screen.fill(COLOR_BG)
    
    # 1. DRAW MATRIX
    for r in range(TOTAL_ROWS):
        for c in range(TOTAL_COLS):
            pygame.draw.rect(screen, COLOR_GRID, get_cell_rect(c, r), 1)

    # 2. DRAW MATH BOUNDARY LINING
    v_line_x = START_X + (DIVISOR_LEN * CELL_W)
    pygame.draw.line(screen, COLOR_TEXT, (v_line_x, START_Y + CELL_H), (v_line_x, START_Y + (2 * CELL_H)), 4)
    h_line_y = START_Y + CELL_H
    pygame.draw.line(screen, COLOR_TEXT, (v_line_x, h_line_y), (START_X + (TOTAL_COLS * CELL_W), h_line_y), 4)

    # 3. DRAW DIVISOR & DIVIDEND
    for i, char in enumerate(str_divisor):
        draw_centered_text(char, get_cell_rect(i, 1), COLOR_TEXT)
        
    div_start_col = DIVISOR_LEN
    focus_col_idx = ALL_STEPS[current_step_idx]["focus_col"] if current_step_idx >= 0 else -1
    
    for i, char in enumerate(str_dividend):
        color = COLOR_TEXT if (current_step_idx == -1 or i <= focus_col_idx) else COLOR_MUTED
        draw_centered_text(char, get_cell_rect(div_start_col + i, 1), color)

    # 4. DRAW DYNAMIC WORK VALUES
    if current_step_idx >= 0:
        state = ALL_STEPS[current_step_idx]
        
        # Draw Quotient perfectly matching the dividend text columns
        q_str = state["quotient"]
        for i, char in enumerate(q_str):
            if char == " ":
                continue
            is_active = (i == state["q_col"] and state["type"] in ["DIVIDE", "MULTIPLY"])
            color = COLOR_HIGHLIGHT if is_active else COLOR_TEXT
            draw_centered_text(char, get_cell_rect(div_start_col + i, 0), color)

        # Draw math layout cascade tracking
        for item_idx, item in enumerate(state["history"]):
            text = item["text"]
            row = item["row"]
            end_col = item["end_col"]
            
            if text == "":
                continue
                
            start_col = (div_start_col + end_col) - len(text) + 1
            is_latest = (item_idx == len(state["history"]) - 1)
            
            # Hide '-' math signs completely during pure MULTIPLY steps
            display_text = text
            if state["type"] == "MULTIPLY" and is_latest:
                display_text = text.replace("-", " ")

            color = COLOR_HIGHLIGHT if (is_latest and state["type"] in ["MULTIPLY", "SUBTRACT", "BRING_DOWN"]) else COLOR_TEXT

            for i, char in enumerate(display_text):
                draw_centered_text(char, get_cell_rect(start_col + i, row), color)
                
            # Hide cell underlines during pure MULTIPLY steps
            if item["underline"] and not (state["type"] == "MULTIPLY" and is_latest):
                cell_box = get_cell_rect(start_col, row)
                line_y = cell_box.bottom - 2
                line_start_x = START_X + (start_col * CELL_W)
                line_end_x = START_X + ((div_start_col + end_col + 1) * CELL_W)
                pygame.draw.line(screen, COLOR_TEXT, (line_start_x, line_y), (line_end_x, line_y), 3)

    # 5. RIGHT PANEL: SUMMARY VALUES BLOCK AND CALCULATION HISTORY
    panel_x = 650
    panel_y = 60
    is_finished = (current_step_idx == len(ALL_STEPS) - 1)
    
    # Gather evaluation states dynamically
    val_quotient = str(DIVIDEND // DIVISOR) if is_finished else ""
    val_remainder = str(DIVIDEND % DIVISOR) if is_finished else ""
    
    # Summary list layouts
    labels = [
        f"dividend:  {DIVIDEND}",
        f"divisor:   {DIVISOR}",
        f"quotient:  {val_quotient}",
        f"remainder: {val_remainder}"
    ]
    
    # Highlight all 4 rows simultaneously in dynamic gold color upon completion
    global_text_color = COLOR_ACCENT if is_finished else COLOR_TEXT
    for idx, line in enumerate(labels):
        lbl_surf = FONT.render(line, True, global_text_color)
        screen.blit(lbl_surf, (panel_x, panel_y + (idx * 32)))
        
    header_surf = HUD_FONT_BOLD.render("CALCULATION LOG:", True, COLOR_TEXT)
    screen.blit(header_surf, (panel_x, panel_y + 160))
    
    # Render unified log items with consistent line gaps
    y_offset = panel_y + 195
    for step_idx, step_data in enumerate(ALL_STEPS):
        if step_idx == current_step_idx and not is_finished:
            prefix = "▶ "
            color = COLOR_HIGHLIGHT
            font_to_use = HUD_FONT_BOLD
        else:
            prefix = "  "
            color = COLOR_MUTED if (current_step_idx == -1 or step_idx > current_step_idx) else COLOR_TEXT
            font_to_use = HUD_FONT
            
        step_log_surf = font_to_use.render(f"{prefix}{step_data['desc']}", True, color)
        screen.blit(step_log_surf, (panel_x, y_offset))
        y_offset += 26
        
        if step_data["is_gap_after"]:
            y_offset += 16

    # Controls UI display footer panel
    inst_text = "Controls: [SPACEBAR] Step Forward  |  [BACKSPACE] Step Backward  |  [R] Reset"
    if current_step_idx == -1:
        inst_text = "Press [SPACEBAR] to begin computation mechanics."
    elif is_finished:
        inst_text = "Calculation Complete! Press [R] to restart."
        
    inst_surf = HUD_FONT.render(inst_text, True, COLOR_MUTED)
    screen.blit(inst_surf, (30, 700))

    pygame.display.flip()
    clock.tick(30)

pygame.quit()
sys.exit()
