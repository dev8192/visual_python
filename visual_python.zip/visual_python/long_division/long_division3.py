import pygame
import sys

# DIVIDEND, DIVISOR = 4812, 12
DIVIDEND, DIVISOR = 1628, 4
# DIVIDEND, DIVISOR = 17640, 35

# Initialize Pygame
pygame.init()
screen = pygame.display.set_mode((1000, 750))
pygame.display.set_caption("Grid Long Division")
clock = pygame.time.Clock()

# Colors
COLOR_BG = pygame.Color("gray15")
COLOR_GRID = pygame.Color("gray25")
COLOR_TEXT = pygame.Color("whitesmoke")
COLOR_HIGHLIGHT = pygame.Color("cyan3")
COLOR_MUTED = pygame.Color("gray45")

# Fonts
FONT = pygame.font.SysFont("Courier New", 42, bold=True)
SUB_FONT = pygame.font.SysFont("Arial", 22)

def compute_division_steps(dividend, divisor):
    """Computes division mechanics skipping useless leading zeros."""
    steps = []
    div_str = str(dividend)
    
    current_idx = 0
    running_str = ""
    
    while current_idx < len(div_str):
        running_str += div_str[current_idx]
        if int(running_str) >= divisor:
            break
        current_idx += 1
        
    if current_idx >= len(div_str):
        current_idx = len(div_str) - 1
        running_str = div_str

    quotient_str = ""
    history = [] 
    current_row = 2 
    
    while current_idx < len(div_str):
        current_val = int(running_str)
        
        # 1. DIVIDE
        q_digit = current_val // divisor
        rem = current_val % divisor
        quotient_str += str(q_digit)
        q_col = current_idx
        
        steps.append({
            "type": "DIVIDE", "quotient": quotient_str, "q_col": q_col,
            "desc": f"Divide: {current_val} ÷ {divisor} = {q_digit}",
            "history": list(history), "focus_col": current_idx, "max_row": current_row
        })
        
        # 2. MULTIPLY
        mult_val = q_digit * divisor
        mult_text = f"-{mult_val}"
        
        steps.append({
            "type": "MULTIPLY", "quotient": quotient_str, "q_col": q_col,
            "desc": f"Multiply: {q_digit} × {divisor} = {mult_val}",
            "history": list(history) + [{"text": mult_text, "row": current_row, "end_col": current_idx, "underline": True}],
            "focus_col": current_idx, "max_row": current_row
        })
        
        history.append({"text": mult_text, "row": current_row, "end_col": current_idx, "underline": True})
        current_row += 1
        
        # 3. SUBTRACT
        rem_text = str(rem)
        steps.append({
            "type": "SUBTRACT", "quotient": quotient_str, "q_col": q_col,
            "desc": f"Subtract: {current_val} - {mult_val} = {rem}",
            "history": list(history) + [{"text": rem_text, "row": current_row, "end_col": current_idx, "underline": False}],
            "focus_col": current_idx, "max_row": current_row
        })
        
        history.append({"text": rem_text, "row": current_row, "end_col": current_idx, "underline": False})
        current_idx += 1
        
        if current_idx < len(div_str):
            next_digit = div_str[current_idx]
            running_str = str(rem) + next_digit
            current_row += 1
            
            # 4. BRING DOWN
            steps.append({
                "type": "BRING_DOWN", "quotient": quotient_str, "q_col": q_col,
                "desc": f"Bring down {next_digit} → New value: {running_str}",
                "history": history[:-1] + [{"text": history[-1]["text"] + next_digit, "row": history[-1]["row"], "end_col": current_idx, "underline": False}],
                "focus_col": current_idx, "max_row": current_row
            })
            history[-1] = {"text": history[-1]["text"] + next_digit, "row": history[-1]["row"], "end_col": current_idx, "underline": False}

    return steps

ALL_STEPS = compute_division_steps(DIVIDEND, DIVISOR)
current_step_idx = 0

str_divisor = str(DIVISOR)
str_dividend = str(DIVIDEND)

CELL_W = 50   
CELL_H = 55
DIVISOR_LEN = len(str_divisor)
DIVIDEND_LEN = len(str_dividend)

# Total columns: Divisor + 1 spacer block + Dividend
TOTAL_COLS = DIVISOR_LEN + 1 + DIVIDEND_LEN
# Pre-calculate the maximum height needed across the entire run
TOTAL_ROWS = ALL_STEPS[-1]["max_row"] + 1

START_X = (1000 - (TOTAL_COLS * CELL_W)) // 2
START_Y = 150

def get_cell_rect(col, row):
    return pygame.Rect(START_X + col * CELL_W, START_Y + row * CELL_H, CELL_W, CELL_H)

def draw_centered_text(text, rect, color):
    surf = FONT.render(text, True, color)
    text_rect = surf.get_rect(center=rect.center)
    screen.blit(surf, text_rect)

# Main Loop
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE:
                if current_step_idx < len(ALL_STEPS) - 1:
                    current_step_idx += 1
            elif event.key == pygame.K_BACKSPACE:
                if current_step_idx > 0:
                    current_step_idx -= 1
            elif event.key == pygame.K_r:
                current_step_idx = 0

    screen.fill(COLOR_BG)
    state = ALL_STEPS[current_step_idx]
    
    # 1. DRAW PRE-CALCULATED RECTANGULAR GRID MATRIX
    for r in range(TOTAL_ROWS):
        for c in range(TOTAL_COLS):
            pygame.draw.rect(screen, COLOR_GRID, get_cell_rect(c, r), 1)

    # 2. DRAW MATH BOUNDARIES
    # Vertical grid line cleanly separating Divisor + Spacer from Dividend (drawn on cell edge)
    v_line_x = START_X + ((DIVISOR_LEN + 1) * CELL_W)
    pygame.draw.line(screen, COLOR_TEXT, (v_line_x, START_Y + CELL_H), (v_line_x, START_Y + (2 * CELL_H)), 4)
    
    # Horizontal grid line cleanly separating Quotient row from Dividend row
    h_line_y = START_Y + CELL_H
    pygame.draw.line(screen, COLOR_TEXT, (v_line_x, h_line_y), (START_X + (TOTAL_COLS * CELL_W), h_line_y), 4)

    # 3. DRAW DIVISOR & DIVIDEND
    for i, char in enumerate(str_divisor):
        draw_centered_text(char, get_cell_rect(i, 1), COLOR_TEXT)
        
    div_start_col = DIVISOR_LEN + 1
    for i, char in enumerate(str_dividend):
        color = COLOR_TEXT if i <= state["focus_col"] else COLOR_MUTED
        draw_centered_text(char, get_cell_rect(div_start_col + i, 1), color)

    # 4. DRAW DYNAMIC WORK VALUES
    q_str = state["quotient"]
    q_offset = (div_start_col + state["q_col"]) - len(q_str) + 1
    for i, char in enumerate(q_str):
        is_active = (i == len(q_str) - 1 and state["type"] in ["DIVIDE", "MULTIPLY"])
        color = COLOR_HIGHLIGHT if is_active else COLOR_TEXT
        draw_centered_text(char, get_cell_rect(q_offset + i, 0), color)

    for item_idx, item in enumerate(state["history"]):
        text = item["text"]
        row = item["row"]
        end_col = item["end_col"]
        
        start_col = (div_start_col + end_col) - len(text) + 1
        is_latest = (item_idx == len(state["history"]) - 1)
        color = COLOR_HIGHLIGHT if (is_latest and state["type"] in ["MULTIPLY", "SUBTRACT", "BRING_DOWN"]) else COLOR_TEXT

        for i, char in enumerate(text):
            draw_centered_text(char, get_cell_rect(start_col + i, row), color)
            
        if item["underline"]:
            cell_box = get_cell_rect(start_col, row)
            line_y = cell_box.bottom - 2
            line_start_x = START_X + (start_col * CELL_W)
            line_end_x = START_X + ((div_start_col + end_col + 1) * CELL_W)
            pygame.draw.line(screen, COLOR_TEXT, (line_start_x, line_y), (line_end_x, line_y), 3)

    # 5. STEP WORK PHRASE & CONTROLS HUD
    desc_surf = FONT.render(state["desc"], True, COLOR_HIGHLIGHT)
    screen.blit(desc_surf, (30, 40))
    
    inst_text = "Controls: [SPACEBAR] Forward  |  [BACKSPACE] Backward  |  [R] Reset"
    if current_step_idx == len(ALL_STEPS) - 1:
        inst_text = "Calculation Complete! Press [R] to restart."
    inst_surf = SUB_FONT.render(inst_text, True, COLOR_MUTED)
    screen.blit(inst_surf, (30, 690))

    pygame.display.flip()
    clock.tick(30)

pygame.quit()
sys.exit()
