import pygame
import sys

# ==========================================
# USER INPUT: Change numbers here!
# ==========================================
DIVIDEND = 1629
DIVISOR = 4

# Initialize Pygame
pygame.init()
screen = pygame.display.set_mode((1200, 750))
pygame.display.set_caption("Clean Long Division")
clock = pygame.time.Clock()

# Color Palette
COLOR_BG = pygame.Color("gray12")
COLOR_GRID = pygame.Color("gray25")
COLOR_TEXT = pygame.Color("whitesmoke")
COLOR_HIGHLIGHT = pygame.Color("cyan3")
COLOR_MUTED = pygame.Color("gray45")
COLOR_ACCENT = pygame.Color("gold")

# Fonts
FONT = pygame.font.SysFont("Courier New", 28, bold=True)
HUD_FONT = pygame.font.SysFont("Arial", 18)
HUD_FONT_BOLD = pygame.font.SysFont("Arial", 18, bold=True)

def compute_division_steps(dividend, divisor):
    """Computes perfectly aligned long division steps without overlaps or leading zeros."""
    steps = []
    div_str = str(dividend)
    
    # Locate initial viable slice
    current_idx = 0
    running_str = ""
    while current_idx < len(div_str):
        running_str += div_str[current_idx]
        if int(running_str) >= divisor:
            break
        current_idx += 1
        
    if current_idx >= len(div_str):
        current_idx = len(div_str) - 1
        running_str = div_str

    # Explicit initial BRING DOWN step for the first iteration slice
    steps.append({
        "type": "BRING_DOWN", "quotient": "", "q_col": current_idx,
        "desc": f"Bring down digits to form target: {running_str}",
        "history": [], "focus_col": current_idx, "max_row": 2, "is_gap_after": False
    })

    quotient_str = ""
    history = [] 
    current_row = 2 
    
    # Process iterations
    while current_idx < len(div_str):
        current_val = int(running_str)
        q_digit = current_val // divisor
        rem = current_val % divisor
        
        # Build stable quotient with spacing padding to prevent jumps
        temp_q = quotient_str + str(q_digit)
        padded_quotient = temp_q + " " * (len(div_str) - len(temp_q))
        
        # 1. DIVIDE
        steps.append({
            "type": "DIVIDE", "quotient": padded_quotient, "q_col": len(temp_q) - 1,
            "desc": f"Divide: {current_val} ÷ {divisor} = {q_digit}",
            "history": list(history), "focus_col": current_idx, "max_row": current_row, "is_gap_after": False
        })
        
        # 2. MULTIPLY (No '-' sign or line drawn yet)
        mult_val = q_digit * divisor
        mult_text_no_sign = f" {mult_val}" 
        steps.append({
            "type": "MULTIPLY", "quotient": padded_quotient, "q_col": len(temp_q) - 1,
            "desc": f"Multiply: {q_digit} × {divisor} = {mult_val}",
            "history": list(history) + [{"text": mult_text_no_sign, "row": current_row, "end_col": current_idx, "underline": False}],
            "focus_col": current_idx, "max_row": current_row, "is_gap_after": False
        })
        
        # Commit with underline and subtraction sign for subsequent steps
        mult_text_with_sign = f"-{mult_val}"
        history.append({"text": mult_text_with_sign, "row": current_row, "end_col": current_idx, "underline": True})
        current_row += 1
        
        # 3. SUBTRACT
        is_last_step = (current_idx == len(div_str) - 1)
        # Always print remainder on last step or if rem != 0; else hide intermediate 0s
        if rem == 0 and not is_last_step:
            rem_text = ""
        else:
            rem_text = str(rem)
            
        steps.append({
            "type": "SUBTRACT", "quotient": padded_quotient, "q_col": len(temp_q) - 1,
            "desc": f"Subtract: {current_val} - {mult_val} = {rem}",
            "history": list(history) + [{"text": rem_text, "row": current_row, "end_col": current_idx, "underline": False}],
            "focus_col": current_idx, "max_row": current_row, "is_gap_after": is_last_step
        })
        
        history.append({"text": rem_text, "row": current_row, "end_col": current_idx, "underline": False})
        quotient_str += str(q_digit)
        current_idx += 1
        
        # --- OPTIMIZED MULTI-BRING DOWN LOOP ---
        while current_idx < len(div_str):
            next_digit = div_str[current_idx]
            if rem == 0:
                running_str = next_digit
            else:
                running_str = str(rem) + next_digit
            
            if int(running_str) < divisor and current_idx + 1 < len(div_str):
                quotient_str += "0"
                padded_q_loop = quotient_str + " " * (len(div_str) - len(quotient_str))
                updated_text = next_digit if history[-1]["text"] == "" else history[-1]["text"] + next_digit
                
                steps.append({
                    "type": "BRING_DOWN", "quotient": padded_q_loop, "q_col": len(quotient_str) - 1,
                    "desc": f"Bring down {next_digit} ({running_str} < {divisor}, add 0 to quotient)",
                    "history": history[:-1] + [{"text": updated_text, "row": history[-1]["row"], "end_col": current_idx, "underline": False}],
                    "focus_col": current_idx, "max_row": current_row, "is_gap_after": False
                })
                history[-1] = {"text": updated_text, "row": history[-1]["row"], "end_col": current_idx, "underline": False}
                rem = int(running_str)
                current_idx += 1
            else:
                padded_q_loop = quotient_str + " " * (len(div_str) - len(quotient_str))
                updated_text = next_digit if history[-1]["text"] == "" else history[-1]["text"] + next_digit
                
                steps.append({
                    "type": "BRING_DOWN", "quotient": padded_q_loop, "q_col": len(quotient_str) - 1,
                    "desc": f"Bring down {next_digit} → Next value to divide: {running_str}",
                    "history": history[:-1] + [{"text": updated_text, "row": history[-1]["row"], "end_col": current_idx, "underline": False}],
                    "focus_col": current_idx, "max_row": current_row, "is_gap_after": True  # Add layout gap after step iteration completes
                })
                history[-1] = {"text": updated_text, "row": history[-1]["row"], "end_col": current_idx, "underline": False}
                current_row += 1
                break

    return steps

ALL_STEPS = compute_division_steps(DIVIDEND, DIVISOR)
current_step_idx = -1

str_divisor = str(DIVISOR)
str_dividend = str(DIVIDEND)

CELL_W = 34   
CELL_H = 38
DIVISOR_LEN = len(str_divisor)
DIVIDEND_LEN = len(str_dividend)

TOTAL_COLS = DIVISOR_LEN + DIVIDEND_LEN
TOTAL_ROWS = ALL_STEPS[-1]["max_row"] + 1

START_X = 60
START_Y = 120

def get_cell_rect(col, row):
    return pygame.Rect(START_X + col * CELL_W, START_Y + row * CELL_H, CELL_W, CELL_H)

def draw_centered_text(text, rect, color):
    surf = FONT.render(text, True, color)
    text_rect = surf.get_rect(center=rect.center)
    screen.blit(surf, text_rect)

running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE:
                if current_step_idx < len(ALL_STEPS) - 1:
                    current_step_idx += 1
            elif event.key == pygame.K_BACKSPACE:
                if current_step_idx > -1:
                    current_step_idx -= 1
            elif event.key == pygame.K_r:
                current_step_idx = -1

    screen.fill(COLOR_BG)
    
    # 1. DRAW MATRIX
    for r in range(TOTAL_ROWS):
        for c in range(TOTAL_COLS):
            pygame.draw.rect(screen, COLOR_GRID, get_cell_rect(c, r), 1)

    # 2. DRAW MATH BOUNDARY LINING
    v_line_x = START_X + (DIVISOR_LEN * CELL_W)
    pygame.draw.line(screen, COLOR_TEXT, (v_line_x, START_Y + CELL_H), (v_line_x, START_Y + (2 * CELL_H)), 4)
    h_line_y = START_Y + CELL_H
    pygame.draw.line(screen, COLOR_TEXT, (v_line_x, h_line_y), (START_X + (TOTAL_COLS * CELL_W), h_line_y), 4)

    # 3. DRAW DIVISOR & DIVIDEND
    for i, char in enumerate(str_divisor):
        draw_centered_text(char, get_cell_rect(i, 1), COLOR_TEXT)
        
    div_start_col = DIVISOR_LEN
    focus_col_idx = ALL_STEPS[current_step_idx]["focus_col"] if current_step_idx >= 0 else -1
    
    for i, char in enumerate(str_dividend):
        color = COLOR_TEXT if (current_step_idx == -1 or i <= focus_col_idx) else COLOR_MUTED
        draw_centered_text(char, get_cell_rect(div_start_col + i, 1), color)

    # 4. DRAW DYNAMIC WORK VALUES
    if current_step_idx >= 0:
        state = ALL_STEPS[current_step_idx]
        
        # Draw Quotient aligned cleanly
        q_str = state["quotient"]
        for i, char in enumerate(q_str):
            if char == " ":
                continue
            is_active = (i == state["q_col"] and state["type"] in ["DIVIDE", "MULTIPLY"])
            color = COLOR_HIGHLIGHT if is_active else COLOR_TEXT
            draw_centered_text(char, get_cell_rect(div_start_col + i, 0), color)

        # Draw math layout cascade tracking
        for item_idx, item in enumerate(state["history"]):
            text = item["text"]
            row = item["row"]
            end_col = item["end_col"]
            
            if text == "":
                continue
                
            start_col = (div_start_col + end_col) - len(text) + 1
            is_latest = (item_idx == len(state["history"]) - 1)
            color = COLOR_HIGHLIGHT if (is_latest and state["type"] in ["MULTIPLY", "SUBTRACT", "BRING_DOWN"]) else COLOR_TEXT

            for i, char in enumerate(text):
                draw_centered_text(char, get_cell_rect(start_col + i, row), color)
                
            if item["underline"]:
                cell_box = get_cell_rect(start_col, row)
                line_y = cell_box.bottom - 2
                line_start_x = START_X + (start_col * CELL_W)
                line_end_x = START_X + ((div_start_col + end_col + 1) * CELL_W)
                pygame.draw.line(screen, COLOR_TEXT, (line_start_x, line_y), (line_end_x, line_y), 3)

    # 5. RIGHT PANEL: FORMULA AND DYNAMIC COMPLETION TRACKER Banner
    panel_x = 650
    panel_y = 60
    
    # Check if compilation is finished
    is_finished = (current_step_idx == len(ALL_STEPS) - 1)
    
    # Calculate equation display value
    if is_finished:
        final_quotient = str(DIVIDEND // DIVISOR)
        equation_str = f"{DIVIDEND} / {DIVISOR} = {final_quotient}"
    else:
        equation_str = f"{DIVIDEND} / {DIVISOR} = "
        
    formula_surf = FONT.render(equation_str, True, COLOR_ACCENT)
    screen.blit(formula_surf, (panel_x, panel_y))
    
    header_surf = HUD_FONT_BOLD.render("CALCULATION LOG:", True, COLOR_TEXT)
    screen.blit(header_surf, (panel_x, panel_y + 50))
    
    # Render scrolling log tracker blocks with iteration gaps
    y_offset = panel_y + 85
    for step_idx, step_data in enumerate(ALL_STEPS):
        # Remove highlighting logic completely if math engine is complete
        if step_idx == current_step_idx and not is_finished:
            prefix = "▶ "
            color = COLOR_HIGHLIGHT
            font_to_use = HUD_FONT_BOLD
        else:
            prefix = "  "
            color = COLOR_MUTED if (current_step_idx == -1 or step_idx > current_step_idx) else COLOR_TEXT
            font_to_use = HUD_FONT
            
        step_log_surf = font_to_use.render(f"{prefix}{step_data['desc']}", True, color)
        screen.blit(step_log_surf, (panel_x, y_offset))
        y_offset += 26
        
        # Insert a visual layout structural row gap between main calculation cycles
        if step_data["is_gap_after"]:
            y_offset += 16

    # Controls UI display footer panel
    inst_text = "Controls: [SPACEBAR] Step Forward  |  [BACKSPACE] Step Backward  |  [R] Reset"
    if current_step_idx == -1:
        inst_text = "Press [SPACEBAR] to begin computation mechanics."
    elif is_finished:
        inst_text = "Calculation Complete! Press [R] to restart."
        
    inst_surf = HUD_FONT.render(inst_text, True, COLOR_MUTED)
    screen.blit(inst_surf, (30, 700))

    pygame.display.flip()
    clock.tick(30)

pygame.quit()
sys.exit()
