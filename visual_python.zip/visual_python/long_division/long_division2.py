import pygame
import sys

# ==========================================
# USER INPUT: Change numbers here!
# ==========================================
DIVIDEND = 17640
DIVISOR = 35

# Initialize Pygame
pygame.init()
screen = pygame.display.set_mode((1000, 750))
pygame.display.set_caption("Grid-Aligned Long Division Mechanics")
clock = pygame.time.Clock()

# Color Palette
COLOR_BG = pygame.Color("gray15")
COLOR_GRID = pygame.Color("gray25")
COLOR_TEXT = pygame.Color("whitesmoke")
COLOR_HIGHLIGHT = pygame.Color("cyan3")
COLOR_MUTED = pygame.Color("gray45")
COLOR_ACCENT = pygame.Color("gold")

# Typography (Monospace is vital for perfect cell alignment)
FONT = pygame.font.SysFont("Courier New", 42, bold=True)
SUB_FONT = pygame.font.SysFont("Arial", 22)

def compute_division_steps(dividend, divisor):
    """Computes division mechanics skipping useless leading zeros."""
    steps = []
    div_str = str(dividend)
    
    # --- PHASE 1: Find the first viable window to skip leading zeros ---
    current_idx = 0
    running_str = ""
    
    while current_idx < len(div_str):
        running_str += div_str[current_idx]
        if int(running_str) >= divisor:
            break
        current_idx += 1
        
    # If the divisor is larger than the whole dividend, start at the last index anyway
    if current_idx >= len(div_str):
        current_idx = len(div_str) - 1
        running_str = div_str

    # --- PHASE 2: Main loop generating structural layout steps ---
    quotient_str = ""
    history = [] # Tracks rows: {"text": str, "row": int, "end_col": int, "underline": bool}
    
    # We track rows dynamically. 
    # Row 0 = Quotient, Row 1 = Dividend Line. Math steps start at Row 2.
    current_row = 2 
    
    while current_idx < len(div_str):
        current_val = int(running_str)
        
        # 1. DIVIDE
        q_digit = current_val // divisor
        rem = current_val % divisor
        quotient_str += str(q_digit)
        
        # Align quotient exactly above the current working column index
        q_col = current_idx
        
        steps.append({
            "type": "DIVIDE",
            "quotient": quotient_str,
            "q_col": q_col,
            "desc": f"Divide: {current_val} ÷ {divisor} = {q_digit}",
            "history": list(history),
            "focus_col": current_idx
        })
        
        # 2. MULTIPLY
        mult_val = q_digit * divisor
        mult_text = f"-{mult_val}"
        
        steps.append({
            "type": "MULTIPLY",
            "quotient": quotient_str,
            "q_col": q_col,
            "desc": f"Multiply: {q_digit} × {divisor} = {mult_val}",
            # Temporarily show the next multiplication row
            "history": list(history) + [{"text": mult_text, "row": current_row, "end_col": current_idx, "underline": True}],
            "focus_col": current_idx
        })
        
        # Commit the multiplication row to history
        history.append({"text": mult_text, "row": current_row, "end_col": current_idx, "underline": True})
        current_row += 1
        
        # 3. SUBTRACT / REMAINDER
        rem_text = str(rem)
        
        steps.append({
            "type": "SUBTRACT",
            "quotient": quotient_str,
            "q_col": q_col,
            "desc": f"Subtract: {current_val} - {mult_val} = {rem}",
            "history": list(history) + [{"text": rem_text, "row": current_row, "end_col": current_idx, "underline": False}],
            "focus_col": current_idx
        })
        
        # Commit remainder row to history
        history.append({"text": rem_text, "row": current_row, "end_col": current_idx, "underline": False})
        
        # Move to next index for bringing down digits
        current_idx += 1
        
        if current_idx < len(div_str):
            next_digit = div_str[current_idx]
            running_str = str(rem) + next_digit
            current_row += 1
            
            # 4. BRING DOWN
            steps.append({
                "type": "BRING_DOWN",
                "quotient": quotient_str,
                "q_col": q_col,
                "desc": f"Bring down {next_digit} → Next value to divide: {running_str}",
                # Modify the last history element visually to show the brought down digit
                "history": history[:-1] + [{"text": history[-1]["text"] + next_digit, "row": history[-1]["row"], "end_col": current_idx, "underline": False}],
                "focus_col": current_idx
            })
            # Commit the update into history array
            history[-1] = {"text": history[-1]["text"] + next_digit, "row": history[-1]["row"], "end_col": current_idx, "underline": False}

    return steps

# Setup Step State Machine
ALL_STEPS = compute_division_steps(DIVIDEND, DIVISOR)
current_step_idx = 0

# --- Grid Sizing Calculations ---
str_divisor = str(DIVISOR)
str_dividend = str(DIVIDEND)

CELL_W = 50   # Perfect box scale for text alignment
CELL_H = 55
DIVISOR_LEN = len(str_divisor)
DIVIDEND_LEN = len(str_dividend)

# Total columns: Divisor cells + 1 spacing gap column + Dividend cells
TOTAL_COLS = DIVISOR_LEN + 1 + DIVIDEND_LEN
# Maximum rows possible during calculation bounds
TOTAL_ROWS = len(ALL_STEPS) + 3 

# Dynamic centering coordinate calculations
START_X = (1000 - (TOTAL_COLS * CELL_W)) // 2
START_Y = 120

def get_cell_rect(col, row):
    """Calculates screen coordinate bounds for a targeted grid coordinate."""
    return pygame.Rect(START_X + col * CELL_W, START_Y + row * CELL_H, CELL_W, CELL_H)

def draw_centered_text(text, rect, color, font=FONT):
    """Renders text perfectly aligned in the middle of a grid box."""
    surf = font.render(text, True, color)
    text_rect = surf.get_rect(center=rect.center)
    screen.blit(surf, text_rect)

# Main Application Execution Loop
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE:
                if current_step_idx < len(ALL_STEPS) - 1:
                    current_step_idx += 1
            elif event.key == pygame.K_BACKSPACE:
                if current_step_idx > 0:
                    current_step_idx -= 1
            elif event.key == pygame.K_r:
                current_step_idx = 0

    screen.fill(COLOR_BG)
    state = ALL_STEPS[current_step_idx]
    
    # ----------------------------------------------------
    # 1. DRAW PRE-COMPUTED STRUCTURAL MATRIX GRID
    # ----------------------------------------------------
    for r in range(TOTAL_ROWS):
        for c in range(TOTAL_COLS):
            cell_rect = get_cell_rect(c, r)
            # Skip drawing grid blocks for the top quotient row over the divisor section
            if r == 0 and c <= DIVISOR_LEN:
                continue
            pygame.draw.rect(screen, COLOR_GRID, cell_rect, 1)

    # ----------------------------------------------------
    # 2. DRAW MATH INTERFACES (Divisor, Dividend, Bracket Lines)
    # ----------------------------------------------------
    # Draw Divisor (Rows start at index 1)
    for i, char in enumerate(str_divisor):
        draw_centered_text(char, get_cell_rect(i, 1), COLOR_TEXT)
        
    # Draw Division Bracket Border lines
    # Vertical divider line separating divisor and dividend
    v_line_x = START_X + (DIVISOR_LEN * CELL_W) + (CELL_W // 2)
    pygame.draw.line(screen, COLOR_TEXT, (v_line_x, START_Y + CELL_H), (v_line_x, START_Y + (2 * CELL_H)), 4)
    # Horizontal divider line separating quotient row and dividend row
    h_line_y = START_Y + CELL_H
    h_start_x = v_line_x
    h_end_x = START_X + (TOTAL_COLS * CELL_W)
    pygame.draw.line(screen, COLOR_TEXT, (h_start_x, h_line_y), (h_end_x, h_line_y), 4)

    # Draw Dividend digits
    div_start_col = DIVISOR_LEN + 1
    for i, char in enumerate(str_dividend):
        color = COLOR_TEXT if i <= state["focus_col"] else COLOR_MUTED
        draw_centered_text(char, get_cell_rect(div_start_col + i, 1), color)

    # ----------------------------------------------------
    # 3. DRAW DYNAMIC MATH CALCULATIONS (Quotients & Work History)
    # ----------------------------------------------------
    # Draw Current Quotient row entries
    q_str = state["quotient"]
    # Offset alignment based on how far we have progressed through the dividend columns
    q_offset = (div_start_col + state["q_col"]) - len(q_str) + 1
    
    for i, char in enumerate(q_str):
        is_active_digit = (i == len(q_str) - 1 and state["type"] in ["DIVIDE", "MULTIPLY"])
        color = COLOR_HIGHLIGHT if is_active_digit else COLOR_TEXT
        draw_centered_text(char, get_cell_rect(q_offset + i, 0), color)

    # Render working steps cascade history
    for item_idx, item in enumerate(state["history"]):
        text = item["text"]
        row = item["row"]
        end_col = item["end_col"]
        
        # Calculate exactly which grid coordinate the string sequence starts writing left-to-right
        start_col = (div_start_col + end_col) - len(text) + 1
        
        is_latest_row = (item_idx == len(state["history"]) - 1)
        color = COLOR_TEXT
        if is_latest_row and state["type"] in ["MULTIPLY", "SUBTRACT", "BRING_DOWN"]:
            color = COLOR_HIGHLIGHT

        for i, char in enumerate(text):
            char_col = start_col + i
            draw_centered_text(char, get_cell_rect(char_col, row), color)
            
        # Draw explicit horizontal math underlines inside cells if flagged
        if item["underline"]:
            cell_box = get_cell_rect(start_col, row)
            line_y = cell_box.bottom - 2
            line_start_x = START_X + (start_col * CELL_W)
            line_end_x = START_X + ((div_start_col + end_col + 1) * CELL_W)
            pygame.draw.line(screen, COLOR_TEXT, (line_start_x, line_y), (line_end_x, line_y), 3)

    # ----------------------------------------------------
    # 4. HEADS UP DISPLAY / HUD INFO TEXTS
    # ----------------------------------------------------
    title_surf = SUB_FONT.render("GRID-ALIGNED LONG DIVISION", True, COLOR_ACCENT)
    screen.blit(title_surf, (30, 30))
    
    desc_surf = FONT.render(state["desc"], True, COLOR_HIGHLIGHT)
    screen.blit(desc_surf, (30, 70))
    
    inst_text = "Controls: [SPACEBAR] Forward  |  [BACKSPACE] Backward  |  [R] Reset"
    if current_step_idx == len(ALL_STEPS) - 1:
        inst_text = "Calculation Complete! Press [R] to restart."
        
    inst_surf = SUB_FONT.render(inst_text, True, COLOR_MUTED)
    screen.blit(inst_surf, (30, 700))

    pygame.display.flip()
    clock.tick(30)

pygame.quit()
sys.exit()
