import pygame
import sys

# DIVIDEND, DIVISOR = 4812, 12
# DIVIDEND, DIVISOR = 1628, 4
DIVIDEND, DIVISOR = 17640, 35

pygame.init()
screen = pygame.display.set_mode((1000, 700))
clock = pygame.time.Clock()

COLOR_BG = pygame.Color("gray15")
COLOR_TEXT = pygame.Color("whitesmoke")
COLOR_HIGHLIGHT = pygame.Color("cyan3")
COLOR_MUTED = pygame.Color("gray45")
COLOR_ACCENT = pygame.Color("gold")

FONT = pygame.font.SysFont("Courier New", 36, bold=True)
SUB_FONT = pygame.font.SysFont("Arial", 20)

# Pre-compute the steps of Long Division
def compute_division_steps(dividend, divisor):
    steps = []
    div_str = str(dividend)
    current_idx = 0
    running_dividend_str = ""
    
    quotient_str = ""
    history = []  # Keep track of rows to draw on screen
    
    # Track vertical alignment rows
    # Each item: (text, x_offset_in_chars, color, has_underline)
    
    while current_idx < len(div_str):
        # 1. BRING DOWN step
        next_digit = div_str[current_idx]
        running_dividend_str += next_digit
        current_val = int(running_dividend_str)
        
        # Add to history as a new active focus point
        step_desc = f"Bring down {next_digit}. Current value is {current_val}."
        steps.append({
            "type": "BRING_DOWN",
            "quotient": quotient_str,
            "desc": step_desc,
            "history": list(history),
            "focus_val": current_val,
            "focus_col": current_idx
        })
        
        # 2. DIVIDE step
        q_digit = current_val // divisor
        rem = current_val % divisor
        quotient_str += str(q_digit)
        
        step_desc = f"Divide: {current_val} ÷ {divisor} = {q_digit} (Remainder: {rem})"
        steps.append({
            "type": "DIVIDE",
            "quotient": quotient_str,
            "desc": step_desc,
            "history": list(history),
            "focus_val": current_val,
            "focus_col": current_idx
        })
        
        # 3. MULTIPLY step
        mult_val = q_digit * divisor
        step_desc = f"Multiply: {q_digit} × {divisor} = {mult_val}"
        steps.append({
            "type": "MULTIPLY",
            "quotient": quotient_str,
            "desc": list(history) + [({"text": f"-{mult_val}", "col": current_idx, "underline": True})],
            "desc_text": step_desc,
            "focus_val": mult_val,
            "focus_col": current_idx
        })
        
        # 4. SUBTRACT step
        history.append({"text": f"-{mult_val}", "col": current_idx, "underline": True})
        history.append({"text": f"{rem}", "col": current_idx, "underline": False})
        
        step_desc = f"Subtract: {current_val} - {mult_val} = {rem}"
        steps.append({
            "type": "SUBTRACT",
            "quotient": quotient_str,
            "desc": list(history),
            "desc_text": step_desc,
            "focus_val": rem,
            "focus_col": current_idx
        })
        
        running_dividend_str = str(rem)
        current_idx += 1
        
    return steps

# Generate the mechanical layout steps
ALL_STEPS = compute_division_steps(DIVIDEND, DIVISOR)
current_step_idx = 0

# Grid Configuration for alignment
CHAR_W = 24
CHAR_H = 45
START_X = 400
START_Y = 200

running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE:
                if current_step_idx < len(ALL_STEPS) - 1:
                    current_step_idx += 1
            elif event.key == pygame.K_r:
                current_step_idx = 0

    # 2. Render State
    screen.fill(COLOR_BG)
    state = ALL_STEPS[current_step_idx]
    
    # --- Draw House Rules (Divisor & Dividend Structure) ---
    # Divisor Text
    divisor_str = str(DIVISOR)
    div_surf = FONT.render(divisor_str, True, COLOR_TEXT)
    screen.blit(div_surf, (START_X - (len(divisor_str) * CHAR_W) - 15, START_Y))
    
    # Dividend Text
    dividend_str = str(DIVIDEND)
    for i, char in enumerate(dividend_str):
        # Mute remaining characters that haven't been brought down yet
        color = COLOR_TEXT if i <= state["focus_col"] else COLOR_MUTED
        char_surf = FONT.render(char, True, color)
        screen.blit(char_surf, (START_X + (i * CHAR_W), START_Y))
        
    # Standard Division Bracket Lines
    bracket_x = START_X - 10
    # Vertical curve line
    pygame.draw.arc(screen, COLOR_TEXT, (bracket_x - 10, START_Y - 5, 20, CHAR_H + 5), 3.14/2, 3*3.14/2, 3)
    # Top horizontal overhead line
    pygame.draw.line(screen, COLOR_TEXT, (bracket_x, START_Y - 5), (START_X + len(dividend_str) * CHAR_W + 10, START_Y - 5), 3)

    # --- Draw Dynamic Quotient (Answer on Top) ---
    q_str = state["quotient"]
    for i, char in enumerate(q_str):
        color = COLOR_HIGHLIGHT if (i == len(q_str)-1 and state["type"] in ["DIVIDE", "MULTIPLY"]) else COLOR_TEXT
        q_surf = FONT.render(char, True, color)
        screen.blit(q_surf, (START_X + (i * CHAR_W), START_Y - CHAR_H - 10))

    # --- Draw Cascading Long Division Sub-Work ---
    active_history = state.get("desc") if isinstance(state.get("desc"), list) else state["history"]
    
    for row_idx, row_data in enumerate(active_history):
        row_y = START_Y + ((row_idx + 1) * CHAR_H)
        row_text = row_data["text"]
        target_col = row_data["col"]
        
        # Calculate trailing alignment so columns match correctly from the right side
        x_pos = START_X + ((target_col - len(row_text) + 1) * CHAR_W)
        
        # If it's the absolute latest math element, highlight it slightly
        is_latest = (row_idx == len(active_history) - 1)
        color = COLOR_HIGHLIGHT if (is_latest and state["type"] in ["MULTIPLY", "SUBTRACT"]) else COLOR_TEXT
        
        # Render numbers
        row_surf = FONT.render(row_text, True, color)
        screen.blit(row_surf, (x_pos, row_y))
        
        # Draw subtraction line divider underneath if flagged
        if row_data["underline"]:
            line_y = row_y + CHAR_H - 5
            line_start_x = START_X + ((target_col - len(row_text) + 1) * CHAR_W)
            line_end_x = START_X + (target_col + 1) * CHAR_W
            pygame.draw.line(screen, COLOR_TEXT, (line_start_x, line_y), (line_end_x, line_y), 2)

    # --- Render GUI HUD & Informational Text Panels ---
    # Top Headline Banner
    title_surf = SUB_FONT.render("LONG DIVISION MECHANICS VISUALIZER", True, COLOR_ACCENT)
    screen.blit(title_surf, (30, 30))
    
    # Instruction Footer
    inst_text = "Press [SPACEBAR] to advance step  |  Press [R] to Reset animation"
    if current_step_idx == len(ALL_STEPS) - 1:
        inst_text = "Division Complete! Press [R] to restart animation."
    inst_surf = SUB_FONT.render(inst_text, True, COLOR_MUTED)
    screen.blit(inst_surf, (30, 650))
    
    # Step Explanation Text Box
    desc_str = state.get("desc_text", state["desc"])
    desc_surf = FONT.render(desc_str, True, COLOR_HIGHLIGHT)
    screen.blit(desc_surf, (50, 100))

    # Update Display
    pygame.display.flip()
    clock.tick(30)

pygame.quit()
sys.exit()
