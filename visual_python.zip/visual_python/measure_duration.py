import os
import sys
os.environ['PYGAME_HIDE_SUPPORT_PROMPT'] = "1"
import pygame

pygame.init()
pygame.font.init()

screen = pygame.display.set_mode((0, 0), pygame.NOFRAME)
pygame.mouse.set_visible(False)

width, height = screen.get_size()

BG_COLOR    = (30, 30, 35)
TEXT_COLOR  = (240, 240, 245)
BAR_COLOR   = (0, 200, 255)
LABEL_COLOR = (150, 150, 160)

font = pygame.font.SysFont("Consolas", 32)
sub_font = pygame.font.SysFont("Consolas", 20)

key_is_held = False
start_time = 0
current_duration = 0.0
final_duration = 0.0

clock = pygame.time.Clock()
running = True

while running:
    current_ticks = pygame.time.get_ticks()

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                running = False
            
            elif event.key == pygame.K_SPACE and not key_is_held:
                key_is_held = True
                start_time = current_ticks
                final_duration = 0.0

        elif event.type == pygame.KEYUP:
            if event.key == pygame.K_SPACE and key_is_held:
                key_is_held = False
                final_duration = (current_ticks - start_time) / 1000.0
                current_duration = 0.0

    if key_is_held:
        current_duration = (current_ticks - start_time) / 1000.0

    screen.fill(BG_COLOR)

    instruction_surface = sub_font.render("Press and HOLD the [ SPACEBAR ] — Press [ ESC ] to quit", True, LABEL_COLOR)
    
    if key_is_held:
        status_surface = font.render(f"Holding... {current_duration:.2f} seconds", True, BAR_COLOR)
    elif final_duration > 0:
        status_surface = font.render(f"Total Hold Duration: {final_duration:.3f} seconds!", True, TEXT_COLOR)
    else:
        status_surface = font.render("Ready... Press Space!", True, TEXT_COLOR)

    screen.blit(instruction_surface, instruction_surface.get_rect(center=(width // 2, height // 2 - 80)))
    screen.blit(status_surface, status_surface.get_rect(center=(width // 2, height // 2)))

    if key_is_held:
        bar_width = min(int(current_duration * 100), 400)
        bar_rect = pygame.Rect(0, 0, bar_width, 20)
        bar_rect.center = (width // 2, height // 2 + 60)
        pygame.draw.rect(screen, BAR_COLOR, bar_rect)

    pygame.display.flip()
    clock.tick(60)

pygame.quit()
sys.exit()
